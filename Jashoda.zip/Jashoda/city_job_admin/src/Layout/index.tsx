import {
    MenuFoldOutlined,
    MenuUnfoldOutlined, 
    UserOutlined, 
    DashboardOutlined, 
    DropboxOutlined, 
    ArrowRightOutlined 
} from '@ant-design/icons';
import { Layout, Menu } from 'antd';
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import type { MenuProps } from 'antd';
import '../Layout/style.css'
import { Dropdown, Space } from 'antd';
import { useDispatch } from 'react-redux';
import { logout } from '../redux/action';
const { Header, Sider, Content } = Layout;
type MenuItem = Required<MenuProps>['items'][number];




function getItem(
    label: React.ReactNode,
    key: React.Key,
    icon?: React.ReactNode,
    children?: MenuItem[],
    onClick? : any,
): MenuItem {
    return {
        key,
        icon,
        children,
        label,
        onClick: onClick
    } as MenuItem;
}
// ld= 27
const AppLayout = (props: any) => {
    const [collapsed, setCollapsed] = useState(false);
    const navigate = useNavigate();
    const items: MenuItem[] = [
        getItem('Dashboard', '1', <ArrowRightOutlined />, undefined, (props: any) => {
            console.log(props);
            navigate('/');
        }), 
        getItem('User', 'sub1', <ArrowRightOutlined />,[
            getItem('Job Seeker', '2', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/user-jobseeker');
            }),
            getItem('Recruiter', '3', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/user-recruiter');
            }),
            getItem('Admin', '4', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/user-admin');
            }),
        ]),
        getItem('Job Seeker', 'sub2', <ArrowRightOutlined />,[
            getItem('Plan Payment', '5', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/seeker-planPayment');
            }),
            getItem('Profile for Job', '6', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/seeker-jobProfile');
            }),
            getItem('Job Seeker Master', 'sub7', undefined  ,[
                getItem('Job Type Master', '20', undefined, undefined, (props: any) => {
                    console.log(props);
                    navigate('/seeker-jobtypeMaster');
                }),
                getItem('Expacted Industry Master', '21', undefined, undefined, (props: any) => {
                    console.log(props);
                    navigate('/seeker-expactedIndustryMaster');
                }),
                // getItem('Location Master', '22', undefined, undefined, (props: any) => {
                //     console.log(props);
                //     navigate('/seeker-planPayment');
                // }),
                // getItem('Functional Area Master', '23', undefined, undefined, (props: any) => {
                //     console.log(props);
                //     navigate('/seeker-planPayment');
                // }), 
            ]),
                 
            
        ]),
        getItem('Recruiter', 'sub3', <ArrowRightOutlined />,[
            getItem('Plan Payment', '9', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/re-planPayment');
            }),
            getItem('Requirement for opening', '10', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/re-openinigReq');
            }),
            getItem('Recruiter Master', 'sub8', undefined  ,[
                getItem('Company Size Master', '22', undefined, undefined, (props: any) => {
                    console.log(props);
                    navigate('/re-companySize');
                }),
                getItem('Required Experience Master', '23', undefined, undefined, (props: any) => {
                    console.log(props);
                    navigate('/re-requiredExperienceMaster');
                }), 
            ]),
            
            
        ]),
        getItem('Role', 'sub6', <ArrowRightOutlined /> ,[       
        ]),
        getItem('Master', 'sub4',<ArrowRightOutlined />,[
            getItem('Location Master', '13', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/location-master');
            }),
            getItem(' Functional Area', '24', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/funcational-area-master');
            }),  
            getItem(' Education ', '25', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/education-master');
            }),  
            getItem('Skills', '26', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/skill-master');
            }),  
        ]), 
        getItem('Configurations', 'sub5', <ArrowRightOutlined />,[
            getItem('Static Pages ', '15', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/cfg-static');
            }),
            getItem('Company General', '16', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/cfg-company-general');
            }),  
            getItem('Email Tamplate', '17', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/cfg-email');
            }),  
            getItem('Contact Us', '18', undefined, undefined, (props: any) => {
                console.log(props);
                navigate('/cfg-contact');
            }), 
             
        ]), 
        getItem('Dynamic Image & Video ', '15', <ArrowRightOutlined />, undefined, (props: any) => {
                console.log(props);
                navigate('/dynamicImg');
            }),
         
    ];

   
    const dispatch =useDispatch();
    const logOut =()=>{      
        dispatch(logout())
        localStorage.clear()
        navigate("/Login");
    }
    
    const menu = (
       
        <Menu
          items={[
            {
              label: <Link to="/EditProfile">Edit Profile</Link>,
              key: '0',
            },
            {
              label:<Link to="/ChangePassword">Change Password</Link>,
              key: '1',
            },
            {
              type: 'divider',
            },
            {
              label:"Log Out",
              key: '3',
              onClick: logOut,
            },
          ]}
        />
      );

    

    return (
        <Layout>
            <Sider trigger={null} collapsible collapsed={collapsed}>
                <div className="logo text-center" >
                   City Job
                </div>
                <Menu theme="dark" defaultSelectedKeys={['1']} mode="inline" items={items} />
            </Sider>
            <Layout className="site-layout">
                <Header className="site-layout-background" style={{ padding: 0 }}>
                    {React.createElement(collapsed ? MenuUnfoldOutlined : MenuFoldOutlined, {
                        className: 'trigger menubtn',
                        onClick: () => setCollapsed(!collapsed),
                    })}
                    <div className='user_details p-3'>
                    
                    <Dropdown overlay={menu} trigger={['click']}>
                        <a onClick={e => e.preventDefault()}>
                        <Space className='Dropdown_heading'>
                           Options 
                        </Space>
                        </a>
                    </Dropdown> 
                    </div>
                </Header>
                <Content
                    className="site-layout-background"
                    style={{
                        margin: '24px 16px',
                        padding: 24,
                        minHeight: 280,
                    }}
                >
                    {props.children}
                </Content>
            </Layout>
        </Layout>
    );
};

export default AppLayout;
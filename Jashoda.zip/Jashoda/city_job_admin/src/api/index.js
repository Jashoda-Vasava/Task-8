import { APIRequest } from "./api-request";
export const USER_LOGIN = 1;
export const USER_PROFILE_UPDATE = 2;
export const UPDATE_PASSWORD =3;
export const FORGOT_PASSWORD =4;
export const SAVE_LOCATION =5;
export const GET_LOCATION =6;
export const SAVE_FUNCTION=7;
export const GET_FUNCTION =8;
export const SAVE_EDUCATION=9;
export const GET_EDUCATION =10;
export const SAVE_SKILL=11;
export const GET_SKILL =12;
export const SAVE_JOBTYPE=13;
export const GET_JOBTYPE =14;
export const SAVE_EXPIND=15;
export const GET_EXPIND =16;



export { APIRequest };
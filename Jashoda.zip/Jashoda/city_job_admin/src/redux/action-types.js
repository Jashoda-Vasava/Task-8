/**
 * Auh Action Types
 * @type {string}
 */
export const SET_TOKEN = "SET_TOKEN";
export const SET_USER = "SET_USER";


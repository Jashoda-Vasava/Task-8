import React, { Fragment, useState } from "react";
import { BrowserRouter, Outlet, Route, Routes} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import 'antd/dist/antd.css'
import { Dashboard } from './Pages/Dashboard/index'
import './App.css';
import AppLayout from "./Layout";  
import { Login } from "./Pages/Login/Login"; 
import { EditProfile } from "./Pages/User/EditProfile";
import { ChangePassword } from "./Pages/User/ChangePassword";
import { ForgotPassword } from "./Pages/Login/ForgotPassword"; 
import { UserJobSeekr } from "./Pages/User/u_jobSeeker";
import { UserRecruiter } from "./Pages/User/u_Recruiter";
import { UserAdmin } from "./Pages/User/u_admin";
import { SeekerPlanPayment } from "./Pages/JobSeeker/js_planPayment";
import { RePlanPayment } from "./Pages/Recruiter/re_PlanPayment";
import { CFG_StatciPage } from "./Pages/Configuration/cfg_staticPage";
import { CFG_CompanyGeneral } from "./Pages/Configuration/cfg_companyGeneral";
import { CFG_Email } from "./Pages/Configuration/cfg_email";
import { CFG_Contact } from "./Pages/Configuration/cfg_contact";
import { SeekerJobTypeMaster } from "./Pages/JobSeeker/js_jobTypeMaster";
import { SeekerExpactedIndustryMaster } from "./Pages/JobSeeker/js_expactedIndustry";
import { ReRequiredExperienceMaster } from "./Pages/Recruiter/re_requiredExperienceMaser";
import { ReCompanySizeMaster } from "./Pages/Recruiter/re_CompanySizeMaster";
import { LocationMaster } from "./Pages/Masters/locationMaster";
import { EducationMaster } from "./Pages/Masters/educationMaster";
import { SkillMaster } from "./Pages/Masters/skillMaster";
import { FuncationalAreaMaster } from "./Pages/Masters/funcationalArea";
import { ReOpeningRequirement } from "./Pages/Recruiter/re_OpeningRequirement";
import { SeekerJobProfile } from "./Pages/JobSeeker/js_jobProfile";
import { DynamicImages } from "./Pages/DynamicImage/dynamicImages";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import AppStore from "../src/redux/store";
import { PrivateRoute } from "./Pages/PrivateRoute/PrivateRoute";
import { PublicRoute } from "./Pages/PrivateRoute/PublicRoute";
const AppOutLet = () => {
  return (
    <AppLayout>
      <Outlet></Outlet>
    </AppLayout>
  )
}
function App() {

  return (
    <Provider store={AppStore.store}>
        <PersistGate loading={null} persistor={AppStore.persistor}>
      
      <BrowserRouter>
          <Fragment>
            <Routes>
           
              <Route path="/" element={<PrivateRoute><AppOutLet></AppOutLet></PrivateRoute>}>
                {/* user */} 
                <Route path="/user-jobseeker" element={<UserJobSeekr/>}></Route>
                <Route path="/user-recruiter" element={<UserRecruiter/>}></Route>
                <Route path="/user-admin" element={<UserAdmin/>}></Route>
                <Route path="/EditProfile" element={<EditProfile/>}></Route>
                <Route path="/ChangePassword" element={<ChangePassword/>}></Route>

                {/*   job seeker */}
                <Route path="/seeker-planPayment" element={<SeekerPlanPayment/>}></Route>
                <Route path="/seeker-jobtypeMaster" element={<SeekerJobTypeMaster/>}></Route>
                <Route path="/seeker-expactedIndustryMaster" element={<SeekerExpactedIndustryMaster/>}></Route>
                <Route path="/seeker-jobProfile" element={<SeekerJobProfile/>}></Route>
                
                {/*   recruiter */}
                <Route path="/re-planPayment" element={<RePlanPayment/>}></Route>
                <Route path="/re-requiredExperienceMaster" element={<ReRequiredExperienceMaster/>}></Route>
                <Route path="/re-companySize" element={<ReCompanySizeMaster/>}></Route>
                <Route path="/re-openinigReq" element={<ReOpeningRequirement/>}></Route>

                {/* masters */}
                <Route path="/location-master" element={<LocationMaster/>}></Route>
                <Route path="/education-master" element={<EducationMaster/>}></Route>
                <Route path="/skill-master" element={<SkillMaster/>}></Route>
                <Route path="/funcational-area-master" element={<FuncationalAreaMaster/>}></Route>

                {/* configuration */}
                <Route path="/cfg-static" element={<CFG_StatciPage/>}></Route>
                <Route path="/cfg-company-general" element={<CFG_CompanyGeneral/>}></Route>
                <Route path="/cfg-email" element={<CFG_Email/>}></Route>
                <Route path="/cfg-contact" element={<CFG_Contact/>}></Route>

                {/* dynamic img and vdo */}
                <Route path="/dynamicImg" element={<DynamicImages/>}></Route>
              
                {/* dashboard */}
                <Route path="/" element={<Dashboard/> } />
              </Route>

              {/* login */}
            
              <Route path="/Login"  element={<PublicRoute><Login/></PublicRoute> }></Route>
              <Route path="/ForgotPassword" element={<PublicRoute><ForgotPassword/></PublicRoute>}></Route> 
              
            </Routes>
          </Fragment>
        </BrowserRouter>
      </PersistGate>
      </Provider>
  );
}

export default App;

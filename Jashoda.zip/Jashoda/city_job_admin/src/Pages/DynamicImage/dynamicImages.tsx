import {Button, Table, Layout, Input,Modal, Row, Col,Select, message, Upload,Radio  } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import type { UploadProps ,RadioChangeEvent } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useState } from 'react';
import '../../assets/css/common.css'


export  const DynamicImages = () => {

    interface DataType {
        key: React.Key; 
        

        imgID:any,
        imgName:any,
        img:any,
        createdBy : any; 
        modifiedBy : any; 
    }

         
 

    const columns: ColumnsType<DataType> = [
     
    //   {
    //     title: 'Company Name',
    //     dataIndex: 'companyName', 
    //     sorter:{ compare: (a, b) =>  a.companyName.localeCompare(b.companyName),
    //       multiple:1
    //   },
    //   onCell: (record, rowIndex) => {
    //     return {
    //       onClick: () => {
    //         modalHandle()
    //       }
    //     };
    //   },
    //   // render: image_1 => <img width="150px" alt={image_1} src={image_1} /> ,
    //   // width:"150px",
    //     className:"hasFormHover" 
    //   },

    {
        title: 'Image ID',
        dataIndex: 'imgID', 
        sorter:{ compare: (a, b) =>  a.imgID.localeCompare(b.imgID),
          multiple:1
      },
      },
    
      {
        title: 'Image Name',
        dataIndex: 'imgName', 
        sorter:{ compare: (a, b) =>  a.imgName.localeCompare(b.imgName),
          multiple:1
      },
      },
    
      {
        title: 'Image',
        dataIndex: 'img', 
        render: image_1 => <img width="150px" alt={image_1} src={image_1} /> ,
         width:"150px",
         onCell: (record, rowIndex) => {
            return {
              onClick: () => {
                modalHandle()
              }
            };
          },
        className:"hasFormHover" 
      },
 

      {
        title: 'Created By',
        dataIndex: 'createdBy', 
        sorter:{ compare: (a, b) =>  a.createdBy.localeCompare(b.createdBy),
          multiple:1
      },
      },
     
      {
        title: 'Modified by',
        dataIndex: 'modifiedBy', 
        sorter:{ compare: (a, b) =>  a.modifiedBy.localeCompare(b.modifiedBy),
          multiple:1
      },
      }, 
    ];
     
    const dataSource = [
      {
        key: '0',  
        imgID:'12',
        imgName:'Main',
        img:"/images/products/product.png" ,  
        createdBy : "06-08-2022 12:22PM", 
        modifiedBy : "06-08-2022 12:22PM", 
      },  
    ];
 

   // Modal
   const [visible, setVisible] = useState(false);
   const modalHandle = () => {
     setVisible(true)
   };

    // Dropdown Select
    const { Option } = Select;
    const onChange = (value: string) => {
      console.log(`selected ${value}`);
    };
    const onSearch = (value: string) => {
      console.log('search:', value);
    };

     // upload
    const props: UploadProps = {
      name: 'file',
      action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
      headers: {
        authorization: 'authorization-text',
      },
      onChange(info) {
        if (info.file.status !== 'uploading') {
          console.log(info.file, info.fileList);
        }
        if (info.file.status === 'done') {
          message.success(`${info.file.name} file uploaded successfully`);
        } else if (info.file.status === 'error') {
          message.error(`${info.file.name} file upload failed.`);
        }
      },
      progress: {
        strokeColor: {
          '0%': '#108ee9',
          '100%': '#87d068',
        },
        strokeWidth: 3,
        format: percent => percent && `${parseFloat(percent.toFixed(2))}%`,
      },
    };
  return (<>    

    <Layout className='custom_MainBackground'>

      <div className="container-fluid p-0 d-flex justify-content-between customers_header">
        <h4>Dynamic Images & Videos</h4>
           <div>
            <Button type="primary" className='custom_activeInactive_btn' >Active</Button>
            <Button type="primary" className='custom_activeInactive_btn' >Inactive</Button> 
            <Button type="primary" className='custom_activeInactive_btn' onClick={modalHandle}>Add New</Button>
        </div>   
      </div>

      <div className="custom_TableWrapper container-fluid  ">
        <div className="d-flex">
        <label className='mt-1'><b>Search:</b></label><Input className='w-50 ms-2' />
        </div>
        <hr/>
        <Table className='custom_table'  rowSelection={{type: "checkbox",columnTitle:'Select',columnWidth:60}} columns={columns}  dataSource={dataSource}
          scroll={{ x: 1000 }}
          pagination={{ showSizeChanger:true, pageSizeOptions: [5,10,25,100] }} 
          />       
      </div>
    </Layout>

    <Modal footer={false} title="Dynamic Images and VIdeos" centered visible={visible} onOk={() => setVisible(false)} onCancel={() => setVisible(false)} width={700} >

    <Row className='Row-Height' gutter={[10,10]}> 
    {/* <img src='/images/products/product.png'/> */}

       
      <Col > 
        <Row>  
          <Col span={24}>
            <label className='label1'>Image Name   *</label><Input />
          </Col>
          <Col span={24}>
          <label className='label1'>Image *</label><br />
                  <Upload {...props}>
                    <Button icon={<UploadOutlined />}>Click to Upload</Button>
                  </Upload>
                  {/* <a href="#">View Logo</a> */}
          </Col> 
        </Row>
      </Col>


      
    


      
      <Col span={24} className="mt-4 p-0">
      <Button type="primary" className='custom_activeInactive_btn' >Save</Button>
      <Button type="primary" className='custom_activeInactive_btn' >Cancel</Button>
    </Col>
      
    </Row>


</Modal>




    
    
  </>)
}


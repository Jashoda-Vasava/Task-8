import { useSelector } from "react-redux";
import { Navigate, Route } from "react-router-dom";

export {PublicRoute};

function PublicRoute({ children }:any) {
    const token =useSelector((state:any)=>state.token)

    const user =localStorage.getItem('token')
    console.log(user,"user");
    
    if (user) {
        return <Navigate to='/' />
      }
    
      return children;

  
  }
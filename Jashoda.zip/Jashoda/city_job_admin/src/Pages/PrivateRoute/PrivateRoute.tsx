import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

export const PrivateRoute = ({ children }: any) => {
  const token = useSelector((state: any) => state.token);
  // console.log(token);
  const user = localStorage.getItem("token");
  // console.log(user, "user");
  if (!user) {
    return <Navigate to='/login' />
  }
  return children;
}



import {Button, Table, Layout, Input,Modal, Row, Col,Select, message, Upload,Radio  } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import type { UploadProps ,RadioChangeEvent } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useState } from 'react';
import '../../assets/css/common.css'


export  const SeekerJobProfile = () => {

    interface DataType {
        key: React.Key; 
        jid:any;
        emailID:any;
        education:any;
        jobPreference:any;
        experience:any;
        skills:any;
        expactedSalary:any;
        createdBy : any;
        createdOn: any;
        modifiedBy : any;
        modifiedOn : any;
        isActive : any;

    }
 
 

    const columns: ColumnsType<DataType> = [
      {
        title: 'Job ID',
        dataIndex: 'jid', 
        sorter:{ compare: (a, b) =>  a.jid.localeCompare(b.jid),
          multiple:1
      },
      }, 
      {
        title: 'Email ',
        dataIndex: 'emailID', 
        sorter:{ compare: (a, b) =>  a.emailID.localeCompare(b.emailID),
          multiple:1
      },
      onCell: (record, rowIndex) => {
        return {
          onClick: () => {
            modalHandle()
          }
        };
      },
      className:"hasFormHover"  
      }, 
      {
        title: 'Education ',
        dataIndex: 'education', 
        sorter:{ compare: (a, b) =>  a.education.localeCompare(b.education),
          multiple:1
      },
      }, 
      {
        title: 'Job Preference',
        dataIndex: 'jobPreference', 
        sorter:{ compare: (a, b) =>  a.jobPreference.localeCompare(b.jobPreference),
          multiple:1
      },
      }, 
      {
        title: 'Experience',
        dataIndex: 'experience', 
        sorter:{ compare: (a, b) =>  a.experience.localeCompare(b.experience),
          multiple:1
      },
      }, 
      {
        title: 'Skills',
        dataIndex: 'skills', 
        sorter:{ compare: (a, b) =>  a.skills.localeCompare(b.skills),
          multiple:1
      },
      }, 
      {
        title: 'Expacted Salary',
        dataIndex: 'expactedSalary', 
        sorter:{ compare: (a, b) =>  a.expactedSalary.localeCompare(b.expactedSalary),
          multiple:1
      },
      },   
      {
        title: 'Created by',
        dataIndex: 'createdBy', 
        sorter:{ compare: (a, b) =>  a.createdBy.localeCompare(b.createdBy),
          multiple:1
      },
      },
      {
        title: 'Created on',
        dataIndex: 'createdOn', 
        sorter:{ compare: (a, b) =>  a.createdOn.localeCompare(b.createdOn),
          multiple:1
      },
      },
      {
        title: 'Modified On',
        dataIndex: 'modifiedOn', 
        sorter:{ compare: (a, b) =>  a.modifiedOn.localeCompare(b.modifiedOn),
          multiple:1
      },
      },
      {
        title: 'Modified by',
        dataIndex: 'modifiedBy', 
        sorter:{ compare: (a, b) =>  a.modifiedBy.localeCompare(b.modifiedBy),
          multiple:1
      },
      },
      {
        title: 'Is Active',
        dataIndex: 'isActive', 
        sorter:{ compare: (a, b) =>  a.isActive.localeCompare(b.isActive),
          multiple:1
      },
      }, 
    ];
     
    const dataSource = [
      {
        key: '0',
        jid:'any1',
        emailID:'any2',
        education:'any3',
        jobPreference:'any4',
        experience:'any5',
        skills:'any6',
        expactedSalary:'any',
        createdBy : "06-08-2022 12:22PM",
        createdOn: "2022-12-2",
        modifiedBy : "06-08-2022 12:22PM",
        modifiedOn : "2022-12-2",
        isActive : "Incative",
      },  
    ]; 
        // Modal
        const [visible, setVisible] = useState(false);
        const modalHandle = () => {
          setVisible(true)
        };
    
         // Dropdown Select
         const { Option } = Select;
         const onChange = (value: string) => {
           console.log(`selected ${value}`);
         };
         const onSearch = (value: string) => {
           console.log('search:', value);
         };
  return (<>    

    <Layout className='custom_MainBackground'> 
      <div className="container-fluid p-0 d-flex justify-content-between customers_header">
        <h4>Job Profile</h4>
          <div>
        <Button type="primary" className='custom_activeInactive_btn' >Active</Button>
        <Button type="primary" className='custom_activeInactive_btn' >Inactive</Button>
        
<Button type="primary" className='custom_activeInactive_btn' onClick={modalHandle}>Add New</Button>
        </div> 
      </div>

      <div className="custom_TableWrapper container-fluid  ">
        <div className="d-flex">
        <label className='mt-1'><b>Search:</b></label><Input className='w-50 ms-2' />
        </div>
        <hr/>
        <Table className='custom_table'  rowSelection={{type: "checkbox",columnTitle:'Select',columnWidth:60}} columns={columns}  dataSource={dataSource}
          scroll={{ x: 1000 }}
          pagination={{ showSizeChanger:true, pageSizeOptions: [5,10,25,100] }} 
          />       
      </div> 
    </Layout>

    <Modal footer={false} title="Job Profile" centered visible={visible} onOk={() => setVisible(false)} onCancel={() => setVisible(false)} width={1400} >

    <Row className='Row-Height' gutter={[10,10]}> 
      <Col xs={24} sm={24} lg={12} span={12}> 
        <Row> 
          <Col span={24}>
            <label className='label1'>Job ID*</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Email *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Education *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'> Job Preferences *</label><Input   />
          </Col>
          <Col span={24}>
            <label className='label1'> Experience *</label><Input  />
          </Col> 
          <Col span={24}>
            <label className='label1'> Skills *</label><Input  />
          </Col> 
        </Row>
      </Col>
      <Col xs={24} sm={24} lg={12} span={12}>
      
        <Row> 
          <Col span={24}>
            <label className='label1'>Expacted Salary *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Created By *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Created On *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Modified By *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Modified On *</label><Input   />
          </Col>
          
          <Col span={24}>
            <label className='label1'>Status*</label> <br />
            <Select className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
              <Option value="active">Active</Option>
              <Option value="inactive">Inactive</Option>
            </Select>
          </Col>
          
        </Row>
      </Col>


      
    


      
      <Col span={24} className="mt-4 p-0">
      <Button type="primary" className='custom_activeInactive_btn' >Save</Button>
      <Button type="primary" className='custom_activeInactive_btn' >Cancel</Button>
    </Col>
      
    </Row>


</Modal>
    




    
    
  </>)
}



import {Button, Table, Layout, Input,Modal, Row, Col,Select, message, Upload,Radio  } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import type { UploadProps ,RadioChangeEvent } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useState } from 'react';
import '../../assets/css/common.css'


export  const SeekerPlanPayment = () => {

    interface DataType {
        key: React.Key; 
        paymentPlan:any;
        paymentId:any;
        planID:any;
        planDay:any;
        price:any;
        paymentGatewayUse:any;
        approvedByAdmin:any;
        createdBy : any;
        createdOn: any;
        modifiedBy : any;
        modifiedOn : any;
        isActive : any;

    }

        // paymentPlan:any;
        // paymentId:any;
        // planID:any;
        // planDay:any;
        // price:any;
        // paymentGatewayUse:any;
        // approvedByAdmin:any;
        // createdBy : any;
        // createdOn: any;
        // modifiedBy : any;
        // modifiedOn : any;
        // isActive : any;
 

    const columns: ColumnsType<DataType> = [
      {
        title: 'Payment Plan',
        dataIndex: 'paymentPlan', 
        sorter:{ compare: (a, b) =>  a.paymentPlan.localeCompare(b.paymentPlan),
          multiple:1
      },
      }, 
      {
        title: 'Payment ID',
        dataIndex: 'paymentId', 
        sorter:{ compare: (a, b) =>  a.paymentId.localeCompare(b.paymentId),
          multiple:1
      },
      onCell: (record, rowIndex) => {
        return {
          onClick: () => {
            modalHandle()
          }
        };
      },
      className:"hasFormHover"  
      }, 
       
      {
        title: 'Plan ID',
        dataIndex: 'planID', 
        sorter:{ compare: (a, b) =>  a.planID.localeCompare(b.planID),
          multiple:1
      },
      },
      {
        title: 'Plan Day',
        dataIndex: 'planDay', 
        sorter:{ compare: (a, b) =>  a.planDay.localeCompare(b.planDay),
          multiple:1
      },
      },
      {
        title: 'Price',
        dataIndex: 'price', 
        sorter:{ compare: (a, b) =>  a.price.localeCompare(b.price),
          multiple:1
      },
      },
      {
        title: 'Payment Gateway Use',
        dataIndex: 'paymentGatewayUse', 
        sorter:{ compare: (a, b) =>  a.paymentGatewayUse.localeCompare(b.paymentGatewayUse),
          multiple:1
      },
      },
      {
        title: 'Approved By Admin',
        dataIndex: 'approvedByAdmin', 
        sorter:{ compare: (a, b) =>  a.approvedByAdmin.localeCompare(b.approvedByAdmin),
          multiple:1
      },
      },



      {
        title: 'Created By',
        dataIndex: 'createdBy', 
        sorter:{ compare: (a, b) =>  a.createdBy.localeCompare(b.createdBy),
          multiple:1
      },
      },
      {
        title: 'Created on',
        dataIndex: 'createdOn', 
        sorter:{ compare: (a, b) =>  a.createdOn.localeCompare(b.createdOn),
          multiple:1
      },
      },
      {
        title: 'Modified On',
        dataIndex: 'modifiedOn', 
        sorter:{ compare: (a, b) =>  a.modifiedOn.localeCompare(b.modifiedOn),
          multiple:1
      },
      },
      {
        title: 'Modified by',
        dataIndex: 'modifiedBy', 
        sorter:{ compare: (a, b) =>  a.modifiedBy.localeCompare(b.modifiedBy),
          multiple:1
      },
      },
      {
        title: 'Is Active',
        dataIndex: 'isActive', 
        sorter:{ compare: (a, b) =>  a.isActive.localeCompare(b.isActive),
          multiple:1
      },
      }, 
    ];
     
    const dataSource = [
      {
        key: '0',
        paymentPlan : "Test Plan",
        paymentId : "Test ID 903465",
        planID : "Test plan ID e9i02", 
        planDay : "Test 05-3-23", 
        price : "$54",
        paymentGatewayUse : "Stripe",
        approvedByAdmin : "Yes",
        createdBy : "06-08-2022 12:22PM",
        createdOn: "2022-12-2",
        modifiedBy : "06-08-2022 12:22PM",
        modifiedOn : "2022-12-2",
        isActive : "Incative",
      },  
    ];
        // Modal
        const [visible, setVisible] = useState(false);
        const modalHandle = () => {
          setVisible(true)
        };
    
         // Dropdown Select
         const { Option } = Select;
         const onChange = (value: string) => {
           console.log(`selected ${value}`);
         };
         const onSearch = (value: string) => {
           console.log('search:', value);
         };
 

 

  return (<>    

    <Layout className='custom_MainBackground'>

      <div className="container-fluid p-0 d-flex justify-content-between customers_header">
        <h4>Plan Payment</h4>
          <div>
        <Button type="primary" className='custom_activeInactive_btn' >Active</Button>
        <Button type="primary" className='custom_activeInactive_btn' >Inactive</Button>
        
<Button type="primary" className='custom_activeInactive_btn' onClick={modalHandle}>Add New</Button>
        </div> 
      </div>

      <div className="custom_TableWrapper container-fluid  ">
        <div className="d-flex">
        <label className='mt-1'><b>Search:</b></label><Input className='w-50 ms-2' />
        </div>
        <hr/>
        <Table className='custom_table'  rowSelection={{type: "checkbox",columnTitle:'Select',columnWidth:60}} columns={columns}  dataSource={dataSource}
          scroll={{ x: 1000 }}
          pagination={{ showSizeChanger:true, pageSizeOptions: [5,10,25,100] }} 
          />       
      </div>

    </Layout>

    <Modal footer={false} title="Recruiter" centered visible={visible} onOk={() => setVisible(false)} onCancel={() => setVisible(false)} width={1400} >

    <Row className='Row-Height' gutter={[10,10]}> 
      <Col xs={24} sm={24} lg={12} span={12}> 
        <Row> 
          <Col span={24}>
            <label className='label1'>Payment Plan*</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Payment ID *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Plan ID *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'> Plan Day *</label><Input   />
          </Col>
          <Col span={24}>
            <label className='label1'> Price *</label><Input  />
          </Col> 
          <Col span={24}>
            <label className='label1'> Payment Gateway Use *</label><Input  />
          </Col> 
        </Row>
      </Col>
      <Col xs={24} sm={24} lg={12} span={12}>
      
        <Row> 
          <Col span={24}>
            <label className='label1'>Approved By Admin *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Created By *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Created On *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Modified By *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Modified On *</label><Input   />
          </Col>
          
          <Col span={24}>
            <label className='label1'>Status*</label> <br />
            <Select className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
              <Option value="active">Active</Option>
              <Option value="inactive">Inactive</Option>
            </Select>
          </Col>
          
        </Row>
      </Col>


      
    


      
      <Col span={24} className="mt-4 p-0">
      <Button type="primary" className='custom_activeInactive_btn' >Save</Button>
      <Button type="primary" className='custom_activeInactive_btn' >Cancel</Button>
    </Col>
      
    </Row>


</Modal>
    




    
    
  </>)
}


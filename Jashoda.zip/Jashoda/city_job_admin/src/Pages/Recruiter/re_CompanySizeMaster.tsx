
import {Button, Table, Layout, Input,Modal, Row, Col,Select, message, Upload,Radio  } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import type { UploadProps ,RadioChangeEvent } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useState } from 'react';
import '../../assets/css/common.css'
 
export  const ReCompanySizeMaster = () => {

    interface DataType {
        key: React.Key; 
        sizeID:any;
        sizeName:any; 
        createdBy : any;
        createdOn: any;
        modifiedBy : any;
        modifiedOn : any;
        isActive : any;

    }
      const columns: ColumnsType<DataType> = [
      {
        title: 'Size ID',
        dataIndex: 'sizeID', 
        sorter:{ compare: (a, b) =>  a.sizeID.localeCompare(b.sizeID),
          multiple:1
      },
      }, 
      {
        title: 'Size Name',
        dataIndex: 'sizeName', 
        sorter:{ compare: (a, b) =>  a.sizeName.localeCompare(b.sizeName),
          multiple:1
      },
       onCell: (record, rowIndex) => {
            return {
              onClick: () => {
                modalHandle()
              }
            };
          },
          className:"hasFormHover"   
      }, 
        



      {
        title: 'Created by',
        dataIndex: 'createdBy', 
        sorter:{ compare: (a, b) =>  a.createdBy.localeCompare(b.createdBy),
          multiple:1
      },
      },
      {
        title: 'Created on',
        dataIndex: 'createdOn', 
        sorter:{ compare: (a, b) =>  a.createdOn.localeCompare(b.createdOn),
          multiple:1
      },
      },
      {
        title: 'Modified On',
        dataIndex: 'modifiedOn', 
        sorter:{ compare: (a, b) =>  a.modifiedOn.localeCompare(b.modifiedOn),
          multiple:1
      },
      },
      {
        title: 'Modified by',
        dataIndex: 'modifiedBy', 
        sorter:{ compare: (a, b) =>  a.modifiedBy.localeCompare(b.modifiedBy),
          multiple:1
      },
      },
      {
        title: 'Is Active',
        dataIndex: 'isActive', 
        sorter:{ compare: (a, b) =>  a.isActive.localeCompare(b.isActive),
          multiple:1
      },
      }, 
    ];
     
    const dataSource = [
      {
        key: '0',
        sizeID : "Test Plan",
        sizeName : "Test ID 903465", 
        createdBy : "06-08-2022 12:22PM",
        createdOn: "2022-12-2",
        modifiedBy : "06-08-2022 12:22PM",
        modifiedOn : "2022-12-2",
        isActive : "Incative",
      },  
    ]; 
     // Modal
     const [visible, setVisible] = useState(false);
     const modalHandle = () => {
       setVisible(true)
     };
 
      // Dropdown Select
      const { Option } = Select;
      const onChange = (value: string) => {
        console.log(`selected ${value}`);
      };
      const onSearch = (value: string) => {
        console.log('search:', value);
      };
  return (<>    

    <Layout className='custom_MainBackground'>

      <div className="container-fluid p-0 d-flex justify-content-between customers_header">
        <h4>Company Size Master</h4>
        <div>
          <Button type="primary" className='custom_activeInactive_btn' >Active</Button>
          <Button type="primary" className='custom_activeInactive_btn' >Inactive</Button>
          
<Button type="primary" className='custom_activeInactive_btn' onClick={modalHandle}>Add New</Button>
        </div> 
      </div>

      <div className="custom_TableWrapper container-fluid  ">
        <div className="d-flex">
        <label className='mt-1'><b>Search:</b></label><Input className='w-50 ms-2' />
        </div>
        <hr/>
        <Table className='custom_table'  rowSelection={{type: "checkbox",columnTitle:'Select',columnWidth:60}} columns={columns}  dataSource={dataSource}
          scroll={{ x: 1000 }}
          pagination={{ showSizeChanger:true, pageSizeOptions: [5,10,25,100] }} 
          />       
      </div>

    </Layout>
    <Modal footer={false} title="Company Size" centered visible={visible} onOk={() => setVisible(false)} onCancel={() => setVisible(false)} width={700} >

<Row className='Row-Height' gutter={[10,10]}> 
  
  <Col >
   
    <Row>  
      <Col span={24}>
        <label className='label1'>Size ID *</label><Input />
      </Col>
      <Col span={24}>
        <label className='label1'>Size Name *</label><Input />
      </Col>
      <Col span={24}>
        <label className='label1'>Created By *</label><Input />
      </Col>
      <Col span={24}>
        <label className='label1'>Created On *</label><Input />
      </Col>
      <Col span={24}>
        <label className='label1'>Modified By *</label><Input />
      </Col>
      <Col span={24}>
        <label className='label1'>Modified On *</label><Input   />
      </Col>
      
      <Col span={24}>
        <label className='label1'>Status*</label> <br />
        <Select className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
          <Option value="active">Active</Option>
          <Option value="inactive">Inactive</Option>
        </Select>
      </Col>
      
    </Row>
  </Col>


  



  
  <Col span={24} className="mt-4 p-0">
  <Button type="primary" className='custom_activeInactive_btn' >Save</Button>
  <Button type="primary" className='custom_activeInactive_btn' >Cancel</Button>
</Col>
  
</Row>


</Modal>




    
    
  </>)
}


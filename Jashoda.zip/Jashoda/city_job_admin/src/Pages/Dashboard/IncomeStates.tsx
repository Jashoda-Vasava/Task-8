import React from 'react'
import { Column,Pie } from '@ant-design/plots';

export default function IncomeStates() {
     // chart 1
     const data = [
        {
          type: 'Jan',
          sales: 38,
        },
        {
          type: 'Feb',
          sales: 52,
        },
        {
          type: 'Mar',
          sales: 61,
        },
        {
          type: 'Apr',
          sales: 145,
        },
        {
          type: 'May',
          sales: 48,
        },
        {
          type: 'Jun',
          sales: 38,
        },
        {
          type: 'Jul',
          sales: 68,
        },
        {
          type: 'Aug',
          sales: 128,
        },
        {
          type: 'Sept',
          sales: 58,
        },
        {
          type: 'Oct',
          sales: 12,
        },
        {
          type: 'Nov',
          sales: 88,
        },
        {
          type: 'Dec',
          sales: 35,
        },
      ];
      const config = {
        data,
        xField: 'type',
        yField: 'sales',
        color:'#fc8579',
        label: {
           
          style: {
            fill: '#FFFFFF',
            opacity: 0.6,
  
          },
        },
        xAxis: {
          label: {
            autoHide: true,
            autoRotate: false,
          },
        },
        meta: {
          type: {
            alias: 'Jeet',
          },
          sales: {
            alias: 'as',
          },
        },
      };
  return (
     
      <Column {...config} /> 
    
  )
}

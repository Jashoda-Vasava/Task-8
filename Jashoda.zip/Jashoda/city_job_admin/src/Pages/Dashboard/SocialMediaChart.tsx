import './Dashboard.css';
import {Button, Table, Layout, Input,Modal,Row,Col,Select,Menu, Dropdown,   } from 'antd';
import { MoreOutlined } from '@ant-design/icons';  
import { Column,Pie } from '@ant-design/plots';


export const SocialMediaChart  = () => {


    const data = [
        {
          type: 'Insta',
          value: 27,
        },
        {
          type: 'FB',
          value: 25,
        },
        {
          type: 'Twitter',
          value: 18,
        },
        {
          type: 'Youtube',
          value: 15,
        },
        {
          type: 'Google',
          value: 10,
        },
         
      ];
      const config = {
        appendPadding: 10,
        data,
        angleField: 'value',
        colorField: 'type',
        radius: 1,
        innerRadius: 0.6,
        label: {
          type: 'inner',
          offset: '-50%',
          content: '{value}',
          style: {
            textAlign: 'center',
            fontSize: 14,
          },
        },
        interactions: [
          {
            type: 'element-selected',
          },
          {
            type: 'element-active',
          },
        ],
        statistic: {
          title: false,
          content: {
            style: {
              whiteSpace: 'pre-wrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            },
            content: '',
          },
        },
      };
      return <Pie  {...config} />;
}
import './Dashboard.css'
import '../../assets/css/common.css'; 
import {Button, Table, Layout, Input,Modal,Row,Col,Select,Menu, Dropdown,Timeline,   } from 'antd';
import { MoreOutlined } from '@ant-design/icons';  
import type { ColumnsType } from 'antd/es/table';
import { Column,Pie } from '@ant-design/plots';
import { SocialMediaChart } from './SocialMediaChart';
import IncomeStates from './IncomeStates';


export const Dashboard  = () => {


      // Dropdown Select
      const { Option } = Select;
      const onChange = (value: string) => {
        console.log(`selected ${value}`);
      };
      const onSearch = (value: string) => {
        console.log('search:', value);
      };

    //   Dropdown Menu
    const menu = (
        <Menu>
          <Menu.Item>
            <a target="_blank" rel="noopener noreferrer" href="http://www.alipay.com/">
              1st menu item
            </a>
          </Menu.Item>
          <Menu.Item>
            <a target="_blank" rel="noopener noreferrer" href="http://www.taobao.com/">
              2nd menu item
            </a>
          </Menu.Item>
          <Menu.Item>
            <a target="_blank" rel="noopener noreferrer" href="http://www.tmall.com/">
              3rd menu item
            </a>
          </Menu.Item>
        </Menu>
      ); 
    const menu2 = (
      <Menu>
        <Menu.Item>
          <a target="_blank" rel="noopener noreferrer" href="http://www.alipay.com/">
            Settings
          </a>
        </Menu.Item>
        <Menu.Item>
          <a target="_blank" rel="noopener noreferrer" href="http://www.taobao.com/">
            Move
          </a>
        </Menu.Item>
        <Menu.Item>
          <a target="_blank" rel="noopener noreferrer" href="http://www.tmall.com/">
           Remove
          </a>
        </Menu.Item>
      </Menu>
    );


    // Table of Recent Orders

    interface DataType {
      key: React.Key;
      no:number;
      status:any;
      country:any;
      customer:any;
      date:any;
      total:any;
      
    }


  const columns: ColumnsType<DataType> = [
    {
      title: 'No.',
      dataIndex: 'no',
       
    },
    {
        title: 'Status',
        dataIndex: 'status',
       
    },
    {
        title: 'Co.',
        dataIndex: 'country',
         
    },
    {
        title: 'Customer',
        dataIndex: 'customer',
         
    },
    {
        title: 'Date',
        dataIndex: 'date',
        
    },
    {
        title: 'Total',
        dataIndex: 'total',
         
    },

    
     
   

  ];

  const dataSource = [
    {
      key: '0',
      no:1,
      status:'Panding',
      country:"india",
      customer:"David Schiwmmer",
      date:"05/02/2017",
      total:"$4507"  
    },
    {
      key: '0',
      no:1,
      status:'Panding',
      country:"india",
      customer:"David Schiwmmer",
      date:"05/02/2017",
      total:"$4507"  
    },
    {
      key: '0',
      no:1,
      status:'Panding',
      country:"india",
      customer:"David Schiwmmer",
      date:"05/02/2017",
      total:"$4507"  
    },
    {
      key: '0',
      no:1,
      status:'Panding',
      country:"india",
      customer:"David Schiwmmer",
      date:"05/02/2017",
      total:"$4507"  
    },
    {
      key: '0',
      no:1,
      status:'Panding',
      country:"india",
      customer:"David Schiwmmer",
      date:"05/02/2017",
      total:"$4507"  
    },
    {
      key: '0',
      no:1,
      status:'Panding',
      country:"india",
      customer:"David Schiwmmer",
      date:"05/02/2017",
      total:"$4507"  
    },
    {
      key: '0',
      no:1,
      status:'Panding',
      country:"india",
      customer:"David Schiwmmer",
      date:"05/02/2017",
      total:"$4507"  
    },
    {
      key: '0',
      no:1,
      status:'Panding',
      country:"india",
      customer:"David Schiwmmer",
      date:"05/02/2017",
      total:"$4507"  
    },
    {
      key: '0',
      no:1,
      status:'Panding',
      country:"india",
      customer:"David Schiwmmer",
      date:"05/02/2017",
      total:"$4507"  
    },
    {
      key: '0',
      no:1,
      status:'Panding',
      country:"india",
      customer:"David Schiwmmer",
      date:"05/02/2017",
      total:"$4507"  
    },
    
  ];
  
    return (<>

    <Layout className='custom_MainBackground '>

      {/* <div className="container p-0 d-flex justify-content-between customers_header">
        <h4>Dashboard</h4>

        <div className='d-flex justify-content-between'>
        <Select placeholder="7th Oct 2022" className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
            <Option value="India">Latest Hat</Option>
        </Select>    
        <Button type="primary" className='custom_activeInactive_btn' >Export</Button>
        </div>
      </div>

       

      <div className="container p-0">
        <Row gutter={10}>
            <Col sm={24} xs={24} lg={8} span={8}> 
                <div className='ContentWrap1 p-3 '> 
                    <div className="d-flex  justify-content-between ">
                            <p>Total Sells</p>
                            <Dropdown overlay={menu}>
                                <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                                 <MoreOutlined className="black" />
                                </a>
                            </Dropdown>
                    </div>

                    <div className=''>
                         <Row className='mt-4'>
                          <Col span={12}>
                            <h3 className='text-truncate'>$2134.00</h3>
                          </Col>
                          <Col span={12}>
                          <div className='text-end'>
                            <p className='downfallArrow'>&#8600; 34.05%</p>
                            <p className='compareText'>Compared to April 2021</p>
                          </div>
                          </Col>
                         </Row>
                    </div>
                </div> 
            </Col>
            <Col sm={24} xs={24} lg={8} span={8}> 
                <div className='ContentWrap1 p-3 '> 
                    <div className="d-flex  justify-content-between ">
                            <p>Avarage Order Value</p>
                            <Dropdown overlay={menu}>
                                <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                                 <MoreOutlined className="black" />
                                </a>
                            </Dropdown>
                    </div>

                    <div className=''>
                         <Row className='mt-4'>
                          <Col span={12}>
                            <h3 className='text-truncate'>$2134.00</h3>
                          </Col>
                          <Col span={12}>
                          <div className='text-end'>
                          <p className='growthArrow'>&#8599; 34.05%</p>
                            <p className='compareText'>Compared to April 2021</p>
                          </div>
                          </Col>
                         </Row>
                    </div>
                </div> 
            </Col>
            <Col sm={24} xs={24} lg={8} span={8}> 
                <div className='ContentWrap1 p-3 '> 
                    <div className="d-flex  justify-content-between ">
                            <p>Total Orders</p>
                            <Dropdown overlay={menu}>
                                <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                                 <MoreOutlined className="black" />
                                </a>
                            </Dropdown>
                    </div>

                    <div className=''>
                         <Row className='mt-4'>
                          <Col span={12}>
                            <h3 className='text-truncate'>$2134.00</h3>
                          </Col>
                          <Col span={12}>
                          <div className='text-end'>
                            <p className='downfallArrow'>&#8600; 34.05%</p>
                            <p className='compareText'>Compared to April 2021</p>
                          </div>
                          </Col>
                         </Row>
                    </div>
                </div> 
            </Col>

            
            
        </Row> 

        <Row gutter={10}>
          <Col sm={24} xs={24} lg={7} span={7}>
            <div className="ContentWrap2 scrollX p-3">
              <Row gutter={10}>
              <Col span={24}>
                <div className="d-flex  justify-content-between ">
                      <h6>Active User</h6>
                      <Dropdown overlay={menu2}>
                          <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                            <MoreOutlined className="black" />
                          </a>
                      </Dropdown>
                </div>
              </Col>

              <Col sm={10} xs={24} md={24} span={24}>
                <div className='Number-container h-100'>
                  <h1>148</h1>
                </div>
              </Col> 
               
              <Col sm={14} xs={24} md={24} span={24}>
                <table className='w-100 mt-1'  > 
                  <tr>
                  <th>Active pages</th> 
                  <th>Users</th>
                  </tr>

                  <tr className='rowBottom'>
                    <td><p>/products/brandix-z4</p></td>
                    <td><p>20</p></td>
                  </tr>
                  <tr className='rowBottom'>
                    <td><p>/products/brandix-z4</p></td>
                    <td><p>20</p></td>
                  </tr>
                  <tr className='rowBottom'>
                    <td><p>/products/brandix-z4</p></td>
                    <td><p>20</p></td>
                  </tr>
                  <tr className='rowBottom'>
                    <td><p>/products/brandix-z4</p></td>
                    <td><p>20</p></td>
                  </tr>  
                </table>
               </Col>
               </Row>
            </div>
          </Col>


          <Col sm={24} xs={24} lg={17} span={17}>
            <div className="ContentWrap2 p-3">
                <Row><Col span={24}><h6>Income Statictics</h6></Col></Row>
                <Row>
                  <Col span={24}>
                  <IncomeStates/>
                     
                  </Col>
                </Row>
            </div>
          </Col>
        </Row>  

        <Row gutter={10}>
          <Col sm={24} xs={24} lg={17} span={17}>
            <div className="ContentWrap3 scrollX p-3">
                  <Col span={24}>
                    <div className="d-flex  justify-content-between ">
                          <h6>Recent orders</h6>
                          <Dropdown overlay={menu2}>
                              <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                                <MoreOutlined className="black" />
                              </a>
                          </Dropdown>
                    </div>
                  </Col>

                  <Table className='configuration_table mt-2'   columns={columns}  dataSource={dataSource}
                      pagination={{ showSizeChanger:true, pageSizeOptions: [5,10,25,100],defaultPageSize:5  }} 
                      />
                  
            </div>
          </Col>

          <Col sm={24} xs={24} lg={7} span={7}>
            <div className="ContentWrap3 scrollX p-3">
                  <Col span={24}>
                    <div className="d-flex  justify-content-between ">
                          <h6>Sales by traffic source</h6>
                          <Dropdown overlay={menu2}>
                              <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                                <MoreOutlined className="black" />
                              </a>
                          </Dropdown>
                    </div>
                  </Col>
              <SocialMediaChart/>
            </div>
          </Col>
        </Row> 
        
        <Row gutter={10}>
          <Col sm={24} xs={24} lg={12} span={12}>
              <div className="ContentWrap2 scrollX p-3">
              <Col className='mb-3' span={24}>
                <div className="d-flex  justify-content-between ">
                      <h6>Recent activity</h6>
                      <Dropdown overlay={menu2}>
                          <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                            <MoreOutlined className="black" />
                          </a>
                      </Dropdown>
                </div>
              </Col>

              <Timeline>
                <Timeline.Item> <b className='timelineHeading'>Yesterday</b> <p className='timelineContent'>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vel corrupti id quia praesentium sint voluptas doloribus, <a href='www.google.com'>perferendis ipsam eius</a> distinctio.</p> </Timeline.Item>  
                <Timeline.Item> <b className='timelineHeading'>5 Days Ago</b> <p className='timelineContent'>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vel corrupti id quia praesentium sint voluptas doloribus, <a href='www.google.com'>perferendis ipsam eius</a> distinctio.</p> </Timeline.Item>  
                <Timeline.Item> <b className='timelineHeading'>10 Days Ago</b> <p className='timelineContent'>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vel corrupti id quia praesentium sint voluptas doloribus, <a href='www.google.com'>perferendis ipsam eius</a> distinctio.</p> </Timeline.Item>  
                
                 
                
              </Timeline>
              </div>
          </Col>
          <Col sm={24} xs={24} lg={12} span={12}>
              <div className="ContentWrap2 scrollX p-3">
                <Col className='mb-3' span={24}>
                <div className="d-flex  justify-content-between ">
                      <h6>Recent reviews</h6>
                      <Dropdown overlay={menu2}>
                          <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                            <MoreOutlined className="black" />
                          </a>
                      </Dropdown>
                </div>
                </Col>
                <hr />

                 
                <Row>
                  <Col xs={5} sm={2} lg={2} span={2}><img src="/images/customers/reviewImg.jpg" className='img-fluid'/></Col>
                  <Col xs={19} sm={19} lg={12} span={12}><p className='productName'>Wiper Blades Brandix WL2</p> <p className='reviewBy'>Reviewed by Ryan Ford</p></Col>
                  <Col xs={20} sm={20} lg={10} span={10} className="text-lg-end"><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9734;</a></Col>  
                </Row>
                <hr />
                <Row>
                  <Col xs={5} sm={2} lg={2} span={2}><img src="/images/customers/reviewImg.jpg" className='img-fluid'/></Col>
                  <Col xs={19} sm={19} lg={12} span={12}><p className='productName'>Wiper Blades Brandix WL2</p> <p className='reviewBy'>Reviewed by Ryan Ford</p></Col>
                  <Col xs={20} sm={20} lg={10} span={10} className="text-lg-end"><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9734;</a></Col>  
                </Row>
                <hr />
                <Row>
                  <Col xs={5} sm={2} lg={2} span={2}><img src="/images/customers/reviewImg.jpg" className='img-fluid'/></Col>
                  <Col xs={19} sm={19} lg={12} span={12}><p className='productName'>Wiper Blades Brandix WL2</p> <p className='reviewBy'>Reviewed by Ryan Ford</p></Col>
                  <Col xs={20} sm={20} lg={10} span={10} className="text-lg-end"><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9734;</a></Col>  
                </Row>
                <hr />
                <Row>
                  <Col xs={5} sm={2} lg={2} span={2}><img src="/images/customers/reviewImg.jpg" className='img-fluid'/></Col>
                  <Col xs={19} sm={19} lg={12} span={12}><p className='productName'>Wiper Blades Brandix WL2</p> <p className='reviewBy'>Reviewed by Ryan Ford</p></Col>
                  <Col xs={20} sm={20} lg={10} span={10} className="text-lg-end"><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9733;</a><a className='reviewStar'>&#9734;</a></Col>  
                </Row>
                <hr />
                
              

                
              </div>
          </Col>
           
        </Row>
      </div>
      */}
    </Layout>
    
    </>)
}
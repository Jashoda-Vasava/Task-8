import {
  Button,
  Table,
  Layout,
  Input,
  Modal,
  Row,
  Col,
  Select,
  message,
  Upload,
  Radio,
} from "antd";
import { UploadOutlined } from "@ant-design/icons";
import type { UploadProps, RadioChangeEvent } from "antd";
import type { ColumnsType } from "antd/es/table";
import { useState, useEffect } from "react";
import "../../assets/css/common.css";
import { APIRequest, SAVE_SKILL, GET_SKILL } from "../../api";
import * as Yup from "yup";
import swal from "sweetalert";
import { useFormik } from "formik";

export const SkillMaster = () => {
  const [functiondata, Setfunctiondata] = useState([]);
  const [visible, setVisible] = useState(false);
  const [page, Setpage] = useState(0);
  const [pagesize, Setpagesize] = useState(10);
  const [totaldata, Settotaldata] = useState(10);

  useEffect(() => {
    new APIRequest.Builder()
      .post()
      .setReqId(GET_SKILL)
      .jsonParams({
        isactive: "Y",
        pageable: {
          pageno: page,
          pagesize: pagesize,
        },
      })
      .reqURL("api/v1/master/getskills")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }, [visible, page, pagesize]);

  const skillform = useFormik({
    initialValues: {
      name: "",
      isactive: "",
    },
    validationSchema: Yup.object().shape({
      name: Yup.string().required("Enter Skill"),
      isactive: Yup.string().required("Select"),
    }),
    onSubmit: (values) => {
      new APIRequest.Builder()
        .post()
        .setReqId(SAVE_SKILL)
        .jsonParams(values)
        .reqURL("api/v1/master/save_skills")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
    },
  });

  const onResponse = (response: any, reqId: any) => {
    switch (reqId) {
      case SAVE_SKILL:
        if (response.data.issuccess) {
          swal(`${response.data.massage}`, "", "success").then((value) => {
            setVisible(false);
          });
        } else {
          swal(`${response.data.massage}`, "", "warning");
        }
        break;
      case GET_SKILL:
        Setfunctiondata(response.data.data);
        Settotaldata(response.data.pageable.totalItems);
        break;
      default:
        break;
    }
  };

  const onError = (response: any, reqId: any) => {
    switch (reqId) {
      case SAVE_SKILL:
        swal(`${response.data.massage}`, "", "warning");
        break;
      case GET_SKILL:
        console.log(response.data);
        break;
      default:
        break;
    }
  };

  interface DataType {
    key: React.Key;
    skillID: any;
    skillName: any;
    createdBy: any;
    createdOn: any;
    modifiedBy: any;
    modifiedOn: any;
    isActive: any;
  }
  const columns: ColumnsType<DataType> = [
    {
      title: "Skill ID",
      dataIndex: "skillID",
      sorter: {
        compare: (a, b) => a.skillID.localeCompare(b.skillID),
        multiple: 1,
      },
    },
    {
      title: "Skill Name",
      dataIndex: "skillName",
      sorter: {
        compare: (a, b) => a.skillName.localeCompare(b.skillName),
        multiple: 1,
      },
      onCell: (record, rowIndex) => {
        return {
          onClick: () => {
            modalHandle();
          },
        };
      },
      className: "hasFormHover",
    },
    {
      title: "Created by",
      dataIndex: "createdBy",
      sorter: {
        compare: (a, b) => a.createdBy.localeCompare(b.createdBy),
        multiple: 1,
      },
    },
    {
      title: "Created on",
      dataIndex: "createdOn",
      sorter: {
        compare: (a, b) => a.createdOn.localeCompare(b.createdOn),
        multiple: 1,
      },
    },
    {
      title: "Modified On",
      dataIndex: "modifiedOn",
      sorter: {
        compare: (a, b) => a.modifiedOn.localeCompare(b.modifiedOn),
        multiple: 1,
      },
    },
    {
      title: "Modified by",
      dataIndex: "modifiedBy",
      sorter: {
        compare: (a, b) => a.modifiedBy.localeCompare(b.modifiedBy),
        multiple: 1,
      },
    },
    {
      title: "Is Active",
      dataIndex: "isActive",
      sorter: {
        compare: (a, b) => a.isActive.localeCompare(b.isActive),
        multiple: 1,
      },
    },
  ];

  const dataSource = functiondata.map(
    (
      item: {
        id: any;
        name: any;
        createdby: any;
        createdon: any;
        modifiedby: any;
        modifiedon: any;
        isactive: string;
      },
      id: any
    ) => {
      return {
        key: id,
        skillID: item.id,
        skillName: item.name,
        createdBy: item.createdby ?? "",
        createdOn: item.createdon ?? "",
        modifiedBy: item.modifiedby ?? "",
        modifiedOn: item.modifiedon ?? "",
        isActive: item.isactive === "Y" ? "Active" : "In-Active",
      };
    }
  );

  // Modal

  const modalHandle = () => {
    setVisible(true);
  };

  // Dropdown Select
  const { Option } = Select;
  const onChange = (value: string) => {
    skillform.setFieldValue("isactive", value);
  };
  const onSearch = (value: string) => {
    console.log("search:", value);
  };
  return (
    <>
      <Layout className="custom_MainBackground">
        <div className="container-fluid p-0 d-flex justify-content-between customers_header">
          <h4>Skill Master</h4>
          <div>
            <Button type="primary" className="custom_activeInactive_btn">
              Active
            </Button>
            <Button type="primary" className="custom_activeInactive_btn">
              Inactive
            </Button>
            <Button
              type="primary"
              className="custom_activeInactive_btn"
              onClick={modalHandle}
            >
              Add New
            </Button>
          </div>
        </div>

        <div className="custom_TableWrapper container-fluid  ">
          <div className="d-flex">
            <label className="mt-1">
              <b>Search:</b>
            </label>
            <Input className="w-50 ms-2" />
          </div>
          <hr />
          <Table
            className="custom_table"
            rowSelection={{
              type: "checkbox",
              columnTitle: "Select",
              columnWidth: 60,
            }}
            columns={columns}
            dataSource={dataSource}
            scroll={{ x: 1000 }}
            pagination={{
              total: totaldata,
              showSizeChanger: true,
              pageSizeOptions: [5, 10, 25, 100],
              onChange: (page, pagesize) => {
                Setpage(page - 1);
                Setpagesize(pagesize);
              },
            }}
          />
        </div>
      </Layout>
      <Modal
        footer={false}
        title="Skill Master"
        centered
        visible={visible}
        onOk={() => setVisible(false)}
        onCancel={() => setVisible(false)}
        width={700}
      >
        <Row className="Row-Height" gutter={[10, 10]}>
        <form onSubmit={skillform.handleSubmit}>
          <Col>
            <Row>              
              <Col span={24}>
                <label className="label1">Skill Name *</label>
                <Input
                  name="name"
                  id="name"
                  onChange={skillform.handleChange}
                  value={skillform.values.name}
                />
                {skillform.touched.name && skillform.errors.name ? (
                  <span className="error">{skillform.errors.name}</span>
                ) : null}
              </Col>
             

              <Col span={24}>
                <label className="label1">Status*</label> <br />
                <Select
                  className="w-100"
                  showSearch
                  optionFilterProp="children"
                  onChange={onChange}
                  onSearch={onSearch}
                  filterOption={(input, option) =>
                    (option!.children as unknown as string)
                      .toLowerCase()
                      .includes(input.toLowerCase())
                  }
                >
                  <Option value="Y">Active</Option>
                  <Option value="N">Inactive</Option>
                </Select>
                {skillform.touched.isactive && skillform.errors.isactive ? (
                  <span className="error">{skillform.errors.isactive}</span>
                ) : null}
              </Col>
            </Row>
          </Col>

          <Col span={24} className="mt-4 p-0">
            <Button type="primary"  htmlType="submit" className="custom_activeInactive_btn">
              Save
            </Button>
            <Button type="primary" className="custom_activeInactive_btn">
              Cancel
            </Button>
          </Col>
          </form>
        </Row>
      </Modal>
    </>
  );
};

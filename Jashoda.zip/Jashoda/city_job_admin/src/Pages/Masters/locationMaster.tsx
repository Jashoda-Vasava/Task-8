import {
  Button,
  Table,
  Layout,
  Input,
  Modal,
  Row,
  Col,
  Select,
  message,
  Upload,
  Radio,
} from "antd";
import { UploadOutlined } from "@ant-design/icons";
import type { UploadProps, RadioChangeEvent } from "antd";
import type { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";
import "../../assets/css/common.css";
import { useFormik } from "formik";
import { APIRequest, SAVE_LOCATION, GET_LOCATION } from "../../api";
import * as Yup from "yup";
import swal from "sweetalert";

export const LocationMaster = () => {
  const [location, Setlocation] = useState([]);
  const [visible, setVisible] = useState(false);

  const [page, Setpage] = useState(0);
  const [pagesize, Setpagesize] = useState(10);
  const [totaldata, Settotaldata] = useState(10);

  useEffect(() => {
    new APIRequest.Builder()
      .post()
      .setReqId(GET_LOCATION)
      .jsonParams({
        isactive: "Y",
        pageable: {
          pageno: page,
          pagesize: pagesize,
        },
      })
      .reqURL("api/v1/master/get_location")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
  }, [visible, page, pagesize]);

  const locationform = useFormik({
    initialValues: {
      name: "",
      isactive: "",
    },
    validationSchema: Yup.object().shape({
      name: Yup.string().required("Enter Location Name"),
      isactive: Yup.string().required("Select"),
    }),
    onSubmit: (values) => {
      new APIRequest.Builder()
        .post()
        .setReqId(SAVE_LOCATION)
        .jsonParams(values)
        .reqURL("api/v1/master/save_location")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
    },
  });

  const onResponse = (response: any, reqId: any) => {
    switch (reqId) {
      case SAVE_LOCATION:
        if (response.data.issuccess) {
          swal(`${response.data.massage}`, "", "success").then((value) => {
            setVisible(false);
          });
        } else {
          swal(`${response.data.massage}`, "", "warning");
        }
        break;
      case GET_LOCATION:
        Setlocation(response.data.data);
        Settotaldata(response.data.pageable.totalItems);
        break;
      default:
        break;
    }
  };

  const onError = (response: any, reqId: any) => {
    switch (reqId) {
      case SAVE_LOCATION:
        swal(`${response.data.massage}`, "", "warning");
        break;
      case GET_LOCATION:
        console.log(response.data);
        break;
      default:
        break;
    }
  };

  interface DataType {
    key: React.Key;
    locationID: any;
    locationName: any;
    createdBy: any;
    createdOn: any;
    modifiedBy: any;
    modifiedOn: any;
    isActive: any;
  }
  const columns: ColumnsType<DataType> = [
    {
      title: "Location ID",
      dataIndex: "locationID",
      sorter: {
        compare: (a, b) => a.locationID.localeCompare(b.locationID),
        multiple: 1,
      },
    },
    {
      title: "Location Name",
      dataIndex: "locationName",
      sorter: {
        compare: (a, b) => a.locationName.localeCompare(b.locationName),
        multiple: 1,
      },
      onCell: (record, rowIndex) => {
        return {
          onClick: () => {
            modalHandle();
          },
        };
      },
      className: "hasFormHover",
    },
    {
      title: "Created by",
      dataIndex: "createdBy",
      sorter: {
        compare: (a, b) => a.createdBy.localeCompare(b.createdBy),
        multiple: 1,
      },
    },
    {
      title: "Created on",
      dataIndex: "createdOn",
      sorter: {
        compare: (a, b) => a.createdOn.localeCompare(b.createdOn),
        multiple: 1,
      },
    },
    {
      title: "Modified On",
      dataIndex: "modifiedOn",
      sorter: {
        compare: (a, b) => a.modifiedOn.localeCompare(b.modifiedOn),
        multiple: 1,
      },
    },
    {
      title: "Modified by",
      dataIndex: "modifiedBy",
      sorter: {
        compare: (a, b) => a.modifiedBy.localeCompare(b.modifiedBy),
        multiple: 1,
      },
    },
    {
      title: "Is Active",
      dataIndex: "isActive",
      sorter: {
        compare: (a, b) => a.isActive.localeCompare(b.isActive),
        multiple: 1,
      },
    },
  ];

  const dataSource = location.map(
    (
      item: {
        id: any;
        name: any;
        createdby: any;
        createdon: any;
        modifiedby: any;
        modifiedon: any;
        isactive: string;
      },
      id: any
    ) => {
      return {
        key: id,
        locationID: item.id,
        locationName: item.name,
        createdBy: item.createdby ?? "",
        createdOn: item.createdon ?? "",
        modifiedBy: item.modifiedby ?? "",
        modifiedOn: item.modifiedon ?? "",
        isActive: item.isactive === "Y" ? "Active" : "In-Active",
      };
    }
  );

  // Modal

  const modalHandle = () => {
    setVisible(true);
  };

  // Dropdown Select
  const { Option } = Select;
  const onChange = (value: string) => {
    locationform.setFieldValue("isactive", value);
  };
  const onSearch = (value: string) => {
    console.log("search:", value);
  };
  return (
    <>
      <Layout className="custom_MainBackground">
        <div className="container-fluid p-0 d-flex justify-content-between customers_header">
          <h4>Location Master</h4>
          <div>
            <Button type="primary" className="custom_activeInactive_btn">
              Active
            </Button>
            <Button type="primary" className="custom_activeInactive_btn">
              Inactive
            </Button>
            <Button
              type="primary"
              className="custom_activeInactive_btn"
              onClick={modalHandle}
            >
              Add New
            </Button>
          </div>
        </div>

        <div className="custom_TableWrapper container-fluid  ">
          <div className="d-flex">
            <label className="mt-1">
              <b>Search:</b>
            </label>
            <Input className="w-50 ms-2" onChange={(e : any) => console.log(e.target.value)} />
          </div>
          <hr />
          <Table
            className="custom_table"
            rowSelection={{
              type: "checkbox",
              columnTitle: "Select",
              columnWidth: 60,
            }}
            columns={columns}
            dataSource={dataSource}
            scroll={{ x: 1000 }}
            pagination={{
              total: totaldata,
              showSizeChanger: true,
              pageSizeOptions: [5, 10, 25, 100],
              onChange: (page, pagesize) => {
                Setpage(page - 1);
                Setpagesize(pagesize);
              },
            }}
          />
        </div>
      </Layout>

      <Modal
        footer={false}
        title="Location Master"
        centered
        visible={visible}
        onOk={() => setVisible(false)}
        onCancel={() => setVisible(false)}
        width={700}
      >
        <Row className="Row-Height" gutter={[10, 10]}>
          <form onSubmit={locationform.handleSubmit}>
            <Col>
              <Row>               
                <Col span={24}>
                  <label className="label1">Location Name *</label>
                  <Input
                    name="name"
                    id="name"
                    onChange={locationform.handleChange}
                    value={locationform.values.name}
                  />
                  {locationform.touched.name && locationform.errors.name ? (
                    <span className="error">{locationform.errors.name}</span>
                  ) : null}
                </Col>              

                <Col span={24}>
                  <label className="label1">Status*</label> <br />
                  <Select
                    className="w-100"
                    showSearch
                    optionFilterProp="children"
                    onChange={onChange}
                    onSearch={onSearch}
                    filterOption={(input, option) =>
                      (option!.children as unknown as string)
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                  >
                    <Option value="Y">Active</Option>
                    <Option value="N">Inactive</Option>
                  </Select>
                  {locationform.touched.isactive &&
                  locationform.errors.isactive ? (
                    <span className="error">
                      {locationform.errors.isactive}
                    </span>
                  ) : null}
                </Col>
              </Row>
            </Col>

            <Col span={24} className="mt-4 p-0">
              <Button
                type="primary"
                htmlType="submit"
                className="custom_activeInactive_btn"
              >
                Save
              </Button>
              <Button type="primary" className="custom_activeInactive_btn">
                Cancel
              </Button>
            </Col>
          </form>
        </Row>
      </Modal>
    </>
  );
};



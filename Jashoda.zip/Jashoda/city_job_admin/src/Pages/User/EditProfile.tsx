import { Button, Layout, Input } from "antd";
import { swap, useFormik } from "formik";
import "../../assets/css/common.css";
import * as Yup from "yup";
import { useSelector } from "react-redux";
import { APIRequest, USER_PROFILE_UPDATE } from "../../api";
import swal from "sweetalert";

export const EditProfile = () => {

  const user = useSelector(state  => state as any)
console.log(user)


  const editprofile = useFormik({
    enableReinitialize: true,
    initialValues: {
      emailid: user.user.emailid ?? "",
      firstname: user.user.firstname ??   "",
      lastname:  user.user.lastname ??"",
      mobilenumber: "",
      mode: "update",
    },
    validationSchema: Yup.object().shape({
      emailid:Yup.string().email("Invalid email address").required("Please enter email"),
      firstname:Yup.string().required("Enter First Name"),
      lastname:Yup.string().required("Enter Last Name"),
      mobilenumber :Yup.string().length(10, "Mobile Number 10 Digit Required").required("Please Enter Mobile Number").matches(/^[0-9]+$/, "Must be only digits")
    }),
    onSubmit: (values) => {
      new APIRequest.Builder()
        .post()
        .setReqId(USER_PROFILE_UPDATE)
        .jsonParams(values)
        .reqURL("api/v1/user/signup")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
    },
  });

  const onResponse = (response: any, reqId: any) => {
    switch (reqId) {
      case USER_PROFILE_UPDATE:
        if (response.data.issuccess) {
          swal(`${response.data.massage}`, "", "success");
        } else {
          swal(`${response.data.massage}`, "", "warning");
        }
        break;
      default:
        break;
    }
  };

  const onError = (response: any, reqId: any) => {
    switch (reqId) {
      case USER_PROFILE_UPDATE:
        swal(`${response.data.massage}`, "", "warning");
        break;
      default:
        break;
    }
  };

  return (
    <>
      <Layout className="custom_MainBackground">
        <div className="container p-0 d-flex justify-content-between customers_header">
          <h4>Edit Profile</h4>
        </div>
        <form onSubmit={editprofile.handleSubmit}>
          {" "}
          <div className="custom_TableWrapper container">
            <label className="label1">First name *</label>
            <Input
              name="firstname"
              id="firstname"
              value={editprofile.values.firstname}
              onChange={editprofile.handleChange}
            />
            {editprofile.touched.firstname && editprofile.errors.firstname ? (
              <span className="error">{editprofile.errors.firstname as any}</span>
            ) : null}
           <br/> <label className="label1">Last name *</label>
            <Input
              name="lastname"
              id="lastname"
              value={editprofile.values.lastname}
              onChange={editprofile.handleChange}
            />
            {editprofile.touched.lastname && editprofile.errors.lastname ? (
              <span className="error">{editprofile.errors.lastname as any}</span>
            ) : null}
           <br/>  <label className="label1">Email *</label>
           <Input
              id="emailid"
              name="emailid"
              value={editprofile.values.emailid}
              onChange={editprofile.handleChange}
            />
            {editprofile.touched.emailid && editprofile.errors.emailid ? (
              <span className="error">{editprofile.errors.emailid as any}</span>
            ) : null}
            <br/> <label className="label1">Mobile number *</label>
            <Input
              name="mobilenumber"
              id="mobilenumber"
              onChange={editprofile.handleChange}
            />
            {editprofile.touched.mobilenumber && editprofile.errors.mobilenumber ? (
              <span className="error">{editprofile.errors.mobilenumber}</span>
            ) : null}
           <br/> <Button
              type="primary"
              htmlType="submit"
              className="custom_activeInactive_btn mt-3"
            >
              Update
            </Button>
          </div>
        </form>
      </Layout>
    </>
  );
};

import { Button, Layout, Input } from "antd";
import { EyeInvisibleOutlined, EyeTwoTone } from "@ant-design/icons";
import "../../assets/css/common.css";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useSelector } from "react-redux";
import { APIRequest ,UPDATE_PASSWORD } from "../../api";
import swal from "sweetalert";

export const ChangePassword = () => {

 
  const user = useSelector(state  => state as any)


  const updatePassword = useFormik({
    enableReinitialize: true,
    initialValues: {
      userid: user.user.userid,
      emailid: user.user.emailid,
      password: "",
      passwordconfirm: "",
    },
    validationSchema: Yup.object().shape({
      password: Yup.string()
        .required("Enter Password")
        .matches(
          /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/,
          "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
        ),
      passwordconfirm: Yup.string()
        .oneOf([Yup.ref("password"), null as any], "Passwords must match")
        .required(" Enter Confirm Password"),
    }),
    onSubmit: (values) => {

      new APIRequest.Builder()
      .post()
      .setReqId(UPDATE_PASSWORD)
      .jsonParams(values)
      .reqURL("api/v1/user/update_password")
      .response(onResponse)
      .error(onError)
      .build()
      .doRequest();
    },
  });

  const onResponse = (response: any, reqId: any) => {
    switch (reqId) {
      case UPDATE_PASSWORD:
        if (response.data.issuccess) {
          swal(`${response.data.massage}`, "", "success");
        } else {
          swal(`${response.data.massage}`, "", "warning");
        } 
        break;
      default:
        break;

        
    }}

    const onError = (response: any, reqId: any) => {
      switch (reqId) {
        case UPDATE_PASSWORD: 
        console.log(response)  
        break;
      default:
        break;
          
      }}

  return (
    <>
      <Layout className="custom_MainBackground">
        <div className="container p-0 d-flex justify-content-between customers_header">
          <h4>Change Password</h4>
        </div>
        <form onSubmit={updatePassword.handleSubmit}>
          <div className="custom_TableWrapper container">
            <label className="label1">Enter Old Password *</label>
            <br />
            <Input.Password
              className="w-25"
              iconRender={(visible) =>
                visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />
              }
            />{" "}
            <br />
            <label className="label1">Enter New Password *</label>
            <br />
            <Input.Password
              id="password"
              name="password"
              onChange={updatePassword.handleChange}
              value={updatePassword.values.password}
              className="w-25"
              iconRender={(visible) =>
                visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />
              }
            />
            {updatePassword.touched.password &&
            updatePassword.errors.password ? (
              <span className="error">{updatePassword.errors.password}</span>
            ) : null}
            <br />
            <label className="label1">Confirm New Password *</label>
            <br />
            <Input.Password
              className="w-25"
              id="passwordconfirm"
              name="passwordconfirm"
              value={updatePassword.values.passwordconfirm}
              onChange={updatePassword.handleChange}
              iconRender={(visible) =>
                visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />
              }
            />
            {updatePassword.touched.passwordconfirm &&
            updatePassword.errors.passwordconfirm ? (
              <span className="error">
                {updatePassword.errors.passwordconfirm}
              </span>
            ) : null}
            <br />
            <Button
              type="primary"
              htmlType="submit"
              className="custom_activeInactive_btn mt-3"
            >
              Update
            </Button>
          </div>
        </form>
      </Layout>
    </>
  );
};


import {Button, Table, Layout, Input,Modal, Row, Col,Select, message, Upload,Radio  } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import type { UploadProps ,RadioChangeEvent } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useState } from 'react';
import '../../assets/css/common.css'


export  const UserJobSeekr  = () => {

    interface DataType {
        key: React.Key;
        userID : any;
        fname : any;
        lname : any;
        email : any;
        mobile : any; 
        createdBy : any;
        createdOn: any;
        modifiedBy : any;
        modifiedOn : any;
        isActive : any;
    }

    const columns: ColumnsType<DataType> = [
      {
        title: 'User Id',
        dataIndex: 'userID',
        sorter:{ compare: (a, b) =>  a.userID.localeCompare(b.userID),
            multiple:1
        },
       
        onCell: (record, rowIndex) => {
          return {
            onClick: () => {
              modalHandle()
            }
          };
        },
        className:"hasFormHover" 
      }, 
      {
        title: 'Fisrt Name',
        dataIndex: 'fname', 
        sorter:{ compare: (a, b) =>  a.fname.localeCompare(b.fname),
          multiple:1
      },
      },
      {
        title: 'Last Name',
        dataIndex: 'lname', 
        sorter:{ compare: (a, b) =>  a.lname.localeCompare(b.lname),
          multiple:1
      },  
      },
      {
        title: 'Email',
        dataIndex: 'email', 
        sorter:{ compare: (a, b) =>  a.email.localeCompare(b.email),
          multiple:1
      },
      },
      {
        title: 'Mobile',
        dataIndex: 'mobile', 
        sorter:{ compare: (a, b) =>  a.mobile.localeCompare(b.mobile),
          multiple:1
      }, 
      },
      {
        title: 'Created by',
        dataIndex: 'createdBy', 
        sorter:{ compare: (a, b) =>  a.createdBy.localeCompare(b.createdBy),
          multiple:1
      }, 
      },
      {
        title: 'Created on',
        dataIndex: 'createdOn', 
        sorter:{ compare: (a, b) =>  a.createdOn.localeCompare(b.createdOn),
          multiple:1
      }, 
      },
      {
        title: 'Modified On',
        dataIndex: 'modifiedOn', 
        sorter:{ compare: (a, b) =>  a.modifiedOn.localeCompare(b.modifiedOn),
          multiple:1
      }, 
      },
      {
        title: 'Modified by',
        dataIndex: 'modifiedBy', 
        sorter:{ compare: (a, b) =>  a.modifiedBy.localeCompare(b.modifiedBy),
          multiple:1
      }, 
      },
      {
        title: 'Is Active',
        dataIndex: 'isActive', 
        sorter:{ compare: (a, b) =>  a.isActive.localeCompare(b.isActive),
          multiple:1
      }, 
      },
      
      
    ];
     
    const dataSource = [
      {
        key: '0',
        userID : "Test ID",
        fname : "Test Fname",
        lname : "Test Lname", 
        email : "Test Email", 
        mobile : "987654321",
        createdBy : "06-08-2022 12:22PM",
        createdOn: "2022-12-2",
        modifiedBy : "06-08-2022 12:22PM",
        modifiedOn : "2022-12-2",
        isActive : "Incative",
      },  
    ];
 



    // Modal
    const [visible, setVisible] = useState(false);
    const modalHandle = () => {
      setVisible(true)
    };

    // Text Area
    // const { TextArea } = Input;


    // Dropdown Select
    const { Option } = Select;
    const onChange = (value: string) => {
      console.log(`selected ${value}`);
    };
    const onSearch = (value: string) => {
      console.log('search:', value);
    };

    // upload
    // const props: UploadProps = {
    //   name: 'file',
    //   action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    //   headers: {
    //     authorization: 'authorization-text',
    //   },
    //   onChange(info) {
    //     if (info.file.status !== 'uploading') {
    //       console.log(info.file, info.fileList);
    //     }
    //     if (info.file.status === 'done') {
    //       message.success(`${info.file.name} file uploaded successfully`);
    //     } else if (info.file.status === 'error') {
    //       message.error(`${info.file.name} file upload failed.`);
    //     }
    //   },
    //   progress: {
    //     strokeColor: {
    //       '0%': '#108ee9',
    //       '100%': '#87d068',
    //     },
    //     strokeWidth: 3,
    //     format: percent => percent && `${parseFloat(percent.toFixed(2))}%`,
    //   },
    // };

    // Radio
 
      // const [value, setValue] = useState(1);
    
      // const onRadioChange = (e: RadioChangeEvent) => {
      //   console.log('radio checked', e.target.value);
      //   setValue(e.target.value);
      // };
    

  return (<>

    <Layout className='custom_MainBackground'>

      <div className="container-fluid p-0 d-flex justify-content-between customers_header">
        <h4>Job Seekres</h4>
          <div>
        <Button type="primary" className='custom_activeInactive_btn' >Active</Button>
        <Button type="primary" className='custom_activeInactive_btn' >Inactive</Button>
        <Button type="primary" className='custom_activeInactive_btn' onClick={modalHandle} >Add New</Button>
        </div> 
      </div>

      <div className="custom_TableWrapper container-fluid">
        <div className="d-flex">
        <label className='mt-1'><b>Search:</b></label><Input className='w-50 ms-2' />
        </div>
        <hr/>
        <Table className='custom_table'  rowSelection={{type: "checkbox",columnTitle:'Select',columnWidth:60}} columns={columns}  dataSource={dataSource}
          scroll={{ x: 1000 }}
          pagination={{ showSizeChanger:true, pageSizeOptions: [5,10,25,100] }} 
          />       
      </div>

    </Layout>




    {/* Modal  */}
         
        <Modal footer={false} title="Job Seeker" centered visible={visible} onOk={() => setVisible(false)} onCancel={() => setVisible(false)} width={1400} >

          <Row className='Row-Height' gutter={[10,10]}> 
            <Col xs={24} sm={24} lg={12} span={12}> 
              <Row> 
                <Col span={24}>
                  <label className='label1'>ID*</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'>First Name *</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'>Last Name *</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'> Email *</label><Input   />
                </Col>
                <Col span={24}>
                  <label className='label1'> Mobile *</label><Input  />
                </Col> 
              </Row>
            </Col>
            <Col xs={24} sm={24} lg={12} span={12}>
             
              <Row> 
                <Col span={24}>
                  <label className='label1'>Created By *</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'>Created On *</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'>Modified By *</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'>Modified On *</label><Input   />
                </Col>
                
                <Col span={24}>
                  <label className='label1'>Status*</label> <br />
                  <Select className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
                    <Option value="active">Active</Option>
                    <Option value="inactive">Inactive</Option>
                  </Select>
                </Col>
                
              </Row>
            </Col>


            
           
          

            
            <Col span={24} className="mt-4 p-0">
            <Button type="primary" className='custom_activeInactive_btn' >Save</Button>
            <Button type="primary" className='custom_activeInactive_btn' >Cancel</Button>
          </Col>
            
          </Row>

  
        </Modal>

{/* referene modal project 1 */}
        <>
         {/* Modal  */}
        {/*
        <Modal footer={false} title="Update Factory" centered visible={visible} onOk={() => setVisible(false)} onCancel={() => setVisible(false)} width={1400} >

          <Row className='Row-Height' gutter={[10,10]}>
            
            <Col xs={24} sm={24} lg={12} span={12}>
              <h4>Factory Details</h4>
              <Row>

                <Col span={24}>
                  <label className='label1'>Factory *</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'>First Name *</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'>Last Name *</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'>Factory Email *</label><Input disabled={true} />
                </Col>
                <Col span={24}>
                  <label className='label1'>Street address *</label> <TextArea rows={4} /> 
                </Col>

                <Col span={24}>
                  <label className='label1'>Country *</label> <br />
                  <Select className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
                    <Option value="India">India</Option>
                    <Option value="Pakistan">Pakistan</Option>
                    <Option value="Chaina">Chaina</Option>
                  </Select>
                </Col>

                <Col span={24}>
                  <label className='label1'>State *</label> <br />
                  <Select className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
                    <Option value="Gujrat">Gujrat</Option>
                    <Option value="Maharashtra">Maharashtra</Option>
                    <Option value="Rajastan">Rajastan</Option>
                  </Select>
                </Col>

                <Col span={24}>
                  <label className='label1'>City *</label> <br />
                  <Select className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
                    <Option value="Rajkot">Rajkot</Option>
                    <Option value="Ahemdabad">Ahemdabad</Option>
                    <Option value="Surat">Surat</Option>
                  </Select>
                </Col>

                <Col span={24}>
                  <label className='label1'>Pincode *</label><Input />
                </Col>

                <Col span={24}>
                  <label className='label1'>Logo Image *</label><br />
                  <Upload {...props}>
                    <Button icon={<UploadOutlined />}>Click to Upload</Button>
                  </Upload>
                  <a href="#">View Logo</a>
                </Col>


              </Row>
            </Col>


            
            <Col xs={24} sm={24} lg={12} span={12}>
              <h4>Commission Details</h4>
              <Row>

                <Col span={24}>
                  <label className='label1'>Commission %*</label><Input  />
                </Col>
                <Col span={24}>
                  <label className='label1'>Business Certifications</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'>Products Type They Make</label><Input />
                </Col>
                <Col span={24}>
                  <label className='label1'>MOQ Required</label>
                  <Radio.Group onChange={onRadioChange} value={value} className="ms-3">
                    <Radio value={1}>Yes</Radio>
                    <Radio value={2}>No</Radio>
                  </Radio.Group>
                </Col>

                <h4 className='mt-4'>Product Associated</h4>

                <Col span={24}>
                  <label className='label1'>Primary Category*</label> <br />
                  <Select mode='multiple' allowClear className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
                    <Option value="Men">Men</Option>
                    <Option value="Women">Women</Option>
                    <Option value="Home">Home</Option>
                  </Select>
                </Col>

                <Col span={24}>
                  <label className='label1'>Sub Category*</label> <br />
                  <Select mode='multiple' allowClear className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
                    <Option value="Kids">Kids</Option>
                    <Option value="Men">Men</Option>
                  </Select>
                </Col>

                <Col span={24}>
                  <label className='label1'>Product Category*</label> <br />
                  <Select mode='multiple' allowClear className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
                    <Option value="Kids">Kids</Option>
                    <Option value="Men">Men</Option>
                  </Select>
                </Col>

                <Col span={24}>
                  <label className='label1'>Product Sub Category*</label> <br />
                  <Select mode='multiple' allowClear className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
                    <Option value="Kids">Kids</Option>
                    <Option value="Men">Men</Option>
                  </Select>
                </Col>

                <Col span={24}>
                  <label className='label1'>Onboarded Status*</label> <br />
                  <Select className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
                    <Option value="Onboarded">Onboarded</Option>
                    <Option value="Pending">Pending</Option>
                  </Select>
                </Col>

                <Col span={24}>
                  <label className='label1'>Status*</label> <br />
                  <Select className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
                    <Option value="active">Active</Option>
                    <Option value="inactive">Inactive</Option>
                  </Select>
                </Col>

              </Row>

            </Col>

          

            
            <Col span={24} className="mt-4 p-0">
            <Button type="primary" className='custom_activeInactive_btn' >Save</Button>
            <Button type="primary" className='custom_activeInactive_btn' >Cancel</Button>
          </Col>
            
          </Row>

  
        </Modal>
          */}
        </>
           
    
  </>)
}


import {
  Button,
  Table,
  Layout,
  Input,
  Modal,
  Row,
  Col,
  Select,
  DatePicker,
  Upload,
  message,
  Radio,
  Space,
} from "antd";
import { EyeInvisibleOutlined, EyeTwoTone } from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";
import { useState } from "react";
import "./Login.css";
import { Link, useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import { APIRequest, USER_LOGIN } from "../../api";
import { useDispatch } from "react-redux";
import { setToken,setUser } from "../../redux/action";
import swal from 'sweetalert';

export const Login = () => {
  const dispatch =useDispatch();
  const navigate= useNavigate();
  const login = useFormik({
    initialValues: {
      emailid: "",
      password: "",
    },
    onSubmit: (value) => {
      new APIRequest.Builder()
        .post()
        .setReqId(USER_LOGIN)
        .jsonParams(value)
        .reqURL("api/v1/user/signin")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
    },
  });

  const onResponse = (response: any, reqId: any) => {
    switch (reqId) {
      case USER_LOGIN: 
      console.log(response.data.data.userdetail )     
        if (response.data.issuccess) {
          dispatch(setToken(response.data.data.accessToken));
          dispatch(setUser(response.data.data.userdetail ));
          localStorage.setItem("token",response.data.data.accessToken)
         navigate("/");
        }
        else{
          swal(`${response.data.massage}`, "" ,"warning" );
        }
        break;
        default:
          break;
    }
  };

  const onError = (response: any, reqId: any) => {
    switch (reqId) {
      case USER_LOGIN:
        console.log(response);     
        
    }
   
  };

  return (
    <>
      <Layout className="Login_Main">
        <img src="/Images/logo1.png" className="img-fluid mb-5" />

        <div className="LoginContianer">
          <h3>Login</h3>
          <p>Log in to your account to continue.</p>
          <form onSubmit={login.handleSubmit}>
            <label className="label1">Email Address</label>
            <Input id="emailid" name="emailid" onChange={login.handleChange} />
            <label className="label1">Password</label>
            <Input.Password
              id="password"
              name="password"
              onChange={login.handleChange}
              iconRender={(visible) =>
                visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />
              }
            />

            <div className="d-flex mt-3 justify-content-between">
              <div>
                <input type="checkbox" name="" id="" />
                <label className="label1 ms-1">Remember me</label>
              </div>
              <div className="mt-2">
                <Link to="/ForgotPassword">Forgot Password</Link>
              </div>
            </div>

            <button className="loginBtn" type="submit">
              Login
            </button>
          </form>
        </div>
      </Layout>
    </>
  );
};

import {
  Button,
  Table,
  Layout,
  Input,
  Modal,
  Row,
  Col,
  Select,
  DatePicker,
  Upload,
  message,
  Radio,
  Space,
} from "antd";
import { EyeInvisibleOutlined, EyeTwoTone } from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";
import { useState } from "react";
import "./Login.css";
import { Link, useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import { APIRequest, FORGOT_PASSWORD } from "../../api";
import swal from "sweetalert";

export const ForgotPassword = () => {
  const navigate = useNavigate();
  const emailform = useFormik({
    initialValues: {
      emailid: "",
    },
    validationSchema: Yup.object().shape({
      emailid: Yup.string()
        .email("Invalid email address")
        .required("Please enter email"),
    }),
    onSubmit: (values) => {
      new APIRequest.Builder()
        .post()
        .setReqId(FORGOT_PASSWORD)
        .jsonParams(values)
        .reqURL("api/v1/user/resetpassword")
        .response(onResponse)
        .error(onError)
        .build()
        .doRequest();
    },
  });

  const onResponse = (response: any, reqId: any) => {
    switch (reqId) {
      case FORGOT_PASSWORD:
        if (response.data.issuccess) {
          swal(`${response.data.massage}`, "", "success").then((value) => {
            navigate("/login");
          });
        } else {
          swal(`${response.data.massage}`, "", "warning");
        }
        break;
      default:
        break;
    }
  };

  const onError = (response: any, reqId: any) => {
    switch (reqId) {
      case FORGOT_PASSWORD:
        console.log(response);
        break;
      default:
        break;
    }
  };

  return (
    <>
      <Layout className="Login_Main">
        <img src="/Images/logo1.png" className="img-fluid mb-5" />

        <div className="ForgotContianer">
          <h3>Password Recovery</h3>
          <p>
            Please fill in the Email You have used to create your account & we
            will send you a reset password link
          </p>
          <form onSubmit={emailform.handleSubmit}>
            <label className="label1">Email</label>
            <Input
              id="emailid"
              name="emailid"
              value={emailform.values.emailid}
              onChange={emailform.handleChange}
            />
            {emailform.touched.emailid && emailform.errors.emailid ? (
              <span className="error">{emailform.errors.emailid}</span>
            ) : null}

            <button className="loginBtn" type="submit">
              Reset Password
            </button>
          </form>
          <p className="text-center mt-3">
            Remember your password ? <Link to="/login">Login</Link>
          </p>
        </div>
      </Layout>
    </>
  );
};


import {Button, Table, Layout, Input,Modal, Row, Col,Select, message, Upload,Radio  } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import type { UploadProps ,RadioChangeEvent } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useState } from 'react';
import '../../assets/css/common.css'


export  const CFG_StatciPage = () => {

    interface DataType {
        key: React.Key; 
        pageCode:any;
        pageName:any;
        title:any;
        pageBody:any;
        

        createdBy : any;
        createdOn: any;
        modifiedBy : any;
        modifiedOn : any;
        isActive : any;

    }


      // Modal
      const [visible, setVisible] = useState(false);
      const modalHandle = () => {
        setVisible(true)
      };
  
       // Dropdown Select
       const { Option } = Select;
       const onChange = (value: string) => {
         console.log(`selected ${value}`);
       };
       const onSearch = (value: string) => {
         console.log('search:', value);
       };
         
 

    const columns: ColumnsType<DataType> = [
      {
        title: 'Page Code',
        dataIndex: 'pageCode', 
        sorter:{ compare: (a, b) =>  a.pageCode.localeCompare(b.pageCode),
          multiple:1
      },
      }, 
      {
        title: 'Page Name',
        dataIndex: 'pageName', 
        sorter:{ compare: (a, b) =>  a.pageName.localeCompare(b.pageName),
          multiple:1
      },
      onCell: (record, rowIndex) => {
        return {
          onClick: () => {
            modalHandle()
          }
        };
      },
      className:"hasFormHover" 
      }, 
       
      {
        title: 'Title',
        dataIndex: 'title', 
        sorter:{ compare: (a, b) =>  a.title.localeCompare(b.title),
          multiple:1
      },
      },
      {
        title: 'Page Body',
        dataIndex: 'pageBody', 
        sorter:{ compare: (a, b) =>  a.pageBody.localeCompare(b.pageBody),
          multiple:1
      },
      },
      
      {
        title: 'Created by',
        dataIndex: 'createdBy', 
        sorter:{ compare: (a, b) =>  a.createdBy.localeCompare(b.createdBy),
          multiple:1
      },
      },
      {
        title: 'Created on',
        dataIndex: 'createdOn', 
        sorter:{ compare: (a, b) =>  a.createdOn.localeCompare(b.createdOn),
          multiple:1
      },
      },
      {
        title: 'Modified On',
        dataIndex: 'modifiedOn', 
        sorter:{ compare: (a, b) =>  a.modifiedOn.localeCompare(b.modifiedOn),
          multiple:1
      },
      },
      {
        title: 'Modified by',
        dataIndex: 'modifiedBy', 
        sorter:{ compare: (a, b) =>  a.modifiedBy.localeCompare(b.modifiedBy),
          multiple:1
      },
      },
      {
        title: 'Is Active',
        dataIndex: 'isActive', 
        sorter:{ compare: (a, b) =>  a.isActive.localeCompare(b.isActive),
          multiple:1
      },
      }, 
    ];
     
    const dataSource = [
      {
        key: '0',
        pageCode : "Test code",
        pageName : "Testp-name",
        title : "Test title", 
        pageBody : "Testbody",  
        createdBy : "06-08-2022 12:22PM",
        createdOn: "2022-12-2",
        modifiedBy : "06-08-2022 12:22PM",
        modifiedOn : "2022-12-2",
        isActive : "Incative",
      },  
    ];
 

 

  return (<>    

    <Layout className='custom_MainBackground'>

      <div className="container-fluid p-0 d-flex justify-content-between customers_header">
        <h4>Static Pages</h4>
          <div>
        <Button type="primary" className='custom_activeInactive_btn' >Active</Button>
        <Button type="primary" className='custom_activeInactive_btn' >Inactive</Button>
        <Button type="primary" className='custom_activeInactive_btn' onClick={modalHandle}>Add New</Button>
        </div> 
      </div>

      <div className="custom_TableWrapper container-fluid  ">
        <div className="d-flex">
        <label className='mt-1'><b>Search:</b></label><Input className='w-50 ms-2' />
        </div>
        <hr/>
        <Table className='custom_table'  rowSelection={{type: "checkbox",columnTitle:'Select',columnWidth:60}} columns={columns}  dataSource={dataSource}
          scroll={{ x: 1000 }}
          pagination={{ showSizeChanger:true, pageSizeOptions: [5,10,25,100] }} 
          />       
      </div>

    </Layout>

    <Modal footer={false} title="Static Page" centered visible={visible} onOk={() => setVisible(false)} onCancel={() => setVisible(false)} width={700} > 
    <Row className='Row-Height' gutter={[10,10]}> 
      <Col > 
        <Row> 
        <Col span={24}>
            <label className='label1'>Page Code *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Page Name*</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Title *</label><Input />
          </Col> 
          <Col span={24}>
            <label className='label1'>Page Body *</label><Input />
          </Col> 
          <Col span={24}>
            <label className='label1'>Created By *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Created On *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Modified By *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Modified On *</label><Input   />
          </Col> 
          <Col span={24}>
            <label className='label1'>Status*</label> <br />
            <Select className='w-100' showSearch   optionFilterProp="children" onChange={onChange} onSearch={onSearch} filterOption={(input, option) =>  (option!.children as unknown as string).toLowerCase().includes(input.toLowerCase())}>
              <Option value="active">Active</Option>
              <Option value="inactive">Inactive</Option>
            </Select>
          </Col>
          </Row>
      </Col> 
      <Col span={24} className="mt-4 p-0">
      <Button type="primary" className='custom_activeInactive_btn' >Save</Button>
      <Button type="primary" className='custom_activeInactive_btn' >Cancel</Button>
    </Col>
      
    </Row>


</Modal>





    
    
  </>)
}


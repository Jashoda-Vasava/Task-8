import {Button, Table, Layout, Input,Modal, Row, Col,Select, message, Upload,Radio  } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import type { UploadProps ,RadioChangeEvent } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useState } from 'react';
import '../../assets/css/common.css'


export  const CFG_CompanyGeneral = () => {

    interface DataType {
        key: React.Key; 
        companyId:any;
        companyName:any;
        website:any;
        copyright:any;
        logo:any;
        favicon:any;
        address:any;
        email:any;
        phone:any;


        createdBy : any;
        createdOn: any;
        modifiedBy : any;
        modifiedOn : any; 

    }

         
 

    const columns: ColumnsType<DataType> = [
      {
        title: 'Company ID',
        dataIndex: 'companyId', 
        sorter:{ compare: (a, b) =>  a.companyId.localeCompare(b.companyId),
          multiple:1
      },
      },
      {
        title: 'Company Name',
        dataIndex: 'companyName', 
        sorter:{ compare: (a, b) =>  a.companyName.localeCompare(b.companyName),
          multiple:1
      },
      onCell: (record, rowIndex) => {
        return {
          onClick: () => {
            modalHandle()
          }
        };
      },
      // render: image_1 => <img width="150px" alt={image_1} src={image_1} /> ,
      // width:"150px",
        className:"hasFormHover" 
      },
      {
        title: 'Website',
        dataIndex: 'website', 
        sorter:{ compare: (a, b) =>  a.website.localeCompare(b.website),
          multiple:1
      },
      },

      {
        title: 'Copyright',
        dataIndex: 'copyright', 
        sorter:{ compare: (a, b) =>  a.copyright.localeCompare(b.copyright),
          multiple:1
      },
      },
      {
        title: 'Logo',
        dataIndex: 'logo', 
        sorter:{ compare: (a, b) =>  a.logo.localeCompare(b.logo),
          multiple:1
      },
      },
      {
        title: 'Favicon',
        dataIndex: 'favicon', 
        sorter:{ compare: (a, b) =>  a.favicon.localeCompare(b.favicon),
          multiple:1
      },
      },


      {
        title: 'Address',
        dataIndex: 'address', 
        sorter:{ compare: (a, b) =>  a.address.localeCompare(b.address),
          multiple:1
      },
      },
      {
        title: 'Phone',
        dataIndex: 'phone', 
        sorter:{ compare: (a, b) =>  a.phone.localeCompare(b.phone),
          multiple:1
      },
      },
      {
        title: 'Email',
        dataIndex: 'email', 
        sorter:{ compare: (a, b) =>  a.email.localeCompare(b.email),
          multiple:1
      },
      },



      {
        title: 'Created By',
        dataIndex: 'createdBy', 
        sorter:{ compare: (a, b) =>  a.createdBy.localeCompare(b.createdBy),
          multiple:1
      },
      },
      {
        title: 'Created on',
        dataIndex: 'createdOn', 
        sorter:{ compare: (a, b) =>  a.createdOn.localeCompare(b.createdOn),
          multiple:1
      },
      },
      {
        title: 'Modified On',
        dataIndex: 'modifiedOn', 
        sorter:{ compare: (a, b) =>  a.modifiedOn.localeCompare(b.modifiedOn),
          multiple:1
      },
      },
      {
        title: 'Modified by',
        dataIndex: 'modifiedBy', 
        sorter:{ compare: (a, b) =>  a.modifiedBy.localeCompare(b.modifiedBy),
          multiple:1
      },
      }, 
    ];
     
    const dataSource = [
      {
        key: '0', 
        companyId: '0', 
        // companyName:"/images/products/product.png" , 
        companyName:"cnam" , 
        website: '0',  
        copyright:'0',       
        logo:'0',      
        favicon:'0',  
        address:'a',
        phone:'98765432',
        email:'ed@gmal.com',   
        createdBy : "06-08-2022 12:22PM",
        createdOn: "2022-12-2",
        modifiedBy : "06-08-2022 12:22PM",
        modifiedOn : "2022-12-2", 
      },  
    ];
 

   // Modal
   const [visible, setVisible] = useState(false);
   const modalHandle = () => {
     setVisible(true)
   };

    // Dropdown Select
    const { Option } = Select;
    const onChange = (value: string) => {
      console.log(`selected ${value}`);
    };
    const onSearch = (value: string) => {
      console.log('search:', value);
    };

  return (<>    

    <Layout className='custom_MainBackground'>

      <div className="container-fluid p-0 d-flex justify-content-between customers_header">
        <h4>Company General</h4>
          {/* <div>
            <Button type="primary" className='custom_activeInactive_btn' >Active</Button>
            <Button type="primary" className='custom_activeInactive_btn' >Inactive</Button>
            
<Button type="primary" className='custom_activeInactive_btn' onClick={modalHandle}>Add New</Button>
        </div>  */}
      </div>

      <div className="custom_TableWrapper container-fluid  ">
        <div className="d-flex">
        <label className='mt-1'><b>Search:</b></label><Input className='w-50 ms-2' />
        </div>
        <hr/>
        <Table className='custom_table'  rowSelection={{type: "checkbox",columnTitle:'Select',columnWidth:60}} columns={columns}  dataSource={dataSource}
          scroll={{ x: 1000 }}
          pagination={{ showSizeChanger:true, pageSizeOptions: [5,10,25,100] }} 
          />       
      </div>
    </Layout>

    <Modal footer={false} title="Company Genreal" centered visible={visible} onOk={() => setVisible(false)} onCancel={() => setVisible(false)} width={1400} >

    <Row className='Row-Height' gutter={[10,10]}> 
    <img src='./images/products/c1.jpg'/>
      <Col xs={24} sm={24} lg={12} span={12}> 
        <Row> 
          <Col span={24}>
            <label className='label1'>Company  ID*</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Company  Name *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Website *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'> Copyright *</label><Input   />
          </Col>
          <Col span={24}>
            <label className='label1'> Logo *</label><Input  />
          </Col> 
          <Col span={24}>
            <label className='label1'> Favicon *</label><Input  />
          </Col> 
          <Col span={24}>
            <label className='label1'>Address *</label><Input />
          </Col>
        </Row>
      </Col>
      <Col xs={24} sm={24} lg={12} span={12}>
      
        <Row> 
         
          <Col span={24}>
            <label className='label1'>Phone   *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Email   *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Created By *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Created On *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Modified By *</label><Input />
          </Col>
          <Col span={24}>
            <label className='label1'>Modified On *</label><Input   />
          </Col>
          
         
          
        </Row>
      </Col>


      
    


      
      <Col span={24} className="mt-4 p-0">
      <Button type="primary" className='custom_activeInactive_btn' >Save</Button>
      <Button type="primary" className='custom_activeInactive_btn' >Cancel</Button>
    </Col>
      
    </Row>


</Modal>




    
    
  </>)
}


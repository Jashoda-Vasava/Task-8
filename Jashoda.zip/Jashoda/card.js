import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Grid,
  Card,
  CardContent,
  Typography,
  CardHeader,
} from "@material-ui/core/";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    padding: theme.spacing(2)
  }
}));


export default function AltCard() {
  const classes = useStyles();
  return (
    <div className={classes.root}>
     <Grid sx={{ flexGrow: 1 }} container spacing={1}>
      <Grid
      xs={12}
      >
        <Grid container  justifyContent="space-evenly" spacing={2}>
          <Card xs={6} md={6}>
            <CardHeader
              title={`quarter :"d`}
              subheader={`earnings : sshhdhdg`}
            />
            <CardContent>
              <Typography variant="h5" gutterBottom>
                Hello World
              </Typography>
            </CardContent>
          </Card>
          <Card xs={6} md={6} >
            <CardHeader
              title={`quarter :"d`}
              subheader={`earnings : sshhdhdg`}
            />
            <CardContent>
              <Typography variant="h5" gutterBottom>
                Hello World
              </Typography>
            </CardContent>
          </Card>
        
        </Grid>
        </Grid>
      </Grid>
    </div>
  );
}

import { get_homepageinfo, get_mediacoverage, get_recruitmentpartners, get_socialicon, get_videodetail, save_homepageheader } from '../Api/apiEndPoint';
import http  from '../Api/commonUrl'

//Home Pages servicess
 export const getAllServices=(props)=> {
    return http.post(`${save_homepageheader}`,props);
  }

export const getHomepageInfoServices=(props)=> {
  return http.post(`${get_homepageinfo}`,props);
}

export const getmediaCoverageServices=(props)=> {
  return http.post(`${get_mediacoverage}`,props)
}

export const getRecruitmentpartnersServices=(props)=> { 
  return http.post(`${get_recruitmentpartners}`,props)
}
export const getSocialiconServices=(props)=> {
  return http.post(`${get_socialicon}`,props)
}
export const getVideodetailServices=(props)=> { 
  return http.post(`${get_videodetail}`,props)
}
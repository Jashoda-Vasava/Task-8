
import './App.css';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Users from './components/Users';
import AddEdit from './components/AddEdit';
function App() {
  return (
    <div className="App">
     <Router>
    <Routes>
      <Route path="/" element={<Users/>} />
      <Route path="/add" element={<AddEdit/>} />
      <Route path="/edit/:id" element={<AddEdit/>} />
    </Routes>
     </Router>
    </div>
  );
}

export default App;

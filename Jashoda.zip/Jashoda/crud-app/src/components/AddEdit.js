import React, {  useState } from "react";
import { FormControl, Input  } from "@mui/material";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { Formik } from "formik";
import * as Yup from "yup";

const dataSchema = Yup.object().shape({
  name: Yup.string().required("Name is required"),
  username: Yup.string().required("Username is required"),
  email: Yup.string().email("Email is invalid").required("Email is required"),
  address: Yup.string().required(" Address is required"),
});

const AddEdit = () => {
  const [user, setUser] = useState();
  const initialValues = { name: "", username: "", email: "", address: "" };
  const { id } = useParams();
  const isAddMode = !id;
  const navigate = useNavigate();
 
  React.useEffect(() => {
    if (!isAddMode) {
      axios.get(`http://localhost:3002/users/${id}`).then((user) => {
        setUser(user.data);
      });
    }
  }, []);
 
  /* API CALL START */
  const AddSubmit = (values) => {
    axios
      .post(`http://localhost:3002/users`, values)
      .then((response) => (response.data, navigate("/")));
  };

  const EditSubmit = (values) => {
    axios
      .put(`http://localhost:3002/users/${id}`, values)
      .then(
        (response) => (response.data,navigate("/"), console.log(response.data, "response"))
      );
  };

  /* API CALL END */
  return (
    <Formik
      initialValues={user || initialValues}
      validationSchema={dataSchema}
      enableReinitialize
      onSubmit={(values) => {
        if (isAddMode) {
          AddSubmit(values);
        } else {
          EditSubmit((id, values));
        }
      }}
    >
      {({ errors, touched, values, handleChange, handleSubmit }) => (
        <div>
          <div>
            <h2> {id ? "Edit Form" : "Add Form"} </h2>
          </div>
          <form onSubmit={handleSubmit}>
            <FormControl>
              <Input
                placeholder="Enter Name"
                name="name"
                type="name"
                value={values.name}
                onChange={handleChange}
              />
              <span>
                {errors.name && touched.name ? (
                  <div style={{ color: "red" }}>{errors.name}</div>
                ) : null}
              </span>
            </FormControl>
            <br />
            <FormControl>
              <Input
                placeholder="Enter User Name"
                name="username"
                value={values.username }
                onChange={handleChange}
              />
              <span>
                {errors.name && touched.username ? (
                  <div style={{ color: "red" }}>{errors.username}</div>
                ) : null}
              </span>
            </FormControl>
            <br />
            <FormControl>
              <Input
                placeholder="Enter Email"
                name="email"
                value={values?.email }
                onChange={handleChange}
              />
              <span>
                {errors.email && touched.email ? (
                  <div style={{ color: "red" }}>{errors.email}</div>
                ) : null}
              </span>
            </FormControl>
            <br />
            <FormControl>
              <Input
                placeholder="Enter Address"
                name="address"
                value={values?.address }
                onChange={handleChange}
              />
              <span>
                {errors.address && touched.address ? (
                  <div style={{ color: "red" }}>{errors.address}</div>
                ) : null}
              </span>
            </FormControl>
            <br />
            <button variant="outlined" type="button" onClick={handleSubmit}>
              {id ? "Edit" : "Add"}{" "}
            </button>
          </form>
        </div>
      )}
    </Formik>
  );
};

export default AddEdit;

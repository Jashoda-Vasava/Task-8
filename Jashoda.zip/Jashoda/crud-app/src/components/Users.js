import * as React from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));
const Users = () => {
  const [user, setUser] = React.useState();
  const navigate = useNavigate();

  React.useEffect(() => {
    axios.get("http://localhost:3002/users").then((response) => {
      setUser(response.data);
    });
  }, []);

  const deleteUser = (id) => {
    if(window.confirm('Are you sure you want to delete')){
    axios.delete(`http://localhost:3002/users/${id}`).then((response) => (response.data));
    axios.get("http://localhost:3002/users").then((response) => {
      setUser(response.data);
    });
  }
  
 }

  return (
    <div>
      <div style={{ marginTop: "5%" }}>
        <button style={{ backgroundColor: "greenyellow" }} onClick={()=>navigate('/add')}>Add User</button>
      </div>
      <TableContainer
        component={Paper}
        style={{ width: "50%", marginLeft: "25%", marginTop: "2%" }}
      >
        <Table
          sx={{ minWidth: 200 }}
          style={{ width: "100%" }}
          aria-label="customized table"
        >
          <TableHead>
            <TableRow>
              <StyledTableCell>Name</StyledTableCell>
              <StyledTableCell align="right">User Name</StyledTableCell>
              <StyledTableCell align="right">Email</StyledTableCell>
              <StyledTableCell align="right">Address</StyledTableCell>
              <StyledTableCell align="right">Action</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {user?.map((row) => (
              <StyledTableRow key={row.id}>
                <StyledTableCell component="th" scope="row">
                  {row.name}
                </StyledTableCell>
                <StyledTableCell align="right">{row.username}</StyledTableCell>
                <StyledTableCell align="right">{row.email}</StyledTableCell>
                <StyledTableCell align="right">{row.address}</StyledTableCell>
                <StyledTableCell align="right">
                  <button
                    style={{ backgroundColor: "blue" }}
                    onClick={() => navigate(`/edit/${row.id}`)}
                  >
                    edit
                  </button>
                  &nbsp;
                  <button style={{ backgroundColor: "red" }} onClick={() =>deleteUser(row.id)}>delete</button>
                </StyledTableCell>
              </StyledTableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default Users;

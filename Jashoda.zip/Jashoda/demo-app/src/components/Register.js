import React from 'react'
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import './login.css'
import { Button,  FormLabel, TextField } from '@mui/material';
import { useDispatch } from 'react-redux';
import { registerForm } from '../redux/action';
import { useNavigate } from 'react-router-dom';

const SignupSchema = Yup.object().shape({
    email: Yup.string().email('invalid email')
      .min(2, 'Too Short!')
      .max(50, 'Too Long!')
      .required('Required'),
      password: Yup.string()
      .required('Please create a stronger password') 
      .min(8, 'Password is too short - should be 8 chars minimum.')
      .matches(/[a-zA-Z]/, 'Password can only contain Latin letters.'),
    confirmPassword: Yup.string().oneOf([Yup.ref("password"), null], "Passwords must match")
    .required("Required"),
    dob: Yup.string().required('Required'),
    gender: Yup.string().required('Required'),
  });
const Register = () => {
  const dispatch=useDispatch();
  const navigate=useNavigate();
  return (
    <>
    <div className='form'>
    <div >
        <h2>Registration Form </h2> </div>
    <div>
         <Formik
       initialValues={{
         email: '',
         password: '',
         confirmPassword: '',
         dob:'',
         gender:''
       }}
       validationSchema={SignupSchema}
       onSubmit={values => {
        dispatch(registerForm(values));
        navigate('/login')
         console.log(values);
       }}
     >
       {({ errors, touched,handleChange,submitForm  }) => (
         <Form onSubmit={submitForm} >
              <FormLabel>Email</FormLabel>
           <TextField fullWidth name="email" onChange={handleChange}/>
           {errors.email && touched.email ? (
             <div style={{ color: 'red' }}>{errors.email}</div>
           ) : null}
            <FormLabel>Password</FormLabel>
           <TextField fullWidth name="password" type="password" onChange={handleChange} />
           {errors.password && touched.password ? (
             <div style={{ color: 'red' }}>{errors.password}</div>
           ) : null}
            <FormLabel>Conform Password</FormLabel>
           <TextField name="confirmPassword" fullWidth type="password" onChange={handleChange} />
           {errors.confirmPassword && touched.confirmPassword ? <div style={{ color: 'red' }}>{errors.confirmPassword}</div> : null}
           <FormLabel>DOB</FormLabel>
           <TextField name="dob" fullWidth type="date" onChange={handleChange}/>
           {errors.dob && touched.dob ? <div style={{ color: 'red' }}>{errors.dob}</div> : null}
           <FormLabel>Gender</FormLabel>
           <TextField name="gender" fullWidth type="gender" onChange={handleChange} />
           {errors.gender && touched.gender ? <div style={{ color: 'red' }}>{errors.gender}</div> : null}
           <Button type="button"  onClick={submitForm} variant='contained'style={{marginTop:20}} >Submit</Button>
         
         </Form>
       )}
     </Formik>
    </div>
    </div>
    </>
  )
}

export default Register
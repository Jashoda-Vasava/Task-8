
import React from 'react'
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import './login.css'
import { Box, Button,  FormLabel, TextField } from '@mui/material';
import { loginForm } from '../redux/action';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';

const SignupSchema = Yup.object().shape({
    email: Yup.string().email('invalid email')
      .min(2, 'Too Short!')
      .max(50, 'Too Long!')
      .required('Required'),
      password: Yup.string()
      .required('Please create  password') 
      .min(8, 'Password is too short - should be 8 chars minimum.')
      .matches(/[a-zA-Z]/, 'Password can only contain Latin letters.'),
  });
  
const Login = () => {
  const dispatch=useDispatch();
  const navigate=useNavigate();
  return (
    <>
    <Box  >
    <div className='form'>
    <div >
        <h2 style={{ alignContent:'flex',}}>Login Form </h2> </div>
    <div>
         <Formik
       initialValues={{
         email: '',
         password: '',
                }}
       validationSchema={SignupSchema}
       onSubmit={values => {
         dispatch(loginForm(values))
         navigate('/')
         console.log(values);
       }}
     >
       {({ errors, touched,handleChange,submitForm }) => (
         <Form onSubmit={submitForm}>
          
      <FormLabel>Email:</FormLabel>
           <TextField fullWidth name="email" type="email" onChange={handleChange}/>
           {errors.email && touched.email ? (
             <div style={{ color: 'red' }}>{errors.email}</div>
           ) : null}
            <FormLabel>Password:</FormLabel>
           <TextField fullWidth type = 'password' name="password"  onChange={handleChange} />
           {errors.password && touched.password ? (
             <div style={{ color: 'red' }}>{errors.password}</div>
           ) : null}
          <Button  variant="contained"  style={{marginTop:20}} type='button' onClick={submitForm}>Submit</Button>
  
         </Form>
       )}
     </Formik>
    </div>
    </div>
  
    
      
     
        </Box>
    </>
  )
}

export default Login
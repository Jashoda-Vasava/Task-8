import axios from 'axios';
import React from 'react'
import { GET_USER, LOGIN, REGISTER } from './actiontype';


export const registerForm = (user) => async (dispatch) => {
  try {
    const res = await axios.post("http://localhost:3003/user",user);
    console.log(res,"responses");
    dispatch({
      type: REGISTER,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
};
export const loginForm = (user) => async (dispatch) => {
  try {
    const res = await axios.post("http://localhost:3003/login",user);
    console.log(res,"responses");
    dispatch({
      type: LOGIN,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
}
export const getUser = (user) => async (dispatch) => {
  try {
    const res = await axios.get("http://localhost:3003/login");
    console.log(res,"responses");
    dispatch({
      type: GET_USER,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
}

import { GET_USER, LOGIN, REGISTER } from './actiontype';
const reducer = (state=[],action) => {
  switch (action.type) {
    case REGISTER:
      return {...state,
       user: action.payload};
    case LOGIN:
      return [...state,
         action.payload];
    case GET_USER:
      return {...state,
       user: action.payload};
    default:
      return state;
}}

export default reducer;
import { createStore,applyMiddleware,compose } from 'redux';
import rootReducer from './combReducer'
import ReduxThunk from 'redux-thunk'
const initialState = {};

const middlewares = [ReduxThunk];
const store = createStore(
  rootReducer,
  compose(applyMiddleware(...middlewares)),
)
export default store
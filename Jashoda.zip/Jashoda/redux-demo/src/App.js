import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashbord from './components/dashbord/Dashbord';
import Register from './components/registerForm/Register';
import Login from './components/login/Login';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import React from 'react';

function App() {
  return (
    <div className="App">
      <React.Suspense>
       <ToastContainer
      position="top-right"
      autoClose={5000}
      hideProgressBar={false}
      newestOnTop={false}
      closeOnClick
      rtl={false}
      pauseOnFocusLoss
      draggable
      pauseOnHover
      theme="light"
      />
      <Router>
        <Routes>
          <Route path='/' element={<Dashbord/>}/>
          <Route path='/register' element={<Register/>}/>
          <Route path='/login' element={<Login/>}/>
          
        </Routes>
      </Router>
      </React.Suspense>
    </div>
  );
}

export default App;

import React, {  } from 'react'
import {  useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom';
import Login from '../login/Login';
import Logout from '../login/Logout';

const Dashbord = () => {
  const users  =useSelector((state)=>state.user)
  console.log(users,"dashborad");
  const user =useSelector((state)=>state.users)
  console.log(user,"users");

 const data= JSON.parse(localStorage.getItem('users'))
 console.log(data,"data");
 const navigation=useNavigate();
  return (
    <div>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
  <div className="container-fluid">
    <form className="d-flex input-group w-auto">
      <input
        type="search"
        className="form-control rounded"
        placeholder="Search"
        aria-label="Search"
        aria-describedby="search-addon"
      />
      <span className="input-group-text text-white border-0" id="search-addon">
        <i className="fas fa-search"></i>
      </span>
      <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>
  <div className="collapse navbar-collapse" id="navbarNavDropdown">
    <ul className="navbar-nav">
      <li className="nav-item active">
        <a className="nav-link"   onClick={(e)=>{e.preventDefault(); navigation('/register')}} type ="link">Register <span className="sr-only">(current)</span></a>
      </li>
      <li className="nav-item">
        <a className="nav-link"   onClick={(e)=>{e.preventDefault(); navigation('/login')}} type ="link">Login</a>
      </li>
      </ul>
     
      </div>
      </form>
  </div>
</nav>
<div className="p-5 text-center bg-light">
    
    <h4 className="mb-3">Welcome to Dashboard <br/>   </h4>
      <h5> {user.email}</h5>
      <h5>{user.password}</h5>
      <h5>{users.gender}</h5>
      {user ?<Logout/>:<Login/>}
 

    
  </div>
    </div>
  )
}

export default Dashbord
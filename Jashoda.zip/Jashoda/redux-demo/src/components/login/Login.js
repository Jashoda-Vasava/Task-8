/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Forms } from "../../redux/action/action/action";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const Login = () => {
   const [users,setUsers]= useState({
    email:'',
    password:'',
  });
  const [error,setError] = useState(true
  )
   const login = useSelector((state) =>state.user);

  const dispatch = useDispatch();
  const navigation=useNavigate(); 

  const handleChange = (e) =>{
    setUsers({...users,[e.target.name]:e.target.value} );
  }

  const handleSubmit=(e)=>{ 
    e.preventDefault();
      const data=login?.find(user=>user.email===users.email && user.password===users.password) 
      if (data) {
      dispatch(Forms.loginForm(users));
      navigation('/')
      toast.success("🦄 Login Susscessfully!", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      })
    
      return ;
          }else{
            toast.error("Please enter valid information!", {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
              theme: "light",
            });
        // alert("Please enter valid information");
        return;
      }
      }
  return (
    <>
      <section className="vh-100" style={{ backgroundColor: " #9A616D" }}>
        <div className="container py-5 h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col col-xl-10">
              <div className="card" style={{ borderRadius: " 1rem;" }}>
                <div className="row g-0">
                  <div className="col-md-6 col-lg-5 d-none d-md-block">
                    <img
                      src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/img1.webp"
                      alt="login form"
                      className="img-fluid"
                      style={{ borderRadius: " 1rem 0 0 1rem;" }}
                    />
                  </div>
                  <div className="col-md-6 col-lg-7 d-flex align-items-center">
                    <div className="card-body p-4 p-lg-5 text-black">
                          <form >
                            <div className="d-flex align-items-center mb-3 pb-1">
                              <i
                                className="fas fa-cubes fa-2x me-3"
                                style={{ color: "#ff6219" }}
                              ></i>
                              <span className="h1 fw-bold mb-0">Logo</span>
                            </div>
                            <h5
                              className="fw-normal mb-3 pb-3"
                              style={{ letterSpacing: " 1px;" }}
                            >
                              Sign into your account
                            </h5>

                            <div className="form mb-4">
                              <label
                                className="form-label"
                                for="form2Example17"
                              >
                                Email address
                              </label>
                              <input
                                className="form-control form-control-lg"
                                type="email"
                                name="email"
                                value={users.email}
                                onChange={handleChange}
                              />
                              {error &&
                <div style={{ color: "red", paddingBottom: 10 }}>{error}</div>
              }

                            </div>
                            <div className="form mb-4">
                              <label
                                className="form-label"
                                for="form2Example27"
                              >
                                Password
                              </label>
                              <input
                                type="password"
                                id="form2Example27"
                                className="form-control form-control-lg"
                                name="password"
                              value={users.password}
                              onChange={handleChange}
                              />
                           
                            </div>

                            <div className="pt-1 mb-4">
                              <button
                                className="btn btn-dark btn-lg btn-block"
                                type="button"
                                onClick={handleSubmit}
                              >
                                Login
                              </button>
                            </div>

                            <a className="small text-muted" href="#!">
                              Forgot password?
                            </a>
                            <p
                              className="mb-5 pb-lg-2"
                              style={{ color: " #393f81;" }}
                            >
                              Don't have an account?
                              &nbsp; <a onClick={(e)=>{e.preventDefault(); navigation('/register')}} type ="link" class="btn-link border-0 " >
                                Register here
                              </a>
                            </p>
                            <a onClick={(e)=>{e.preventDefault(); navigation('/')}} type ="link" class="btn-link border-0 " >
                               Dashbord
                              </a>
                          </form>
                     
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Login;

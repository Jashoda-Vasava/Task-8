
import React from 'react'
import { useDispatch } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { Forms } from '../../redux/action/action/action'

const Logout = () => {
    const dispatch=useDispatch()
    const navigate=useNavigate();
    const handlerLogout =(e)=>{
        e.preventDefault()
        dispatch(Forms.logoutForm())
        navigate('/login')
    }
  return (
    <div>
        <button variant='primary' onClick={handlerLogout}>Logout</button>
    </div>
  )
}

export default Logout
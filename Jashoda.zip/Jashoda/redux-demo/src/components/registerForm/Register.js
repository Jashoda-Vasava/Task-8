import React, { useEffect, useRef } from "react";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { Forms } from "../../redux/action/action/action";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const SignupSchema = Yup.object().shape({
  email: Yup.string()
    .email("Invalid email")
    .required(" Please enter email address")
    .matches(/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i, "Invalid email format"),
  password: Yup.string()
    .required("Please enter password")
    .min(8, "Password is too short - should be 8 chars minimum.")
    .matches(/[a-zA-Z]/, "Password can only contain Latin letters."),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref("password"), null], "Passwords must match")
    .required("Please enter confirmPassword"),
  bod: Yup.string().required(" Please enter birth of date"),
  gender: Yup.string().required("Please enter gender"),
});

const Register = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user =useSelector((state) => state.user)
  console.log(user,"usersregister");


  return (
    <div>
      <section className="vh-100" style={{ backgroundColor: " #9A616D" }}>
        <div className="container py-5 h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col col-xl-10">
              <div className="card" style={{ borderRadius: " 1rem;" }}>
                <div className="row g-0">
                  <div className="col-md-6 col-lg-5 d-none d-md-block">
                    <img
                      src="https://mdbootstrap.com/img/new/ecommerce/vertical/004.jpg"
                      alt="register form"
                      className="img-fluid"
                      style={{ borderRadius: " 1rem 0 0 1rem;" }}
                    />
                  </div>
                  <div className="col-md-6 col-lg-7 d-flex align-items-center">
                    <div className="card-body p-4 p-lg-5 text-black">
                      <Formik
                        initialValues={{
                          email: "",
                          password: "",
                          confirmPassword: "",
                          bod: "",
                          gender: "",
                        }}
                        validationSchema={SignupSchema}
                        onSubmit={(values) => {
                          dispatch(Forms.registerForm(values));
                          localStorage.setItem('users', JSON.stringify(values))
                         navigate('/login')
                          if (values) {
                            toast.success("🦄 Register Susscessfully!", {
                              position: "top-right",
                              autoClose: 5000,
                              hideProgressBar: false,
                              closeOnClick: true,
                              pauseOnHover: true,
                              draggable: true,
                              progress: undefined,
                              theme: "light",
                            });
                          } else {
                            toast.error("🦄 Wow so easy!", {
                              position: "top-right",
                              autoClose: 5000,
                              hideProgressBar: false,
                              closeOnClick: true,
                              pauseOnHover: true,
                              draggable: true,
                              progress: undefined,
                              theme: "light",
                            });
                          }

                         
                        }}
                        
                      >
                        {({ errors, touched, handleChange, submitForm }) => (
                          <Form onSubmit={(e)=>{ e.preventDefault(); submitForm()}}>
                            <div className="d-flex align-items-center mb-3 pb-1">
                              <i
                                className="fas fa-cubes fa-2x me-3"
                                style={{ color: "#ff6219;" }}
                              ></i>
                              <span className="h1 fw-bold mb-0">Logo</span>
                            </div>
                            <h5
                              className="fw-normal mb-3 pb-3"
                              style={{ letterSpacing: " 1px;" }}
                            >
                              Sign up to your account
                            </h5>

                            <div className="form mb-4">
                              <label className="form-label" for="">
                                Email address
                              </label>
                              <input
                                type="email"
                                id="form3Example3"
                                className="form-control"
                                onChange={handleChange}
                                name="email"
                              />
                              {errors.email && touched.email ? (
                                <div style={{ color: "red" }}>
                                  {errors.email}
                                </div>
                              ) : null}
                            </div>

                            <div className="form mb-4">
                              <label className="form-label" for="">
                                Password
                              </label>
                              <input
                                type="password"
                                id="form3Example4"
                                className="form-control"
                                name="password"
                                onChange={handleChange}
                              />
                              {errors.password && touched.password ? (
                                <div style={{ color: "red" }}>
                                  {errors.password}
                                </div>
                              ) : null}
                            </div>

                            <div className="form mb-4">
                              <label className="form-label" for="form3Example5">
                                ConfirmPassword
                              </label>
                              <input
                                type="password"
                                id="form3Example5"
                                className="form-control"
                                name="confirmPassword"
                                onChange={handleChange}
                              />
                              {errors.confirmPassword &&
                              touched.confirmPassword ? (
                                <div style={{ color: "red" }}>
                                  {errors.confirmPassword}
                                </div>
                              ) : null}
                            </div>
                            <div className="form mb-4">
                              <label className="form-label" for="form3Example6">
                                Birth of Date
                              </label>
                              <input
                                type="date"
                                id="form3Example6"
                                className="form-control"
                                name="bod"
                                onChange={handleChange}
                              />
                              {errors.bod && touched.bod ? (
                                <div style={{ color: "red" }}>{errors.bod}</div>
                              ) : null}
                            </div>
                            <div className="form mb-4">
                              <label className="form-label" for="form3Example7">
                                Gender
                              </label>
                              <input
                                type="gender"
                                id="form3Example7"
                                className="form-control"
                                name="gender"
                                onChange={handleChange}
                              />
                              {errors.gender && touched.gender ? (
                                <div style={{ color: "red" }}>
                                  {errors.gender}
                                </div>
                              ) : null}
                            </div>

                            <button
                              type="button"
                              className="btn btn-primary btn-block mb-4"
                              onClick={submitForm}
                            >
                              Sign up
                            </button>

                            <p
                              className="mb-5 pb-lg-2 "
                              style={{ color: " #393f81;"}}
                            >
                              Already Registered  
                              &nbsp; <a onClick={(e)=>{e.preventDefault(); navigate('/login')}} type ="link" class="btn-link border-0 " >
                                Login here
                              </a>
                            </p>
                          </Form>
                        )}
                      </Formik>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Register;

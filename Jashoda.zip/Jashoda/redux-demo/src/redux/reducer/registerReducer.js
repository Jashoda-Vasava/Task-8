const initialState ={
data:[]
}

const registerData = (state = [], action) => {
  switch (action.type) {
    case "REGISTER_USER":
      console.log(action.payload,"registerreduce");
      return [...state ,{ 
      bod: action.payload.users.bod,
      confirmPassword: action.payload.users.confirmPassword,
      email: action.payload.users.email,
      gender: action.payload.users.gender,
      password: action.payload.users.password,
        }];
   
    default:
      return state;
  }
};
export default registerData;

const initialState ={
    data:[]
    }
    
    const loginReducer = (state = [], action) => {
      switch (action.type) {
        case "LOGIN_USER":
          console.log(action.payload, "reducer state");
          return {
            ...state,
            email: action.payload.login.email,
            password: action.payload.login.password}
        
          case "LOGOUT_USER":
            console.log(state, "reducer state");
           
            return {
              ...state,
              email: null,
              password:null
          
            };
     
        default:
          return state;
      }
    };
    export default loginReducer;
    
import { combineReducers } from 'redux'
import loginReducer from './loginReducer'
import registerData from './registerReducer'


const demoApp = combineReducers({
   user: registerData,
   users:loginReducer
})

export default demoApp
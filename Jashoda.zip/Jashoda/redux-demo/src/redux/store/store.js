import { applyMiddleware, compose, createStore } from "redux";
import reducer from "../reducer/index"
import thunk from "redux-thunk";
const configureStore = () => {
    return createStore(
        reducer,
      compose(applyMiddleware(thunk))
    );
  };
  
  export default configureStore;
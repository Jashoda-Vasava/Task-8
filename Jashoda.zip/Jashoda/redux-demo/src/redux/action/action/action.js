import { LOGIN_USER,  LOGOUT_USER,  REGISTER_USER } from "../actionType/types";

export const Forms = {
  registerForm: (users) => ({ type: REGISTER_USER , payload: { users }}),
  loginForm: (login) => ({ type: LOGIN_USER, payload: { login } })    ,
    logoutForm:(login)=> ({type:LOGOUT_USER,payload:{login}})
  }

import axios from "axios";
import * as Constants from "../Common/Global/url";
import * as Constant from "../Common/Global/constants";

// Set Token in localstorage
localStorage.setItem("token",Constant.TOKEN);

//Axios create config
export default axios.create({
  baseURL: Constants.BASE_URL_API,
  headers: {
    "Content-type": "application/json",
    "Authorization": ` Bearer ${Constant.TOKEN}`,
  },
});

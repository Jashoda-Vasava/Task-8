import React, { useEffect, useState } from "react";
import { Container, Row } from "react-bootstrap";
import "../../Common/common.css";
import Buttons from "../../Components/Buttons/buttons";
import Download from "../../Components/Download/download";
import ImageText from "../../Components/ImageText/imageText";
import KeyFeture from "../../Components/KeyFeture/keyFeture";
import "./jobSeeker.css";
import Accordion from "react-bootstrap/Accordion";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";

export default function JobSeeker() {
  const [faqData, setFaqData] = useState([]);

  useEffect(() => {
    getFaqDetails();
  }, []);

  /******************** API CALL  START HERE **************************/
  const getFaqDetails = () => {
    axiosInstance
      .post(`${Constants.GetFAQ}`, {
        applicableto: "Job Seeker",
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setFaqData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/
  
  return (
    <Container fluid>
      <Download />
      <Container className="my100">
        <ImageText
          Heading="Lorem Ipsum is simply dummy text of"
          Content="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's Lorem Ipsum is simply dummy text of the printing and typesetting induhas been the industry's ."
        />
      </Container>
      <div className="bgOffWhite py100 text-center">
        <h1 className="w700 textGray">
          How To Get Your <span className="textPrime">Dream</span>Job
        </h1>
        <div className="seekerImageContainer mt50 mb-3">
          <div className="oneStep">
            <img src="/assets/images/seeker1.png" alt=""/>
            <p className="w500 textGray mt-2">#1 Build Your Profile</p>
          </div>
          <div className="oneStep">
            <img src="/assets/images/seeker2.png" alt=""/>
            <p className="w500 textGray mt-2">#2 Apply for jobs</p>
          </div>
          <div className="oneStep">
            <img src="/assets/images/seeker3.png" alt=""/>
            <p className="w500 textGray mt-2">#3 Get Your Dream Job</p>
          </div>
        </div>
        <Buttons
          bgColor="Prime"
          textColor="White"
          content="Get Hired"
          hover="greenHover"
        />
      </div>
      <Container className="my100">
        <ImageText
          Heading="Lorem Ipsum is simply dummy text of"
          Content="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's Lorem Ipsum is simply dummy text of the printing and typesetting induhas been the industry's."
        />
      </Container>
      <Container>
        <div className="py100 text-center">
          <h1 className="w700 textGray mb-5">
            Our Key <span className="textPrime">Features</span>
          </h1>
          <Row>
            <div className="col-md-4 d-flex justify-content-center">
              <KeyFeture
                content="Direct Communication with Recruiters"
                path="chat.png"
              />
            </div>
            <div className="col-md-4 d-flex justify-content-center">
              <KeyFeture
                content="AI Powered Job Recommendations"
                path="ai.png"
              />
            </div>
            <div className="col-md-4 d-flex justify-content-center">
              <KeyFeture
                content="Built In Video Call Function"
                path="vcall.png"
              />
            </div>
          </Row>
        </div>
      </Container>
      <Container fluid>
        <h1 className="w700 textPrime text-center">
          FAQ<span className="textGray">s</span>
        </h1>
        {faqData?.map((item) => (
          <div className="faq_accordian">
            <Accordion defaultActiveKey="0">
              <Accordion.Item>
                <Accordion.Header>{item?.question}</Accordion.Header>
                <Accordion.Body>
                  <p className="mb-0 textJustify">{item?.answer}</p>
                </Accordion.Body>
              </Accordion.Item>
              <hr className="mx-3"/>
            </Accordion>
          </div>
        ))}
      </Container>
    </Container>
  );
}

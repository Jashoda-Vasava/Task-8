import React from "react";
import "./pricing.css";
import "../../Common/common.css";
import { Container, Row } from "react-bootstrap";
import Download from "../../Components/Download/download";
import PricingPlanCard from "../../Components/PricingPlanCard/pricingPlanCard";

export default function Pricing() {
  return (
    <>
      <Container>
        <Row className="py50">
          <h1 className="text-center w700 textGray mb-5">
            Our <span className="textPrime"> Plans</span>
          </h1>
          <div className="col-md-4">
            <div className="hoverUP">
              <PricingPlanCard />
            </div>
          </div>
          <div className="col-md-4">
            <div className="hoverUP">
              <PricingPlanCard />
            </div>
          </div>
          <div className="col-md-4">
            <div className="hoverUP">
              <PricingPlanCard />
            </div>
          </div>
        </Row>
      </Container>
      <Download />
    </>
  );
}

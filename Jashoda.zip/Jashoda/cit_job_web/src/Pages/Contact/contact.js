import React from "react";
import { Container, Row } from "react-bootstrap";
import Download from "../../Components/Download/download";
import Input from "../../Components/Input/input";
import "./contact.css";
import "../../Common/common.css";
import Buttons from "../../Components/Buttons/buttons";

export default function Contact() {
  return (
    <>
      <Container>
        <Row className="my100">
          <h2 className="mb-4 w700 textGray">Get in touch</h2>
          <div className="col-md-6">
            <Input placeHolder="Your Name"/>
          </div>
          <div className="col-md-6">
            <Input placeHolder="Mobile No."/>
          </div>
          <div className="col-md-6">
            <Input placeHolder="Email"/>
          </div>
          <div className="col-md-6">
            <Input placeHolder="Subject"/>
          </div>
          <div className="col-12">
            <textarea
              className="w-100 borderNone outlineNone ps-3 pt-3 bgOffWhite textAreaContact"
              placeholder="Description"
            ></textarea>
          </div>
          <div className="col-12 text-center mt-3">
            <Buttons
              bgColor="Prime"
              textColor="White"
              content="Send"
              hover="greenHover"
            />
          </div>
        </Row>
      </Container>
      <Download />
    </>
  );
}

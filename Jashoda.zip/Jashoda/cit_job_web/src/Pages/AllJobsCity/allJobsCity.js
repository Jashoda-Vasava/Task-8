import React, { useEffect, useState } from "react";
import { Container, Row } from "react-bootstrap";
import { Link } from "react-router-dom";
import "../../Common/common.css";
import JobAndCity from "../../Components/JobAndCity/jobAndCity";
import SearchBar from "../../Components/SearchBar/searchBar";
import axiosInstance from "../../Api/commonUrl";
import swal from "sweetalert";
import * as Constants from "../../Common/Global/constants";

export default function AllJobsCity() {
  const [cityData, setCityData] = useState([]);
  const [geteducationData, setEducationData] = useState([]);

  useEffect(() => {
    getEducation();
    getCityMaster();
  }, []);

  /******************** API CALL START HERE **************************/
  const getEducation = () => {
    axiosInstance
      .post(`${Constants.GetEducation}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setEducationData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getCityMaster = () => {
    axiosInstance
      .post(`${Constants.GetCityMaster}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setCityData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  /******************** API CALL END HERE **************************/
  return (
    <Container>
      <div className="d-flex justify-content-center mt50">
        <SearchBar />
      </div>
      <Row>
        <h1 className="text-center textGray w700 mb50">
          Job <span className="textPrime">Categories</span>
        </h1>
        {geteducationData?.map((item) => (
          <div className="col-md-3 col-lg-3">
            <Link className="linkNone" to="/categorydetails">
              <JobAndCity name={item?.name} candidate="214K"/>
            </Link>
          </div>
        ))}
      </Row>
      <Row>
        <h1 className="text-center textGray w700 my50">
          All <span className="textPrime">Cities</span>
        </h1>
        {cityData?.map((item) => (
          <div className="col-md-4 col-lg-3">
            <JobAndCity name={item.city} candidate="214K"/>
          </div>
        ))}
      </Row>
    </Container>
  );
}

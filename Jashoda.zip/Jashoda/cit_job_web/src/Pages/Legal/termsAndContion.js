import React, { useEffect, useState } from "react";
import { Container, Row } from "react-bootstrap";
import Download from "../../Components/Download/download";
import "./legal.css";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";

export default function TermsAndContion() {
  const [termsData, setTermsData] = useState([]);

  useEffect(() => {
    termsConditions();
  }, []);

  /******************** API CALL START HERE **************************/
  const termsConditions = () => {
    axiosInstance
      .post(`${Constants.GetStaticPages}`, {
        pagecode: "terms_conditions",
        isactive: "Y",
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setTermsData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  /******************** API CALL END HERE **************************/
  return (
    <>
      <Container>
        <Row>
          {termsData?.map((item) => (
            <div>
              <div className="col-12 my50">
                <h2 className="textGray w700">{item?.pagetitle}</h2>
              </div>
              <div className="col-12 mb50">
                <p
                  className="textJustify textLightGray w500 tAndCPera"
                  dangerouslySetInnerHTML={{__html: item?.content}}
                ></p>
              </div>
            </div>
          ))}
        </Row>
      </Container>
      <Download />
    </>
  );
}

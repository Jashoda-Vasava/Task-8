/* eslint-disable jsx-a11y/anchor-is-valid */
import { React, useEffect, useState } from "react";
import { Container, Row } from "react-bootstrap";
import "../../Common/common.css";
import "./landingpage.css";
import Download from "../../Components/Download/download";
import JobAndCity from "../../Components/JobAndCity/jobAndCity";
import Buttons from "../../Components/Buttons/buttons";
import Slider from "react-slick";
import Card from "../../Components/Card/card";
import SearchBar from "../../Components/SearchBar/searchBar";
import { Link } from "react-router-dom";
import DownloadModal from "../../Components/DownloadModal/downloadModal";
import axiosInstance from "../../Api/commonUrl";
import swal from "sweetalert";
import * as Constants from "../../Common/Global/constants";

export default function Landingpage() {
  const [show, setShow] = useState(false);
  const [headerData, setHeaderData] = useState([]);
  const [infoData, setInfoData] = useState([]);
  const [mediaData, setMediaData] = useState([]);
  const [recruitmentData, setRecruitmentData] = useState([]);
  const [videodetailData, setVideodetailData] = useState([]);
  const [dynamicImageData, setDynamicImageData] = useState([]);
  const [cityData, setCityData] = useState([]);
  const [geteducationData, setEducationData] = useState([]);

  useEffect(() => {
    getWebsiteHomePageHeader();
    getWebsiteHomePageInfo();
    getEducation();
    getVideoDetail();
    getCityMaster();
    getWebsiteRecruitmentPartners();
    getWebsiteMediaCoverage();
    getDynamicImage();
  }, []);

  /******************** API CALLS START HERE **************************/

  const getWebsiteHomePageHeader = () => {
    axiosInstance
      .post(`${Constants.SaveHomePageHeader}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setHeaderData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getWebsiteHomePageInfo = () => {
    axiosInstance
      .post(`${Constants.GetHomePageInfo}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setInfoData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getEducation = () => {
    axiosInstance
      .post(`${Constants.GetEducation}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setEducationData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getVideoDetail = () => {
    axiosInstance
      .post(`${Constants.GetVideoDetail}`, {
        pagecode: "HOME_PAGE",
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setVideodetailData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getCityMaster = () => {
    axiosInstance
      .post(`${Constants.GetCityMaster}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setCityData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getWebsiteRecruitmentPartners = () => {
    axiosInstance
      .post(`${Constants.GetRecruitmentPartners}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setRecruitmentData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getWebsiteMediaCoverage = () => {
    axiosInstance
      .post(`${Constants.GetMediaCoverage}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setMediaData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getDynamicImage = () => {
    axiosInstance
      .post(`${Constants.GetDynamicImage}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setDynamicImageData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  /******************** API CALLS END HERE **************************/

  /******************** SLIDERS START HERE **************************/

  const videoSlider = {
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2500,
    arrow: false,
  };

  const recruiterSlider = {
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1350,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1080,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
    ],
  };

  const mediaCoverageSlider = {
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1350,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1080,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  /******************** SLIDERS END HERE **************************/

  /******************** SLIDERS FUNCTION START HERE **************************/
  const videosData = () => {
    return videodetailData?.map((item) => {
      return (
        <>
          <Container fluid>
            <Row>
              <div className="col-md-6">
                <video
                  src={item?.videourl}
                  controls
                  loop
                  className="w-100"
                ></video>
              </div>
              <div className="col-md-6 sideTextContainer textJustify ">
                <h3 className="textGray w700 videoTextHeading">
                  {item?.header}
                </h3>
                <p
                  className="textLightGray w500 my-4"
                  dangerouslySetInnerHTML={{ __html: item?.description }}
                ></p>
                {/* <Buttons bgColor="Prime" textColor="White" content="Learn More" hover="greenHover"/> */}
              </div>
            </Row>
          </Container>
        </>
      );
    });
  };
  /******************** SLIDERS FUNCTION END HERE **************************/

  return (
    <Container fluid>
      <Container>
        <div className="herosection">
          <h1
            className="text-center mt100 w700 textGray"
            dangerouslySetInnerHTML={{ __html: headerData[0]?.header }}
          ></h1>
          <p
            className="text-center mt-5 w500 textLightGray"
            dangerouslySetInnerHTML={{ __html: headerData[0]?.description }}
          ></p>
          <div className="d-flex justify-content-center">
            <SearchBar />
          </div>
          <div className="featureWrap">
            <Row>
              {infoData?.slice(0, 4)?.map((item) => (
                <div className="col-md-3 col-12">
                  <div className="text-center">
                    <img src={item?.iconimage} alt="" className="infoData"/>
                    <p className="textGray w700 mt-2 font14">
                      {item?.count}
                      <p
                        className="textGray w700 font14"
                        dangerouslySetInnerHTML={{ __html: item?.description }}
                      ></p>
                    </p>
                  </div>
                </div>
              ))}
            </Row>
          </div>
        </div>
      </Container>
      <Download />
      <Container>
        <div className="TrendingSection">
          <h1 className="text-center mt100 w700 textGray">
            <span className="textPrime">Trending</span> Job Categories
          </h1>
          <Row className="mt50">
            {geteducationData?.slice(0, 7)?.map((item) => (
              <div className="col-md-4 col-lg-3">
                <JobAndCity name={item?.name} candidate="214K"/>
              </div>
            ))}
            <div className="col-md-3">
              <div className="bgOffWhite text-center jobAndCityBoxContainer">
                <Link className="textGray font18 w700 linkNone" to="alljobs">
                  View All
                </Link>
              </div>
            </div>
          </Row>
        </div>
      </Container>
      <div className="section4">
        <Row>
          <div className="col-lg-6 section4Box bgOffWhite">
            <h3 className="w700 textGray text-center">
              Chat <span className="textPrime">Directly</span> with
              Decision-Maker
            </h3>
            <Buttons
              bgColor="Prime"
              textColor="White"
              content="Get Hired"
              hover="greenHover"
            />
          </div>
          <div className="col-lg-6 section4Box bgPrime">
            <h3 className="w700 textWhite text-center">
              Hire <span className="textGray">Instantly</span>with Job-Portal
            </h3>
            <Buttons
              bgColor="White"
              textColor="Prime"
              content="Hire Talent"
              hover="whiteHover"
            />
          </div>
        </Row>
      </div>
      <Container className="my100">
        <Slider {...videoSlider}>{videosData()}</Slider>
      </Container>
      <div className="Section6 bgOffWhite text-center">
        <h1 className="w700 textGray mt50">
          Find <span className="textPrime">Candidates</span>in Your City
        </h1>
        <div className="my50 section6ImageContainer">
          {cityData?.slice(0, 5)?.map((item) => (
            <div>
              <img
                src={dynamicImageData?.[3]?.url}
                alt=""
                className="city-icon"
              />
              <br />
              <p className="font14 w700 paragraph"> {item?.city}</p>
            </div>
          ))}
        </div>
        <Link to="alljobs">
          <Buttons
            bgColor="Prime"
            textColor="White"
            content="View All"
            hover="greenHover"
            className="mb50"
          />
        </Link>
      </div>
      <div className="Section7 bgWhite text-center">
        <h1 className="w700 textGray mt50">
          Our <span className="textPrime">Trusted</span>Recruitment Partners
        </h1>
        <div className="my50 section7ImageContainer">
          <Container>
            <Slider {...recruiterSlider}>
              {recruitmentData?.map((item) => (
                <div className="d-flex justify-content-center">
                  <div className="imagbox">
                    <img src={item?.imageurl} alt="" className="imagecrop"/>
                  </div>
                </div>
              ))}
            </Slider>
          </Container>
        </div>
      </div>
      <div className="bgOffWhite text-center pb-5">
        <h1 className="w700 textGray mt50 pt-5">
          What <span className="textPrime">People</span> Are Saying
        </h1>
        <div className="tesimonialContainer bgWhite">
          <div className="d-flex ms-3 pt-3">
            <img src="/assets/images/user1.png" className="img-fluid" alt=""/>
            <div>
              <p className="font18 textGray ms-3 w600 mb-0">
                Francis Underwood
              </p>
              <p className="font12 textPrime mb-0 w600">
                New York City , New York
              </p>
            </div>
          </div>
          <p className="text-start p-3 font14 textLightGray w500">
            dipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet
            odio mattis. Class aptent taciti sociosqu ad litora torquent per
            conubia nostra, per incept himenaeos. Curabitur tempus
          </p>
        </div>
        <div className="mt-3">
          <button className="borderNone outlineNone bgNone">
            <img src="/assets/images/prev.png" alt=""/>
          </button>
          <button className="borderNone outlineNone bgNone">
            <img src="/assets/images/next.png" alt=""/>
          </button>
        </div>
      </div>
      <div className="container">
        <div className="section8 text-center">
          <h1 className="w700 textGray mt50">
            <span className="textPrime">Media</span> Coverage
          </h1>
          <Slider {...mediaCoverageSlider} className="my100">
            {mediaData?.map((item) => (
              <div className="d-flex justify-content-center">
                <Card
                  src={item?.imageurl}
                  description={item?.description}
                />
              </div>
            ))}
          </Slider>
        </div>
      </div>
      <DownloadModal show={show} setShow={setShow} />
    </Container>
  );
}

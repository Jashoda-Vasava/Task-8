import React, { useEffect, useState } from "react";
import "./recruiter.css";
import "../../Common/common.css";
import { Container, Row } from "react-bootstrap";
import Accordion from "react-bootstrap/Accordion";
import Buttons from "../../Components/Buttons/buttons";
import Download from "../../Components/Download/download";
import ImageText from "../../Components/ImageText/imageText";
import KeyFeture from "../../Components/KeyFeture/keyFeture";
import Input from "../../Components/Input/input";
import axiosInstance from "../../Api/commonUrl"
import * as Constants from "../../Common/Global/constants"
import swal from "sweetalert";

export default function Recruiter() {
  const [faqData, setFaqData] = useState([]);

  useEffect(() => {
    getFaqDetails();
  }, []);

  /******************** API CALL START HERE **************************/
  const getFaqDetails = () => {
    axiosInstance
      .post(`${Constants.GetFAQ}`, {
        applicableto: "Recruiter",
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setFaqData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/
  
  return (
    <Container fluid>
      <Container className="py100">
        <Row>
          <div className="col-md-6">
            <h2 className="w700 textGray mb-5">
              Hire <span className="textPrime">Talent</span> Instantly !!!
            </h2>
            <img src="/assets/images/sidePhoto.png" className="w-100" alt=""></img>
          </div>
          <div className="col-md-6 text-centers ps-0 ps-md-5">
            <div className="formContainer text-center bgWhite">
              <h2 className="w700 textGray mb-5 text-start">
                Fill the <span className="textPrime">From</span> Below &
              </h2>
              <Input placeHolder="Your Name"/>
              <Input placeHolder="Email"/>
              <Input placeHolder="Mobile No."/>
              <Input placeHolder="Company's Name"/>
              <Input placeHolder="Your Designation"/>
              <Buttons
                bgColor="Prime"
                textColor="White"
                content="Submit"
                hover="greenHover"
              />
            </div>
          </div>
        </Row>
      </Container>
      <div className="bgOffWhite py100 text-center">
        <h1 className="w700 textGray">
          Hire <span className="textPrime"> Talented </span>Employees
        </h1>
        <div className="hireImageContainer mt50 mb-3">
          <div className="oneStep">
            <img src="/assets/images/seeker1.png" alt=""/>
            <p className="w500 textGray mt-2">#1 Build Your Profile</p>
          </div>
          <div className="oneStep">
            <img src="/assets/images/comp2.png" alt=""/>
            <p className="w500 textGray mt-2">#2 Post a Job</p>
          </div>
          <div className="oneStep">
            <img src="/assets/images/seeker3.png" alt=""/>
            <p className="w500 textGray mt-2">#3 Hire a Perfect Employee</p>
          </div>
        </div>
        <Buttons
          bgColor="Prime"
          textColor="White"
          content="Start Hiring"
          hover="greenHover"
        />
      </div>
      <Container className="my100">
        <ImageText
          Heading="Lorem Ipsum is simply dummy text of"
          Content="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's Lorem Ipsum is simply dummy text of the printing and typesetting induhas been the industry's ."
        />
      </Container>
      <Container>
        <div className="py50 text-center">
          <h1 className="w700 textGray mb-5">
            Our Key <span className="textPrime">Features</span>
          </h1>
          <Row>
            <div className="col-md-3 d-flex justify-content-center">
              <KeyFeture
                content="Direct Communication with Job Seekers"
                path="chat.png"
              />
            </div>
            <div className="col-md-3 d-flex justify-content-center">
              <KeyFeture content="Data Security" path="secure.png"/>
            </div>
            <div className="col-md-3 d-flex justify-content-center">
              <KeyFeture content="Conduct Video Interviews" path="vcall.png"/>
            </div>
            <div className="col-md-3 d-flex justify-content-center">
              <KeyFeture content="100% Data Security" path="secure2.png"/>
            </div>
          </Row>
        </div>
      </Container>
      <Container fluid className="py50">
        <h1 className="w700 textPrime text-center">
          FAQ<span className="textGray">s</span>
        </h1>
        {faqData?.map((item) => (
        <div className="faq_accordian">
          <Accordion >
            <Accordion.Item eventKey="0">
              <Accordion.Header>{item?.question}</Accordion.Header>
              <Accordion.Body>
                <p className="mb-0 textJustify">
                  {item?.answer}
                </p>
              </Accordion.Body>
            </Accordion.Item>
            <hr className="mx-3"/>          
          </Accordion>
        </div>
        ))}
      </Container>
      <Download />
    </Container>
  );
  //
}

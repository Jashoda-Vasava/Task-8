import React from "react";
import { Outlet } from "react-router-dom";
import Footer from "../../Components/Footer/footer";
import NavigationBar from "../../Components/NavigationBar/navigationBar";

export default function Homepage() {
  return (
    <>
      <NavigationBar />
      <div className="marginMain">
        <Outlet />
      </div>
      <Footer />
    </>
  );
}

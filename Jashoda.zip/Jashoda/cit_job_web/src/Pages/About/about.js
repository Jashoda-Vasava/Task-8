import React, { useEffect, useState } from "react";
import { Container, Row } from "react-bootstrap";
import Download from "../../Components/Download/download";
import "./about.css";
import axiosInstance from "../../Api/commonUrl";
import "../../Common/common.css";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";

export default function About() {
  const [aboutData, setAboutData] = useState([]);

  useEffect(() => {
    aboutUs();
  }, []);

  /******************** API CALL START HERE **************************/
  const aboutUs = () => {
    axiosInstance
      .post(`${Constants.GetStaticPages}`, {
        pagecode: "about_job_portal",
        isactive: "Y",
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setAboutData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/
  
  return (
    <>
      <Container>
        <Row>
          {aboutData?.map((data) => (
            <div className="text-center" dangerouslySetInnerHTML={{__html: data?.content}}></div>
          ))}
        </Row>
      </Container>
      <Download />
    </>
  );
}

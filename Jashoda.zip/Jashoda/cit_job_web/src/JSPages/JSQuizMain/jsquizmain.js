/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./jsquizmain.css";
import { Container, Row } from "react-bootstrap";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";

export default function Jsquizmain() {
  const [quizDetails, setQuizDetails] = useState([]);
  const [clickData, setClickData] = useState("");
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);

  useEffect(() => {
    geQuizDetails();
  }, []);

  /******************** API CALL START HERE **************************/
  const geQuizDetails = () => {
    axiosInstance
      .post(`${Constants.GetQuizDetail}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setQuizDetails(response.data.data);
        } else {
          swal(`${response.data.message}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  /******************** API CALL END HERE **************************/

  /******************** FUNCTION CALL START HERE **************************/
  const nextQuestions = () => {
    if (clickData === quizDetails?.[currentQuestion]?.correctoption) {
      setScore(score + 1);
    }
    if (currentQuestion < quizDetails?.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setClickData("");
    } else {
      setShowResults(true);
    }
    let allRadio = document.querySelectorAll(".optionGroup");
    allRadio.forEach((value) => (value.checked = false));
  };

  const resetData = () => {
    setShowResults(false);
    setCurrentQuestion(0);
    setClickData("");
    setScore(0);
  };
  /******************** FUNCTION CALL END HERE **************************/

  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="breadcrubsContainer bgWhite p-3">
                      <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                          <li class="breadcrumb-item">
                            <a href="#" className="linkNone textLightGray w600">
                              My Account
                            </a>
                          </li>
                          <li class="breadcrumb-item">
                            <a href="#" className="linkNone textLightGray w600">
                              My Quiz
                            </a>
                          </li>
                          <li class="breadcrumb-item">
                            <a href="#" className="linkNone textGray w600">
                              {quizDetails?.[currentQuestion]?.name}
                            </a>
                          </li>
                        </ol>
                      </nav>
                    </div>
                  </div>
                </Row>
                {showResults ? (
                  <Row>
                    <div className="col-md-6">
                  <div className="quizQestionContainer w-100 p-3 bgWhite mt-4">
                  <h4 className="mb-4">
                    you have scored {score} out of {quizDetails?.length}
                    </h4>
                    <br/>
                    <button onClick={resetData} className="border bgPrime2 px-3 py-2"> Play Again!!</button>
                  </div>
                  </div>
                  </Row>
                ) : (
                  <Row>
                    <div className="col-md-6">
                      <div className="quizQestionContainer w-100 p-3 bgWhite mt-4">
                        <p className="text-end textLightGray w60">
                          {currentQuestion} /{quizDetails?.length}
                        </p>
                        <div>
                          <h4 className="mb-4">
                            {currentQuestion + 1}.
                            {quizDetails?.[currentQuestion]?.questions}
                          </h4>
                          <input
                            type="radio"
                            id="1"
                            name="fav_language"
                            value={quizDetails?.[currentQuestion]?.option1}
                            className="optionGroup"
                            onClick={(e) =>
                              setClickData(
                                quizDetails?.[currentQuestion]?.option1
                              )
                            }
                          />
                          <label for="1" className="ms-3 w600 textPrime2">
                            {quizDetails?.[currentQuestion]?.option1}
                          </label>
                          <hr className="optionHr" />
                          <input
                            type="radio"
                            id="2"
                            name="fav_language"
                            value={quizDetails?.[currentQuestion]?.option2}
                            className="optionGroup"
                            onClick={() =>
                              setClickData(
                                quizDetails?.[currentQuestion]?.option2
                              )
                            }
                          />
                          <label for="2" className="ms-3 w600 textPrime2">
                            {quizDetails?.[currentQuestion]?.option2}
                          </label>
                          <hr className="optionHr" />
                          <input
                            type="radio"
                            id="3"
                            name="fav_language"
                            value={quizDetails?.[currentQuestion]?.option3}
                            className="optionGroup"
                            onClick={() =>
                              setClickData(
                                quizDetails?.[currentQuestion]?.option3
                              )
                            }
                          />
                          <label for="3" className="ms-3 w600 textPrime2">
                            {quizDetails?.[currentQuestion]?.option3}
                          </label>
                          <hr className="optionHr" />
                          <input
                            type="radio"
                            id="4"
                            name="fav_language"
                            value={quizDetails?.[currentQuestion]?.option4}
                            className="optionGroup"
                            onClick={() =>
                              setClickData(
                                quizDetails?.[currentQuestion]?.option4
                              )
                            }
                          />
                          <label for="4" className="ms-3 w600 textPrime2">
                            {quizDetails?.[currentQuestion]?.option4}
                          </label>
                          <hr className="optionHr" />
                          <div className="text-center">
                            <button
                              className="borderNone textWhite bgPrime2 px-3 py-2"
                              onClick={nextQuestions}
                            >
                              Next
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Row>
                )}
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
}

import React from "react";
import "../../Common/common.css";
import "./jslogin.css";
import { Container, Row } from "react-bootstrap";
import { Link } from "react-router-dom";

export default function Jslogin() {
  return (
    <>
      <Container fluid>
        <Row>
          <div className="col-12 ps-5">
            <img
              src="/assets/images/city-job-text-icon.png"
              alt=""
              className="sidebarLogoWithText"
            />
          </div>
          <div className="col-md-6 text-center mt-5">
            <h2 className="w700 mb-5">
              Get <span className="textPrime2">Hired</span> Instantly !!!
            </h2>
            <img
              src="/assets/images/sidePhoto.png"
              className="img-fluid"
              alt=""
            />
          </div>
          <div className="col-md-6 ">
            <div className="logiFormContainer">
              <h4 className="w700 text-center pt-5">
                Verify Yourself and <span className="textPrime2">Login</span>
              </h4>
              <p className="text-center mt-4 w600 textPrime2">
                Continue with mobile number
              </p>
              <input
                type="text"
                placeholder="Enter mobile number"
                className="loginContainerInput"
              />
              <p className="text-center mt-4 w600 textPrime2">
                Or, Continue with Email ID
              </p>
              <input
                type="text"
                placeholder="Enter mobile number"
                className="loginContainerInput"
              />
              <div className="text-center">
                <Link to="/j_home">
                  <button className="bgPrime2 textWhite px-3 py-2 w600 borderNone btnLogin mt-5">
                    Login
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </Row>
      </Container>
    </>
  );
}

/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import "../../Common/common.css";
import "./jsmypayment.css";
import { Container, Row } from "react-bootstrap";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import Myaccountheaderjsd from "../../Components/MyAccountHeaderJSD/myaccountheaderjsd";
import { FaLessThan } from "react-icons/fa";
import { IoMdInformationCircle } from "react-icons/io";

export default function Jsmypayment() {
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="breadcrubsContainer bgWhite p-3">
                      <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                          <li class="breadcrumb-item">
                            <a href="#" className="linkNone textLightGray w600">
                              My Account
                            </a>
                          </li>
                          <li class="breadcrumb-item ">
                            <a href="#" className="linkNone textGray w600">
                              My Payment
                            </a>
                          </li>
                        </ol>
                      </nav>
                    </div>
                  </div>
                </Row>

                <Row>
                  <div className="col-12 mt-4">
                    <Myaccountheaderjsd />
                  </div>
                </Row>

                <Row>
                  <div className="col-md-6 mt-4">
                    <div className="singlePaymentSlip w-100 bgWhite p-3">
                      <h4 className="w600 mb-0">
                        Current Plan{" "}
                        <span className="font14 ">(3 Days Left)</span>
                      </h4>
                      <div className="d-flex justify-content-between mt-2">
                        <h4 className="textPrime2 w600">
                          VIP Plan{" "}
                          <span className="font14 textGray w600">
                            (3 Days Left)
                          </span>
                        </h4>
                        <div className="line"></div>
                        <h4 className="textPrime2 w600">4500/-</h4>
                      </div>
                      <div className="d-flex justify-content-between mt-2">
                        <h5 className="textLightGray w600 mb-0">
                          Activated On
                        </h5>
                        <h4 className="textGray w600 mb-0">16-7-22</h4>
                      </div>
                      <div className="d-flex justify-content-between mt-2">
                        <h5 className="textLightGray w600 mb-0">Expires On</h5>
                        <h4 className="textGray w600 mb-0">16-7-23</h4>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6 mt-4">
                    <div className="singlePaymentSlip w-100 bgWhite p-3">
                      <div className="d-flex justify-content-between mt-2">
                        <h4 className="textPrime2 w600">
                          VIP Plan{" "}
                          <span className="font14 textGray w600">
                            (3 Days Left)
                          </span>
                        </h4>
                        <h4 className="textPrime2 w600">4500/-</h4>
                      </div>
                      <div className="d-flex justify-content-between mt-2">
                        <h5 className="textLightGray w600 mb-0">
                          Activated On
                        </h5>
                        <h4 className="textGray w600 mb-0">16-7-22</h4>
                      </div>
                      <div className="d-flex justify-content-between mt-2">
                        <h5 className="textLightGray w600 mb-0">Expires On</h5>
                        <h4 className="textGray w600 mb-0">16-7-23</h4>
                      </div>
                    </div>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
}

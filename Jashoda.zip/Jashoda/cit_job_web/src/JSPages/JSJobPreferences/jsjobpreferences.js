import React from "react";
import "../../Common/common.css";
import "./jsjobpreferences.css";
import { Container, Row } from "react-bootstrap";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import Myaccountheaderjsd from "../../Components/MyAccountHeaderJSD/myaccountheaderjsd";
import Jobpreferencecardjsd from "../../Components/JobPreferenceCardJSD/jobpreferencecardjsd";

export default function Jsjobpreferences() {
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="breadcrubsContainer bgWhite p-3">
                      <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                          <li class="breadcrumb-item ">
                            <a href="#" className="linkNone textLightGray w600">
                              My Account
                            </a>
                          </li>
                          <li class="breadcrumb-item ">
                            <a href="#" className="linkNone textGray w600">
                              My Job Preferences
                            </a>
                          </li>
                        </ol>
                      </nav>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="col-12 mt-4">
                    <Myaccountheaderjsd />
                  </div>
                </Row>
                <Row>
                  <div className="col-md-6 mt-4">
                    <Jobpreferencecardjsd />
                  </div>
                  <div className="col-md-6 mt-4">
                    <Jobpreferencecardjsd />
                  </div>
                  <div className="col-md-6 mt-4">
                    <Jobpreferencecardjsd />
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
}

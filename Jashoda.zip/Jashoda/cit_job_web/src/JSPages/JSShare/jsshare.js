import React from "react"
import "../../Common/common.css"
import "./jsshare.css"
import { Container, Row } from "react-bootstrap" 
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd"   
import {BiCopy} from "react-icons/bi"

export default function Jsshare() {
  return (
    <>
    <Container fluid >
        <Row>  
          <div className="d-flex"> 
            <div>
               <Sidebarjs/> 
            </div> 
            <Container fluid className="mainPagesContainer">
              <Container>   
                <Row >
                   <div className="col-xl-8 col-lg-9 col-md-12 mt-4">
                        <div className="shareMainBox w100 bgWhite p-3">
                            <div className="qrbox p-3">
                                <p className="text-center textGray w600">Scan & Share</p>
                                <img src="/assets/images/qr.png" className="qrImage" alt="" />
                            </div>
                            <div className="mx-auto p-3 text-center">
                                <p className="text-center textGray w600">Share via app</p>
                                <div className="d-flex socialIconBox">
                                    <img src="/assets/images/fb.png" alt=""  className="mx-2" />
                                    <img src="/assets/images/ig.png" alt=""  className="mx-2" />
                                    <img src="/assets/images/wa.png" alt=""  className="mx-2" />
                                    <img src="/assets/images/li.png" alt=""  className="mx-2" />
                                    <img src="/assets/images/tw.png" alt=""  className="mx-2" />
                                </div>
                                <p className="text-center textGray w600 mt-4">Or copy link below</p>
                                <div className="d-flex linkShareBox text-center">
                                    <input type="text" value="bit.ly.366swds/refrsfrind/cfke/c.com" className="ms-3" />
                                    <button className="bgNone textPrime2 w600">Copy <BiCopy/></button>
                                </div>
                            </div>
                        </div>
                   </div>
                </Row>
              </Container>
            </Container>
          </div> 
        </Row>
      </Container>
    </>
  )
}

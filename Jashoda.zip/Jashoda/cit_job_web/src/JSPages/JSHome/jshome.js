import React from "react";
import "../../Common/common.css";
import "./jshome.css";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import { Container, Row } from "react-bootstrap";
import JobCardJSD from "../../Components/JobCardJSD/jobcardjsd";
import Slider from "react-slick";
import { Link } from "react-router-dom";

export default function JShome() {
  const settings = {
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1350,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1080,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div className="fixed">
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <Slider {...settings} className="slike1">
                      <img src="/assets/images/banner.png" alt="" />
                      <img src="/assets/images/banner.png" alt="" />
                      <img src="/assets/images/banner.png" alt="" />
                      <img src="/assets/images/banner.png" alt="" />
                      <img src="/assets/images/banner.png" alt="" />
                      <img src="/assets/images/banner.png" alt="" />
                    </Slider>
                  </div>
                </Row>
                <Row>
                  <p className="mb-0 w600 textGray font18">Trending Jobs</p>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                </Row>
                <Row>
                  <p className="mt-4 mb-0 w600 textGray font18">
                    Trending Categories
                  </p>
                  <button className="trendingCategory bgWhite">
                    <img src="/assets/images/banking.png" alt="" />
                    <a className="linkNone textGray ">Banking</a>
                  </button>
                  <button className="trendingCategory bgWhite">
                    <img src="/assets/images/trading.png" alt="" />
                    <a className="linkNone textGray ">Trading</a>
                  </button>
                  <button className="trendingCategory bgWhite">
                    <img src="/assets/images/healthcare.png" alt="" />
                    <a className="linkNone textGray">Health Care</a>
                  </button>
                  <button className="trendingCategory bgWhite">
                    <img src="/assets/images/finance.png" alt="" />
                    <a className="linkNone textGray">Finance</a>
                  </button>
                  <button className="trendingCategory bgWhite">
                    <img src="/assets/images/it.png" alt="" />
                    <a className="linkNone textGray">IT Sector</a>
                  </button>
                  <button className="trendingCategory bgWhite">
                    <img src="/assets/images/management.png" alt="" />
                    <a className="linkNone textGray">Management</a>
                  </button>
                </Row>
                <Row>
                  <p className="mb-0 w600 textGray font18 mt-4">
                    Recently Viewed
                  </p>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
}

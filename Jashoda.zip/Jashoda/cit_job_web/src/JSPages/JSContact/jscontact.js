import React from "react";
import "../../Common/common.css";
import "./jscontact.css";
import { Container, Row } from "react-bootstrap";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import Myaccountheaderjsd from "../../Components/MyAccountHeaderJSD/myaccountheaderjsd";

export default function Jscontact() {
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="breadcrubsContainer bgWhite p-3">
                      <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                          <li class="breadcrumb-item">
                            <a href="#" className="linkNone textLightGray w600">
                              My Account
                            </a>
                          </li>
                          <li class="breadcrumb-item">
                            <a href="#" className="linkNone textGray w600">
                              Contact Us
                            </a>
                          </li>
                        </ol>
                      </nav>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="col-12 mt-4">
                    <Myaccountheaderjsd />
                  </div>
                </Row>
                <Row>
                  <div className="col-md-4 mt-4">
                    <div className="singleContactInfoCard w-100 bgWhite p-4 d-flex">
                      <div className="">
                        <img src="/assets/images/call.png" alt="" />
                      </div>
                      <div className="ms-3">
                        <p className="mb-0 font18 w600 textGray">
                          Phone number
                        </p>
                        <p className="mb-0 font18 w600 textLightGray">
                          9876543210
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-4 mt-4">
                    <div className="singleContactInfoCard w-100 bgWhite p-4 d-flex">
                      <div className="">
                        <img src="/assets/images/location.png" alt="" />
                      </div>
                      <div className="ms-3">
                        <p className="mb-0 font18 w600 textGray">Location</p>
                        <p className="mb-0 font18 w600 textLightGray">
                          Rajkot, Gujrat
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-4 mt-4">
                    <div className="singleContactInfoCard w-100 bgWhite p-4 d-flex">
                      <div className="">
                        <img src="/assets/images/mail.png" alt="" />
                      </div>
                      <div className="ms-3">
                        <p className="mb-0 font18 w600 textGray">Email</p>
                        <p className="mb-0 font18 w600 textLightGray">
                          support@cityjob.com
                        </p>
                      </div>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="Col-12 ContactUsFormMainBox bgWhite w-100 mt-4 p-4">
                    <Row>
                      <div className="col-md-6">
                        <input type="text" placeholder="First Name"/>
                      </div>
                      <div className="col-md-6">
                        <input type="text" placeholder="Last Name"/>
                      </div>
                      <div className="col-md-6">
                        <input type="text" placeholder="Email"/>
                      </div>
                      <div className="col-md-6">
                        <input type="text" placeholder="Subject"/>
                      </div>
                      <div className="col-12">
                        <input type="text" placeholder="Decription"/>
                      </div>
                      <div className="text-center">
                        <button className="py-2 px-3 bgPrime2 textWhite borderNone mt-4">
                          Send
                        </button>
                      </div>
                    </Row>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
}

import React from "react";
import "../../Common/common.css";
import "./jsmyaccount.css";
import Sidebarjsd from "../../Components/SideBarJSD/sidebarjsd";
import { Container, Row } from "react-bootstrap";
import Myaccountheaderjsd from "../../Components/MyAccountHeaderJSD/myaccountheaderjsd";
import { Link } from "react-router-dom";

export default function Jsmyaccount() {
  return (
    <Container fluid>
      <Row>
        <div className="d-flex">
          <div>
            <Sidebarjsd />
          </div>
          <Container fluid className="mainPagesContainer">
            <Container>
              <Row>
                <div className="col-12">
                  <Myaccountheaderjsd />
                </div>
                <div className="col-md-6 mt-4">
                  <div className="myAccountMenuSectionMain bgWhite p-1">
                    <div className="singleMenuItemBox px-4 py-3">
                      <img
                        src="/assets/images/greetings.png"
                        className="me-4"
                        alt=""
                      />
                      <Link
                        to="/j_greetings"
                        className="mb-0 textLightGray w600 linkNone"
                      >
                        Greetings
                      </Link>
                    </div>
                    <div className="singleMenuItemBox px-4 py-3">
                      <img
                        src="/assets/images/contact.png"
                        className="me-4"
                        alt=""
                      />
                      <Link
                        to="/j_contact"
                        className="mb-0 textLightGray w600 linkNone"
                      >
                        <p className="mb-0 textLightGray w600">Contact Us</p>
                      </Link>
                    </div>
                    <div className="singleMenuItemBox px-4 py-3">
                      <img
                        src="/assets/images/job.png"
                        className="me-4"
                        alt=""
                      />
                      <Link
                        to="/j_jobpreference"
                        className="mb-0 textLightGray w600 linkNone"
                      >
                        <p className="mb-0 textLightGray w600">
                          Job Preferences
                        </p>
                      </Link>
                    </div>
                    <div className="singleMenuItemBox px-4 py-3">
                      <img
                        src="/assets/images/rewards.png"
                        className="me-4"
                        alt=""
                      />
                      <Link
                        to="/j_rewards"
                        className="mb-0 textLightGray w600 linkNone"
                      >
                        <p className="mb-0 textLightGray w600">My Rewards</p>
                      </Link>
                    </div>
                    <div className="singleMenuItemBox px-4 py-3">
                      <img
                        src="/assets/images/quiz.png"
                        className="me-4"
                        alt=""
                      />
                      <Link
                        to="/j_quizhome"
                        className="mb-0 textLightGray w600 linkNone"
                      >
                        <p className="mb-0 textLightGray w600">My Quiz</p>
                      </Link>
                    </div>
                    <div className="singleMenuItemBox px-4 py-3">
                      <img
                        src="/assets/images/payment.png"
                        className="me-4"
                        alt=""
                      />
                      <Link
                        to="/j_mypayment"
                        className="mb-0 textLightGray w600 linkNone"
                      >
                        <p className="mb-0 textLightGray w600">My Payments</p>
                      </Link>
                    </div>
                  </div>
                </div>
                <div className="col-md-6 mt-4">
                  <div className="myAccountMenuSectionMain bgWhite p-1">
                    <div className="singleMenuItemBox2 px-4 py-3">
                      <Link
                        to="/j_saved"
                        className="mb-0 textLightGray w600 linkNone"
                      >
                        My Chats
                      </Link>
                      <p className="mb-0 w600">4</p>
                    </div>
                    <div className="singleMenuItemBox2 px-4 py-3">
                      <Link
                        to="/j_saved"
                        className="mb-0 textLightGray w600 linkNone"
                      >
                        Total Viewed Jobs
                      </Link>
                      <p className="mb-0 w600">4</p>
                    </div>
                    <div className="singleMenuItemBox2 px-4 py-3">
                      <Link
                        to="/j_saved"
                        className="mb-0 textLightGray w600 linkNone"
                      >
                        My Saved Jobs
                      </Link>
                      <p className="mb-0 w600">4</p>
                    </div>
                    <div className="singleMenuItemBox2 px-4 py-3">
                      <Link
                        to="/j_saved"
                        className="mb-0 textLightGray w600 linkNone"
                      >
                        Resume Sent For
                      </Link>
                      <p className="mb-0 w600">4</p>
                    </div>
                  </div>
                </div>
              </Row>
            </Container>
          </Container>
        </div>
      </Row>
    </Container>
  );
}

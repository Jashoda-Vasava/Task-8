import React from "react";
import "../../Common/common.css";
import "./jsjoblist.css";
import { Container, Row } from "react-bootstrap";
import Dropdown from "react-bootstrap/Dropdown";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import JobCardJSD from "../../Components/JobCardJSD/jobcardjsd";
import { IoSearch } from "react-icons/io5";
import { Link } from "react-router-dom";

export default function Jsjoblist() {
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="d-flex justify-content-between">
                    <div className="d-flex">
                      <Dropdown>
                        <Dropdown.Toggle
                          className="dropdownBorder px-2 py-2"
                          id="dropdown-basic"
                        >
                          Web Developer
                        </Dropdown.Toggle>

                        <Dropdown.Menu>
                          <Dropdown.Item href="#/action-1">
                            Action
                          </Dropdown.Item>
                          <Dropdown.Item href="#/action-2">
                            Another action
                          </Dropdown.Item>
                          <Dropdown.Item href="#/action-3">
                            Something else
                          </Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                      <Dropdown>
                        <Dropdown.Toggle
                          className="dropdownBorder px-2 py-2"
                          id="dropdown-basic"
                        >
                          Sort By
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                          <Dropdown.Item href="#/action-1">
                            Action
                          </Dropdown.Item>
                          <Dropdown.Item href="#/action-2">
                            Another action
                          </Dropdown.Item>
                          <Dropdown.Item href="#/action-3">
                            Something else
                          </Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                    </div>
                    <div className="d-flex align-item-center">
                      <button className="bgPrime2 borderNone textWhite px-3 py-2 me-3 joblistBtn2">
                        Filter
                      </button>
                      <Link to="/j_search">
                        <button className="bgPrime2 borderNone textWhite px-3 py-2 joblistBtn2">
                          <IoSearch />
                        </button>
                      </Link>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                  <div className="col-md-6 mt-4">
                    <Link to="/j_jobdetails" className="linkNone">
                      <JobCardJSD />
                    </Link>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
}

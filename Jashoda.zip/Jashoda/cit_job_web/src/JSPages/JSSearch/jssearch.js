import React from "react"
import "../../Common/common.css"
import "./jssearch.css"
import { Container, Row } from "react-bootstrap" 
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd"   


export default function Jssearch() {
  return (
    <>
    <Container fluid >
        <Row>  
          <div className="d-flex"> 
            <div>
               <Sidebarjs/> 
            </div> 
            <Container fluid className="mainPagesContainer">
              <Container>
              <Row >
                  <div className="col-12">
                    <div className="breadcrubsContainer bgWhite p-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0">
                                <li class="breadcrumb-item"><a href="#" className="linkNone textLightGray w600">Jobs</a></li>
                                <li class="breadcrumb-item"><a href="#" className="linkNone textGray w600">Search</a></li> 
                            </ol>
                        </nav>
                    </div>
                  </div>
                </Row>  
                <Row >
                   <div className="col-12 mt-4">
                    <div className="searchMainBox w-100 bgWhite p-3">
                        <Row>
                            <div className="col-md-6">
                                <input type="text" placeholder="Enter job title, keywords or company name" />
                            </div>
                            <div className="col-md-6">
                                <input type="text" placeholder="Location" />
                            </div>
                            <div className="text-center">
                                <button className="bgPrime2 textWhite borderNone px-3 py-2 mt-4 searchBtn">Search</button>
                            </div>
                        </Row>
                    </div>
                   </div>
                </Row>
              </Container>
            </Container>
          </div> 
        </Row>
      </Container>
    </>
  )
}

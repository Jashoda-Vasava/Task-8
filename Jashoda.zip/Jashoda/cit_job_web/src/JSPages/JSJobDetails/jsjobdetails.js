import React from "react";
import "../../Common/common.css";
import "./jsjobdetails.css";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import { Container, Row } from "react-bootstrap";
import { AiTwotoneHeart } from "react-icons/ai";
import Sidebarjsd from "../../Components/SideBarJSD/sidebarjsd";

export default function Jsjobdetails() {
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="jobDetailsHeaderContainer bgWhite p-4 d-flex justify-content-between w-100">
                      <div>
                        <h4 className="mb-0 w600">Operation Executive</h4>
                        <p className="mb-0 w500 text-secondary">
                          Hoch Technology
                        </p>
                      </div>
                      <div className="font28 text-danger">
                        <AiTwotoneHeart />
                      </div>
                    </div>
                  </div>
                </Row>
                <Row>
                  <p className="mt-4 mb-0 w600">Description</p>
                  <p className="mt-1 text-secondary textJustify">
                    An automotive engineer by profession and a technology
                    enthusiast as a person, I have gained experience in
                    automotive feature innovation, research and development
                    especially in the field of ADAS and Active Safety Systems.An
                    automotive engineer by profession and a technology
                    enthusiast as a person, I have gained experience in
                    automotive feature innovation, research and development
                    especially in the field of ADAS and Active Safety Systems.An
                    automotive engineer by profession and a technology
                    enthusiast as a person, I have gained experience in
                    automotive feature innovation, research and development
                    especially in the field of ADAS and Active Safety Systems.
                  </p>
                </Row>
                <Row>
                  <div className="d-flex mt-4">
                    <div className="me-5">
                      <p className="mb-0 textGray w600">Experiences</p>
                      <p className="mb-0 textPrime2 w600">7 Years</p>
                    </div>
                    <div className="me-5">
                      <p className="mb-0 textGray w600">Education</p>
                      <p className="mb-0 textPrime2 w600">Graduate</p>
                    </div>
                    <div className="me-5">
                      <p className="mb-0 textGray w600">Location</p>
                      <p className="mb-0 textPrime2 w600">Pune</p>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="col-md-6">
                    <p className="mt-4 w600">Description</p>
                    <button className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2">
                      HTML
                    </button>
                    <button className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2">
                      CSS
                    </button>
                    <button className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2">
                      React JS
                    </button>
                    <button className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2">
                      Bootsrap
                    </button>
                    <button className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2">
                      JSX
                    </button>
                    <button className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2">
                      Flexbox
                    </button>
                    <button className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2">
                      Web Design
                    </button>
                    <button className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2">
                      Web Development
                    </button>
                  </div>
                  <div className="col-md-6">
                    <p className="mt-4 w600">About Company</p>
                    <p className="font18 textPrime2 w600 mb-0">
                      Hoch Technology
                      <span className="font14 textLightGray w500">
                        Inforamtion Technology
                      </span>
                    </p>
                    <p className="textLightGray w500">20-50 Employee</p>

                    <p className="textLightGray mb-1">
                      Location :
                      <span className="w500 textPrime2">Rajkot,Gujrat</span>
                    </p>
                    <p className="textLightGray mb-1">
                      Website :
                      <span className="w500 textPrime2">
                        www.hochtechnology.com
                      </span>
                    </p>
                    <p className="textLightGray mb-1">
                      E-mail :
                      <span className="w500 textPrime2">
                        contact@hochtechnology.com
                      </span>
                    </p>
                    <p className="textLightGray mb-1">
                      Posted By :
                      <span className="w500 textPrime2">
                        Steve Smith - HR Manager
                      </span>
                    </p>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
}
// Location : Rajkot,Gujrat
// Website :
//  :
//  :

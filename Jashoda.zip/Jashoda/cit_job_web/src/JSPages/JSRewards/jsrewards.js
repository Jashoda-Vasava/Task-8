import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./jsrewards.css";
import { Container, Row } from "react-bootstrap";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import Myaccountheaderjsd from "../../Components/MyAccountHeaderJSD/myaccountheaderjsd";
import { FaLessThan } from "react-icons/fa";
import { IoMdInformationCircle } from "react-icons/io";
import { Link } from "react-router-dom";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";

export default function Jsrewards() {
  const [rewardData, setRewardData] = useState([]);
  
  useEffect(() => {
    getRewardPointMaster();
  }, []);

  /******************** API CALL START HERE **************************/
  const getRewardPointMaster = () => {
    axiosInstance
      .post(`${Constants.GetRewardPointMaster}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setRewardData(response.data.data);
        } else {
          swal(`${response.data.message}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/

  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="breadcrubsContainer bgWhite p-3">
                      <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                          <li class="breadcrumb-item">
                            {/* eslint-disable-next-line jsx-a11y/anchor-is-valid */}
                            <a href="#" className="linkNone textLightGray w600">
                              My Account
                            </a>
                          </li>
                          <li class="breadcrumb-item">
                        {/* eslint-disable-next-line jsx-a11y/anchor-is-valid */}
                            <a href="#" className="linkNone textGray w600">
                              Rewards
                            </a>
                          </li>
                        </ol>
                      </nav>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="col-12 mt-4">
                    <Myaccountheaderjsd />
                  </div>
                </Row>
                <Row>
                  <div className="col-md-6">
                    <div className="col-12">
                      <div className="currentPointContainer mt-4 w-100 bgWhite p-3">
                        <p className="textLightGray mb-0 font18">
                          You have total{" "}
                          <span className="textPrime2 w600">900</span> points{" "}
                        </p>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="referFriendContainer mt-4 w-100 bgWhite p-3">
                        <p className="w600 text-dark mb-1">Refer a friend</p>
                        <p className="textLightGray">
                          By referring City-job to your friends you will get
                          bonus points if they install using your link .{" "}
                        </p>
                        <div className="d-flex inputContainer ">
                          <input
                            type="text"
                            value="bit.ly.366swds/refrsfrind/cfke/c.com"
                            className="borderNone"
                          />
                          <button className="borderNone bgWhite textPrime2 w600">
                            Copy
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="playQuizBox w-100 bgWhite mt-4 p-3">
                        <p className="mb-0 textGray w600 font18">
                          Play quiz to earn more points
                        </p>
                        <Link to="/j_quizhome">
                          <button className="borderNone textWhite bgPrime2 px-3 py-2">
                            Start
                          </button>
                        </Link>
                      </div>
                    </div>
                    <div className="col-12 p-3">
                      <p className="textLightGray w500 mt-2">
                        <IoMdInformationCircle className="textPrime2 mt-0" />{" "}
                        You can post one additional job preference once reach
                        1000 points
                      </p>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="row">
                    {rewardData?.map(item=>(
                      <div className="col-6 mt-4">
                        <div className="singleSocialBox w-100 bgWhite p-3">
                          <div className="text-center socialIcon">
                            <img
                              src={item?.imageicon}
                              alt=""
                              className="mt-2"
                            />
                            <p className="mt-3 w600 textGray font18">
                            {item?.name}
                            </p>
                          </div>
                          <div className="d-flex justify-content-between mt-3">
                            <p className="textPrime2 w600 mb-0">{item?.point} Points</p>
                            <button className="borderNone bgPrime2 fullRadious textWhite">
                          <Link to={item?.urlopen}> <FaLessThan className="inIcon"  /></Link>
                            </button>
                          </div>
                        </div>
                      </div>
                      ))}
                      {/* <div className="col-6 mt-4">
                                <div className="singleSocialBox w-100 bgWhite p-3 ">
                                    <div className="text-center socialIcon">
                                        <img src="/assets/images/ig.png" alt="" className="mt-2" />
                                        <p className="mt-3 w600 textGray font18">Follow us on Instagram</p>
                                    </div>
                                    <div className="d-flex justify-content-between mt-3">
                                        <p className="textPrime2 w600 mb-0">300 Points</p>
                                        <button className="borderNone bgPrime2 fullRadious textWhite"><FaLessThan className="inIcon"/></button>
                                    </div>
                                </div>
                            </div>
                            <div className="col-6 mt-4">
                                <div className="singleSocialBox w-100 bgWhite p-3 ">
                                    <div className="text-center socialIcon">
                                        <img src="/assets/images/ig.png" alt="" className="mt-2" />
                                        <p className="mt-3 w600 textGray font18">Follow us on Instagram</p>
                                    </div>
                                    <div className="d-flex justify-content-between mt-3">
                                        <p className="textPrime2 w600 mb-0">300 Points</p>
                                        <button className="borderNone bgPrime2 fullRadious textWhite"><FaLessThan className="inIcon"/></button>
                                    </div>
                                </div>
                            </div>
                            <div className="col-6 mt-4">
                                <div className="singleSocialBox w-100 bgWhite p-3 ">
                                    <div className="text-center socialIcon">
                                        <img src="/assets/images/ig.png" alt="" className="mt-2" />
                                        <p className="mt-3 w600 textGray font18">Follow us on Instagram</p>
                                    </div>
                                    <div className="d-flex justify-content-between mt-3">
                                        <p className="textPrime2 w600 mb-0">300 Points</p>
                                        <button className="borderNone bgPrime2 fullRadious textWhite"><FaLessThan className="inIcon"/></button>
                                    </div>
                                </div>
                            </div> */}
                    </div>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
}

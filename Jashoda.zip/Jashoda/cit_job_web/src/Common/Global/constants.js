/****************** API TOKEN *******************************/
export const TOKEN ="eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJndWVzdEBjaXR5LmNvbSIsImlhdCI6MTY4MTc5MTc2MywiZXhwIjoxNjgxODIwNTYzfQ.1XbnkFPka9rnpf8Yov0ddk-fMB5nA2E_pHT3lzh3KmCCtkN5N4qGpekhbLXpOkhdcAE5OfEx4e7f0RQQmJK0AA";
/****************** API TOKEN END HERE **********************/

/****************** API ERROR CODES *******************************/
export const CODE_ACCESS_TOKEN_UNAUTHORIZED = "401";
export const CODE_ACCESS_TOKEN_EXPIRED = "20";
export const CODE_SUCCESS = "200";
/****************** API ERROR CODES END HERE **********************/

export const WebSite = "api/v1/website/";
export const Master = "api/v1/master/";
export const Common = "api/v1/common/";
export const JobSeeker = "api/v1/jobseeker/";
export const Recruitment = "api/v1/recruitment/";

/******************** API URL START HERE **************************/

/********************HOME PAGE API START HERE **************************/
export const SaveHomePageHeader = WebSite + "get_website_homepageheader";
export const GetHomePageInfo = WebSite + "get_website_homepageinfo";
export const GetMediaCoverage = WebSite + "get_website_mediacoverage";
export const GetRecruitmentPartners = WebSite + "get_website_recruitmentpartners";
export const GetSocialicon = WebSite + "get_website_socialicon";
export const GetVideoDetail = WebSite + "get_website_videodetail";
/******************** HOME PAGE API END HERE **************************/

/******************** MASTER API START HERE **************************/
export const GetSkills = Master + "getskills";
export const SaveSkills = Master + "save_skills";

export const GetCompanySize = Master + "getCompanySize";
export const GetEducation = Master + "geteducation";
export const GetRequiredExperience = Master + "getRequiredExperience";
export const GetFunctionalArea = Master + "get_functional_area";

export const GetLocation = Master + "get_location";
export const SaveLocation = Master + "save_location";

export const GetExpactedIndustry = Master + "get_expacted_industry";
export const GetJobType = Master + "get_jobtype";
export const GetDynamicImage = Master + "get_dynamicimage";
export const GetCountyMaster = Master + "get_countrymaster";
export const GetStateMaster = Master + "get_statemaster";
export const GetCityMaster = Master + "get_citymaster";
/******************** MASTER API END HERE **************************/

/******************** CONFIGURATIONS API START HERE **************************/
export const GetCompanyGeneralDetail = Master + "get_company_general_detail";
export const GetFAQ = Master + "getfaq";
export const GetStaticPages = Master + "getstaticpages";
export const GetEmailTemplete = Common + "email/getemailtemplete";
/******************** CONFIGURATIONS API END HERE **************************/

/******************** JOBSEEKER API START HERE *************************/
export const GetQuizHeader = JobSeeker + "get_quizheader";
export const GetQuizDetail = JobSeeker + "get_quizdetail";
export const GetJobSeekerPlan = JobSeeker + "get_jobseekerplan";
export const GetRewardPointMaster = JobSeeker + "get_rewardpointmaster";
/******************** JOBSEEKER API END HERE *************************/

/******************** RECRUITMENT API START HERE *************************/
export const GetRecruitmentPlan=Recruitment+"get_recruitmentplan"
/******************** RECRUITMENT API END HERE *************************/

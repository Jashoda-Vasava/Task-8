import React from "react";
import "./buttons.css";
import "../../Common/common.css";
export default function Buttons(props) {
  return (
    <button className={`bg${props.bgColor} text${props.textColor} ${props.hover} buttonCommon borderNone w500`}>
      {props.content}
    </button>
  );
}

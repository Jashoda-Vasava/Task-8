/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from "react";
import "./navigationBar.css";
import "../../Common/common.css";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import { Link } from "react-router-dom";
import DownloadModal from "../DownloadModal/downloadModal";

export default function NavigationBar() {
  const [show, setShow] = useState(false);
  return (
    <>
      <Navbar className="jobNavbar bgWhite" expand="lg">
        <Container fluid>
          <Navbar.Brand href="#home">
            <Link className="linkNone" to="">
              <img src="/assets/images/Logo.png" height="35px" className="mx-3" alt=""/>
              <a className="font18 textGray linkNone w700">City Job</a>
            </Link>
          </Navbar.Brand>
          <Navbar.Toggle
            aria-controls="basic-navbar-nav"
            className="shadow-none"
          />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto"></Nav>
            <Nav className="ms-auto">
              <Nav.Link>
                <Link className="ms-3 w500 textGray textPrimeHover linkNone" to="">Home</Link>
              </Nav.Link>
              <Nav.Link>
                <Link className="ms-3 w500 textGray textPrimeHover linkNone" to="recruiter">Recruiters</Link>
              </Nav.Link>
              <Nav.Link>
                <Link className="ms-3 w500 textGray textPrimeHover linkNone" to="jobseeker">Job Seekers</Link>
              </Nav.Link>
              <Nav.Link>
                <Link className="ms-3 w500 textGray textPrimeHover linkNone" to="pricing">Pricing</Link>
              </Nav.Link>
              <Nav.Link onClick={() => {setShow(true)}} className="ms-3 w500 textGray textPrimeHover">Download App</Nav.Link>
              <Nav.Link className="ms-3 d-block d-lg-none w500 textGray textPrimeHover">
                <Link className="linkNone textGray" to="about">About us</Link>
              </Nav.Link>
              <Nav.Link className="ms-3 d-block d-lg-none w500 textGray textPrimeHover">Blog</Nav.Link>
            </Nav>
            <NavDropdown
              className="ms-3 d-none d-lg-block"
              title={
                <>
                  <button className="font26 borderNone bgNone mx-3 textGray textPrimeHover">
                    &#9776;
                  </button>
                </>
              }
              id="basic-nav-dropdown"
            >
              <NavDropdown.Item
                href="#action/3.1"
                className="bgWhite w500 textGray"
              >
                <Link to="about" className="linkNone textGray">About us</Link>
              </NavDropdown.Item>
              <NavDropdown.Item href="#action/3.1" className="bgWhite w500 textGray">Blog</NavDropdown.Item>
            </NavDropdown>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <DownloadModal show={show} setShow={setShow}/>
    </>
  );
}

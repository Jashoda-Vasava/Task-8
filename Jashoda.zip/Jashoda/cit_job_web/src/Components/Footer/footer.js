import React, { useEffect, useState } from "react";
import "./footer.css";
import "../../Common/common.css";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import { Link } from "react-router-dom";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";

export default function Footer() {
  const [companyDetails, setCompanyDetails] = useState([]);
  const [socialiconData, setSocialIconData] = useState([]);

  useEffect(() => {
    getCompanyGeneralDetail();
    getSocialicon();
  }, []);

  /******************** API CALL START HERE **************************/
  const getCompanyGeneralDetail = () => {
    axiosInstance
      .post(`${Constants.GetCompanyGeneralDetail}`, {
        isactive: "Y",
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setCompanyDetails(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getSocialicon = () => {
    axiosInstance
      .post(`${Constants.GetSocialicon}`, {
        isactive: "Y",
        pageable: {
          pageno: 0,
          pagesize: 10,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setSocialIconData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/

  return (
    <>
      <Container fluid className="bgGray footer p-5">
        {companyDetails?.map((item) => (
          <div>
            <Row>
              <div className="col-md-4 pe-5">
                <img src={item?.logo_image} height="50px" alt=""/>
                <a href className="linkNone font18 w600 textWhite">
                  {item?.name}
                </a>
                <p className="textOffWhite mt-3">{item?.description} </p>
                {socialiconData?.map((item) => (
                  <img
                    className="font26 textWhite me-3"
                    src={item?.imageurl}
                    alt=""
                  />
                ))}
              </div>
              <div className="col-md-3">
                <p className="textWhite w600 mt-2 mt-5 mt-md-0">Job Portal</p>
                <Link to="" className="linkNone">
                  <p className="textWhite w400 mt-2 font14 mb-0">Home</p>
                </Link>
                <Link to="about" className="linkNone">
                  <p className="textWhite w400 mt-2 font14 mb-0">About Us</p>
                </Link>
                <Link to="recruiter" className="linkNone">
                  <p className="textWhite w400 mt-2 font14 mb-0">Recruiters</p>
                </Link>
              </div>
              <div className="col-md-3">
                <p className="textWhite w600 mt-2 mt-5 mt-md-0">Support</p>
                <Link to="" className="linkNone">
                  <p className="textWhite w400 mt-2 font14 mb-0">
                    {item?.emailid}
                  </p>
                </Link>
                <Link to="contact" className="linkNone">
                  <p className="textWhite w400 mt-2 font14 mb-0">Contact Us</p>
                </Link>
              </div>
              <div className="col-md-2">
                <p className="textWhite w600 mt-2 mt-5 mt-md-0">Legal</p>
                <Link to="/privacy" className="linkNone">
                  <p className="textWhite w400 mt-2 font14 mb-0">
                    Privacy Policy
                  </p>
                </Link>
                <Link to="/terms" className="linkNone">
                  <p className="textWhite w400 mt-2 font14 mb-0">
                    Terms and Conditions
                  </p>
                </Link>
                <Link to="/refund" className="linkNone">
                  <p className="textWhite w400 mt-2 font14 mb-0">
                    Refund Policy
                  </p>
                </Link>
              </div>
            </Row>
            <Row>
              <p className="text-center textWhite mt-5 mb-0">
                {item?.copyright}
              </p>
            </Row>
          </div>
        ))}
      </Container>
    </>
  );
}

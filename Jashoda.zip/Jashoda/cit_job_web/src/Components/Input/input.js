import React from "react"
import "./input.css"
import "../../Common/common.css"

export default function Input(props) {
  return (
    <input type="text" className="offWhiteInput bgOffWhite borderNone outlineNone ps-3" placeholder={props.placeHolder}/>
  )
}

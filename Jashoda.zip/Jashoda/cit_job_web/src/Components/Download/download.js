import React from "react";
import { Container, Row } from "react-bootstrap";
import "../../Common/common.css";
import "./download.css";

export default function Download() {
  return (
    <>
      <Container fluid className="bgOffWhite downloadContainer">
        <Container>
          <Row className="pt-5">
            <div className="col-md-3 d-none d-lg-block">
              <img src="/assets/images/mockup.png" height="50%" alt=""/>
            </div>
            <div className="col-md-8">
              <h1 className="w700 textGray">
                Get the <span className="textPrime">App</span> Now
              </h1>
              <p className="w500 textLightGray mt-4">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been .
              </p>
              <div className="inputWrap mt-4">
                <input
                  type="text"
                  className="downloadInput borderNone outlineNone"
                  placeholder="Enter mobile no."
                />
                <button className="downloadSendBtn fullRadious borderNone bgPrime textWhite">
                  &#x27A4;
                </button>
              </div>
            </div>
          </Row>
        </Container>
      </Container>
    </>
  );
}

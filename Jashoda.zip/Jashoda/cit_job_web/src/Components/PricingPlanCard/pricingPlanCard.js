import React from "react"
import "./pricingPlanCard.css"

export default function PricingPlanCard() {
  return ( 
    <div className="planContainer">
        <div className="planName text-start bgPrime">
            <p className="mb-0 w700 ms-4 textGray">Premium</p>
            <h1 className="mb-0 w700 ms-4 textWhite">$23 <span className="font16">monthly</span></h1>
        </div>
        <div className="featuresContainer text-start mb-3">
            <p className="ms-4 textGray w600">&#11201; Feature 1</p>
            <p className="ms-4 textGray w600">&#11201; Feature 2</p>
            <p className="ms-4 textGray w600">&#11201; Feature 3</p>
            <p className="ms-4 textGray w600 isLocked">&#11201; Locked Feature 1</p>
            <p className="ms-4 textGray w600 isLocked">&#11201; Locked Feature 2</p>
        </div> 
    </div> 
  )
}

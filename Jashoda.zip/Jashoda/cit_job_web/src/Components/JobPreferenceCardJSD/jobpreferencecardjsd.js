import React from "react"
import "../../Common/common.css"
import "./jobpreferencecardjsd.css"

export default function Jobpreferencecardjsd() {
  return (
    <>
        <div className="singlePreferenceBox w-100 bgWhite p-3">
            <p className="textPrime2 w600 mb-0">Data Analyst <span className="ms-3 textLightGray">Rs 4-5 LPA</span></p>
            <p className="textLightGray w600">Information Technology | E-commerce | Banking</p>
            <p className="textLightGray w600">Rajkot, Gujrat</p>
        </div>
    </>
  )
}

import React from "react"
import "../../Common/common.css"
import "./jobcardjsd.css"
import {AiTwotoneHeart} from "react-icons/ai"

export default function JobCardJSD(props) {
  return (
    <>
    {/* <div className="jobcardMainContainer w-100 bgWhite p-3">
        <div className="d-flex justify-content-between">
            <div>
                <b className="font18 textGray">Opration Executive</b>
                <p className="text-secondary w500">Hoch Technology</p>
            </div>
            <div className="font20 text-danger"><AiTwotoneHeart/></div>
        </div>
        <div className="d-flex">
            <div className="jobCardMetadataBox"> 
                <p className="text12 textPrime2 w600 mb-0">Education</p>
                <p className="w600 textLightGray">Graduate</p>
            </div>
            <div className="jobCardMetadataBox"> 
                <p className="text12 textPrime2 w600 mb-0">Location</p>
                <p className="w600 textLightGray">Pune <span className="font14">Maharashtra</span></p>
            </div>
        </div>
        <div className="d-flex">
            <div className="jobCardMetadataBox"> 
                <p className="text12 textPrime2 w600 mb-0">Experience</p>
                <p className="w600 textLightGray">5 Years</p>
            </div>
            <div className="jobCardMetadataBox"> 
                <p className="text12 textPrime2 w600 mb-0">Posted by</p>
                <p className="w600 textLightGray">David Wood <span className="font14">HR Manager</span></p>
            </div>
        </div>
    </div> */}
    <div className="jobcardMainContainer w-100 bgWhite p-3">
        <div className="d-flex justify-content-between">
            <div>
                <b className="font18 textGray">Opration Executive</b>
                <p className="text-secondary w500">Hoch Technology</p>
            </div>
            <div className="font20 text-danger"><AiTwotoneHeart/></div>
        </div>
        <div className="row">
            <div className="col-sm-6"> 
                <p className="text12 textPrime2 w600 mb-0">Education</p>
                <p className="w600 textLightGray">Graduate</p>
            </div>
            <div className="col-sm-6"> 
                <p className="text12 textPrime2 w600 mb-0">Location</p>
                <p className="w600 textLightGray">Pune <span className="font14">Maharashtra</span></p>
            </div>
            <div className="col-sm-6"> 
                <p className="text12 textPrime2 w600 mb-0">Posted by</p>
                <p className="w600 textLightGray">David Wood <span className="font14">HR Manager</span></p> 
            </div>
            <div className="col-sm-6"> 
                <p className="text12 textPrime2 w600 mb-0">Experience</p>
                <p className="w600 textLightGray">5 Years</p> 
            </div>
        </div>
    </div>
    </>
  )
}

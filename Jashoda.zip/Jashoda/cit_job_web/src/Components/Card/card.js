import React from "react";
import "./card.css";
import "../../Common/common.css";

export default function Card(props) {
  return (
    <div>
      <div className="cardContainer">
        <div className="d-flex ms-3 pt-3">
          <img src={props.src} alt="" className="pnx-msg-icon" />
          <div className="font15 textGray ms-3 w600 mb-0">
            <p>{props.name}</p>
          </div>
        </div>
        <hr />
        <p
          className="w500 textLightGray textJustify"
          dangerouslySetInnerHTML={{ __html: props.description }}
        ></p>
      </div>
    </div>
  );
}

import React from "react"
import "../../Common/common.css"
import "./myaccountheaderjsd.css"
import Sidebarjsd from "../../Components/SideBarJSD/sidebarjsd"
import { Container, Row } from "react-bootstrap"

export default function Myaccountheaderjsd() {
  return (
    <>
    <div className="myAccountHeaderMainContainer bg-white px-4">
        <div className="d-flex">
            <img src="/assets/images/dp.png" className="accountHeaderImage" alt="" />
            <div className="ms-3">
                <h3 className="mb-0 w600 textPrime2">Martin Guptil</h3>
                <p className="textLightGray w500">Junior Software Engineer | 7 Years | Gradute</p>
            </div> 
        </div>
        <p className="textUnderline textPrime2 w600">My Plan</p>
    </div>
    </>
  )
}

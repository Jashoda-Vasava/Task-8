import React from "react";
import { Container, Row } from "react-bootstrap";
import "../../Common/common.css";
import "./videoText.css";
import Slider from "react-slick";

export default function VideoText(props) {
  const settings1 = {
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
  };
  return (
    <Container fluid>
      <Row>
        <div className="col-md-6">
          <Slider {...settings1} className="imgTextComponenetSlider">
            <div>
              <video src={props.video} controls loop className="w-100"></video>
            </div>
            <div>
              <video src={props.video} controls loop className="w-100"></video>
            </div>
            <div>
              <video src={props.video} controls loop className="w-100"></video>
            </div>
            <div>
              <video src={props.video} controls loop className="w-100"></video>
            </div>
            <div>
              <video src={props.video} controls loop className="w-100"></video>
            </div>
          </Slider>
        </div>
        <div className="col-md-6 sideTextContainer textJustify">
          <h3 className="textGray w700 videoTextHeading">{props.Heading}</h3>
          <p className="textLightGray w500 my-4">{props.Content}</p>
        </div>
      </Row>
    </Container>
  );
}

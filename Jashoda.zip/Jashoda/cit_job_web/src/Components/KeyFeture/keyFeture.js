import React from "react"
import "../../Common/common.css" 
import "./keyFeture.css"

export default function KeyFeture(props) {
  return (
    <div className="singleFeatureContainer text-center bgWhite">
            <img src={`/assets/images/${props.path}`} alt=""/>
            <p className="textPrime w500 mt-3">{props.content}</p>
    </div>
  )
}

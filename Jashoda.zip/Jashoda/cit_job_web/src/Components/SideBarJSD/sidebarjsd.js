import React, { useState } from "react"
import "../../Common/common.css"
import "./sidebarjsd.css"
import { Link } from "react-router-dom"

export default function Sidebarjsd() {
  const [collapsSidebar,setCollaps] = useState(true)

  const handleCollaps = () =>{
    if (collapsSidebar == true){
      setCollaps(false)
    }
    else{
      setCollaps(true)
    }
  }
 
  return (
    <>
    <div className="sideBarMainCotainer"> 
      <div className="sideBarContent" style={{width:(collapsSidebar == true  ? "250px" : "58px") }}>
        <img src="/assets/images/city-job-text-icon.png" className="sidebarLogoWithText mb-4" alt="" /> <br />
        <div className="singleLinkContainer cursorPointer activeLink d-flex">
          <img src="/assets/images/home-icon.svg" className="link-icon" alt=""/> <Link to="/j_home" className="linkNone textGray ms-4 font18 w600 link-text cursorPointer">Home</Link>
        </div>
        <div className="singleLinkContainer cursorPointer  d-flex">
          <img src="/assets/images/job-icon.svg" className="link-icon" alt=""/> <Link to="/j_joblist" className="linkNone textGray ms-4 font18 w600 link-text cursorPointer">Job</Link>
        </div>
        <div className="singleLinkContainer cursorPointer  d-flex">
          <img src="/assets/images/account-icon.svg" className="link-icon" alt="" /> <Link to="/j_myaccount" className="linkNone textGray ms-4 font18 w600 link-text cursorPointer">My Account</Link>
        </div>
        <div className="singleLinkContainer cursorPointer  d-flex">
          <img src="/assets/images/share-icon.svg" className="link-icon" alt="" /> <Link to="/j_share" className="linkNone textGray ms-4 font18 w600 link-text cursorPointer">Share</Link>
        </div>
        <div className="singleLinkContainer cursorPointer  d-flex">
          <img src="/assets/images/logout-icon.svg" className="link-icon" alt="" /> <Link to="/j_login" className="linkNone textGray ms-4 font18 w600 link-text cursorPointer">Logout</Link>
        </div> 
      </div>
      <button className="collapsButton borderNone bgWhite textPrime2" onClick={handleCollaps} >&#x2630;</button>
    </div>
    </>
    
  )
} 
import React from "react";
import { Container, Row } from "react-bootstrap";
import "../../Common/common.css";
import "./imageText.css";
import Slider from "react-slick";

export default function ImageText(props) {
  const settings1 = {
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
  };
  return (
    <Container fluid>
      <Row>
        <div className="col-md-6">
          <Slider {...settings1} className="imgTextComponenetSlider">
            <div>
              <img src="/assets/images/sidePhoto.png" className="w-100" alt=""></img>
            </div>
            <div>
            <img src="/assets/images/sidePhoto.png" className="w-100" alt=""></img>
            </div>
            <div>
            <img src="/assets/images/sidePhoto.png" className="w-100" alt=""></img>
            </div>
            <div>
            <img src="/assets/images/sidePhoto.png" className="w-100" alt=""></img>
            </div>
            <div>
            <img src="/assets/images/sidePhoto.png" className="w-100" alt=""></img>
            </div>
          </Slider>
        </div>
        <div className="col-md-6 sideTextContainer textJustify">
          <h3 className="textGray w700 imageTextHeading">{props.Heading}</h3>
          <p className="textLightGray w500 my-4">{props.Content}</p>
        </div>
      </Row>
    </Container>
  );
}

import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Landingpage from "./Pages/Landingpage/landingpage";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import JobSeeker from "./Pages/JobSeeker/jobSeeker";
import { Routes, Route } from "react-router-dom";
import Homepage from "./Pages/Homepage/homepage";
import Recruiter from "./Pages/Reruiter/recruiter";
import AllJobsCity from "./Pages/AllJobsCity/allJobsCity";
import CategoryDetails from "./Pages/CategoryDetails/categoryDetails";
import Legal from "./Pages/Legal/legal";
import TermsAndContion from "./Pages/Legal/termsAndContion";
import Contact from "./Pages/Contact/contact";
import CandidateInfo from "./Pages/CandidateInfo/candidateInfo";
import About from "./Pages/About/about";
import Listing from "./Pages/Listing/listing";
import Slider from "./Pages/Slider/slider";
import Pricing from "./Pages/Pricing/pricing";
import PrivacyPolicy from "./Pages/Legal/privacyPolicy";
import RefundPolicy from "./Pages/Legal/refundPolicy";
//jobseeker dashboard 
import Jshome from './JSPages/JSHome/jshome';
import Jsjobdetails from './JSPages/JSJobDetails/jsjobdetails';
import Jslogin from './JSPages/JSLogin/jslogin';
import Jsmyaccount from './JSPages/JSMyAccount/jsmyaccount';
import Jsjoblist from './JSPages/JSJobList/jsjoblist';
import Jsgreetings from './JSPages/JSGreetings/jsgreetings';
import Jscontact from './JSPages/JSContact/jscontact';
import Jsjobpreferences from './JSPages/JSJobPreferences/jsjobpreferences';
import Jssaved from './JSPages/JSSaved/jssaved';
import Jssearch from './JSPages/JSSearch/jssearch';
import Jsshare from './JSPages/JSShare/jsshare';
import Jsrewards from './JSPages/JSRewards/jsrewards';
import Jsquizhome from './JSPages/JSQuizHome/jsquizhome';
import Jsmypayment from './JSPages/JSMyPayment/jsmypayment';
import Jsquizmain from './JSPages/JSQuizMain/jsquizmain';
function App() {
  return (
    <>
      <Routes>
        <Route exact path="/" element={<Homepage />}>
          <Route exact path="" element={<Landingpage />} />
          <Route exact path="jobseeker" element={<JobSeeker />} />
          <Route exact path="recruiter" element={<Recruiter />} />
          <Route exact path="alljobs" element={<AllJobsCity />} />
          <Route exact path="categorydetails" element={<CategoryDetails />} />
          <Route exact path="legal" element={<Legal />} />
          <Route exact path="terms" element={<TermsAndContion />} />
          <Route exact path="privacy" element={<PrivacyPolicy />} />
          <Route exact path="refund" element={<RefundPolicy />} />
          <Route exact path="contact" element={<Contact />} />
          <Route exact path="info" element={<CandidateInfo />} />
          <Route exact path="about" element={<About />} />
          <Route exact path="listing" element={<Listing />} />
          <Route exact path="pricing" element={<Pricing />} />
          <Route exact path="slider" element={<Slider />} />
        </Route>
         {/* jjob seeker dashboard */}
         <Route exact path='/j_home' element={<Jshome />} />
        <Route exact path='/j_jobdetails' element={<Jsjobdetails />} />
        <Route exact path='/j_login' element={<Jslogin />} />
        <Route exact path='/j_myaccount' element={<Jsmyaccount />} />
        <Route exact path='/j_joblist' element={<Jsjoblist />} />
        <Route exact path='/j_greetings' element={<Jsgreetings />} />
        <Route exact path='/j_contact' element={<Jscontact />} />
        <Route exact path='/j_jobpreference' element={<Jsjobpreferences />} />
        <Route exact path='/j_saved' element={<Jssaved />} />
        <Route exact path='/j_search' element={<Jssearch />} />
        <Route exact path='/j_share' element={<Jsshare />} />
        <Route exact path='/j_rewards' element={<Jsrewards />} />
        <Route exact path='/j_quizhome' element={<Jsquizhome />} />
        <Route exact path='/j_mypayment' element={<Jsmypayment />} />
        <Route exact path='/j_quiz' element={<Jsquizmain />} />
      </Routes>
    </>
  );
}

export default App;

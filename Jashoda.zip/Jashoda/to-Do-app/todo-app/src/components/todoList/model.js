import React from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";

const Model = () => {
  const todos = useSelector((state) => state.todoReducer.todos);
   const { id } = useParams();
  // eslint-disable-next-line eqeqeq
  const data = todos.find((tod) => tod.id == id);
  
  return (
    <div className="container my-4 py-1  w-50">
      <div className="row">
        <div className="col-sm-12">
          <div className="card">
            <h4 className="card-title">View Details</h4>
            <div className="card-body">
              <p className="card-text">
                <h5> Title:{data.title}</h5>
                <h5> Description:{data.description}</h5>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Model;

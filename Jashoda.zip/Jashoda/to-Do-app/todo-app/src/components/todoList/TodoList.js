/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  addNewTodo,
  deleteTodo,
  editTodo,
  updateTodo,
} from "../../redux/action/action";
import { useNavigate } from "react-router-dom";

const TodoList = () => {
  const [value, setValue] = useState({});
  const [error, setError] = useState("");
  const dispatch = useDispatch();
  const isEdit = useSelector((state) => state.todoReducer.isEdit);
  const editTodos = useSelector((state) => state.todoReducer.editTodo);
  const todos = useSelector((state) => state.todoReducer.todos);
  const navigate = useNavigate();

  useEffect(() => {
    editTodos && setValue(() => editTodos);
  }, [editTodos]);

  const onSubmit = (e) => {
    e.preventDefault();

    if (!value?.title) {
      setError((error) => ({
        ...error,
        title: "Please enter todo title",
      }));
      return;
    }
    if (!value?.description) {
      setError((error) => ({
        ...error,
        description: "Please enter todo description",
      }));
      return;
    }
    if (isEdit) {
      dispatch(updateTodo(editTodos.id, value));
    } else {
      dispatch(addNewTodo(value));
    }
    setValue({ title: "", description: "" });
    document.getElementById("todoForm").reset();
  };

  const changeEvent = (e) => {
    setValue({
      ...value,
      [e.target.name]: e.target.value,
    });
    if (e?.target?.name === "title") {
      setError({
        title: "",
      });
    }
    if (e?.target?.name === "description") {
      setError({
        description: "",
      });
    }
  };
  const actionClick = (data) => {
    if (data && data?.type === "edit") {
      dispatch(editTodo(data?.todo?.id));
    } else if (data && data?.type === "delete") {
      dispatch(deleteTodo(data?.todo?.id));
    }
  };

  return (
    <div>
      <div className="container my-4 py-1 border w-50 card">
        <form className="mt-3 mb-2" id="todoForm" onSubmit={onSubmit}>
          <div className="row">
            <div className="col-xl-6">
              <label className="sr-only">Name</label>
              <input
                type="text"
                name="title"
                className="form-control mb-2 mr-sm-3"
                placeholder="Todo Title"
                defaultValue={value?.title}
                onChange={(e) => changeEvent(e)}
              />
              <span className="text-danger">{error?.title}</span>
            </div>

            <div className="col-xl-6">
              <label className="sr-only">Description</label>
              <input
                type="text"
                name="description"
                className="form-control mb-2 mr-sm-3"
                placeholder="Description"
                defaultValue={value?.description}
                onChange={(e) => changeEvent(e)}
              />
              <span className="text-danger">{error?.description}</span>
            </div>

            <div className="">
              <button className="btn btn-primary mb-2  " type="submit">
                {isEdit ? "Update Todo" : "Create Todo"}
              </button>
            </div>
          </div>
        </form>
      </div>
      <div className="container my-4 py-1  w-50 ">
        <div className="table-responsive">
          <table className="table table-sm">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Description</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {todos?.map((item, index) => (
                <tr key={index}>
                  <th scope="row">
                    <input
                      type={"checkbox"}
                      value={item?.id}
                      onChange={(e) => changeEvent(e, item?.id)}
                      name={`todo_${index}`}
                    />
                  </th>
                  <td>{item.title}</td>
                  <td>{item.description}</td>
                  <td>
                    <a
                      type="button"
                      className="btn btn-outline-none"
                      onClick={() => navigate(`model/${item.id}`)}
                    >
                      <span className="fa fa-eye"></span>
                    </a>
                    &nbsp;
                    <button
                      type="button"
                      className="btn btn-outline-none btn btn-primary btn-sm"
                      onClick={() => actionClick({ todo: item, type: "edit" })}
                    >
                      <span className="fa fa-pencil"></span>{" "}
                    </button>
                    &nbsp;
                    <button
                      type="button"
                      className="btn btn-outline-none btn btn-danger btn-sm ml-1 "
                      onClick={() =>
                        actionClick({ todo: item, type: "delete" })
                      }
                    >
                      <span className="fa fa-trash"></span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TodoList;

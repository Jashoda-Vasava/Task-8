import { ADD_USER, DELETE_USER, EDIT_USER, UPDATE_USER } from "./actionType";

export const addNewTodo = (todo) => {
  return {
    type: ADD_USER,
    payload: {
      id: Date.now(),
      title: todo?.title,
      description: todo?.description,
    },
  };
};

export const deleteTodo = (id) => {
  return {
    type: DELETE_USER,
    id,
  };
};

export const editTodo = (id) => {
  return {
    type: EDIT_USER,
    payload: {
      id: id,
    },
    isEdit: true,
  };
};

export const updateTodo = (id, todo) => {
  return {
    type: UPDATE_USER,
    payload: {
      todoId: id,
      todoTitle: todo?.title,
      todoDescription: todo?.description,
    },
  };
};

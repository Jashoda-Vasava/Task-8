import {
  ADD_USER,
  DELETE_USER,
  EDIT_USER,
  UPDATE_USER,
} from "../action/actionType";

const initialState = {
  todos: [
    {
      id: 1,
      title: "TodoList 1",
      description: "This is first todo",
    },
    {
      id: 2,
      title: "TodoList 2",
      description: "This is second todo",
    },
    {
      id: 3,
      title: "TodoList 3",
      description: "This is third todo",
    },
  ],
  isEdit: false,
  editTodoId: "",
};

const todoReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_USER:
      const { id, title, description } = action.payload;
      return {
        ...state,
        todos: [
          ...state.todos,
          {
            id: id,
            title: title,
            description: description,
          },
        ],
        isEdit: action.isEdit,
      };
    case DELETE_USER:
      const newTodoList = state.todos.filter((item) => item.id !== action.id);
      return {
        ...state,
        todos: newTodoList,
      };

    case EDIT_USER:
      const editTodo = action.payload;
      let newEditTodo = state?.todos?.find((item) => item?.id === editTodo?.id);
      return {
        ...state,
        isEdit: action.isEdit,
        editTodo: newEditTodo,
      };

    case UPDATE_USER:
      const { todoId, todoTitle, todoDescription } = action.payload;
      const todos = state.todos.filter((todo) => {
        return todo.id !== todoId;
      });

      const todo = state.todos.find((todo) => todo?.id === todoId);
      todo.title = todoTitle;
      todo.description = todoDescription;
      todos.push(todo);

      return {
        ...state,
        todos: [...todos],
        isEdit: false,
      };

    default:
      return state;
  }
};
export default todoReducer;

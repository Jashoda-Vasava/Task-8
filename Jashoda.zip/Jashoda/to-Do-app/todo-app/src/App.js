import "./App.css";
import Dashbord from "./components/dashboard/Dashbord";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import TodoList from "./components/todoList/TodoList";
import Model from "./components/todoList/model";

function App() {
  return (
    <div className="App">
      <Dashbord />
      <Router>
        <Routes>
          <Route path="/" element={<TodoList />} />
          <Route path="/model/:id" element={<Model />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;

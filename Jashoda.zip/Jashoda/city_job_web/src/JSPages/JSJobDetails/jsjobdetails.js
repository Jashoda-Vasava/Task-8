/* eslint-disable no-array-constructor */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./jsjobdetails.css";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import { Container, Row } from "react-bootstrap";
import { AiTwotoneHeart } from "react-icons/ai";
import swal from "sweetalert";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import { useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";

const Jsjobdetails = () => {
  const [recruitmentData, setRecruitmentData] = useState([]);
  var skillName = new Array();
  skillName = recruitmentData?.map((item) => {
    return item.skillname?.split(",");
  });
  const { id } = useParams();
  const Token = useSelector((state) => state?.token);
  const login = useSelector((state) => state?.login);
  const navigate = useNavigate();

  useEffect(() => {
    getRecruitmentData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /******************** API CALL START HERE **************************/
  const getRecruitmentData = () => {
    const body = {
      postjobid: id,
      loginuserid: login?.userid,
    };
    axiosInstance
      .post(`${Constants.GetRecruitmentData}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/j_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setRecruitmentData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  /******************** API CALL END HERE **************************/

  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              {recruitmentData.length > 0 &&
                recruitmentData?.map((item, key) => (
                  <Container key={key}>
                    <div key={key}>
                      <Row>
                        <div className="col-12">
                          <div className="jobDetailsHeaderContainer bgWhite p-4 d-flex justify-content-between w-100">
                            <div>
                              <h4 className="mb-0 w600">Operation Executive</h4>
                              <p className="mb-0 w500 text-secondary">
                                {item?.companyname}
                              </p>
                            </div>
                            <div>
                              <AiTwotoneHeart
                                className={
                                  item?.isfavourite === "Y"
                                    ? "font20 text-danger activeLink mx-3"
                                    : "font20 textLightGray mx-3"
                                }
                              />
                            </div>
                          </div>
                        </div>
                      </Row>
                      <Row>
                        <p className="mt-4 mb-0 w600">Description</p>
                        <p className="mt-1 text-secondary textJustify">
                          {item?.description}
                        </p>
                      </Row>
                      <hr className="opacity50" />
                      <div>
                        <Row>
                          <div className="d-flex mt-4">
                            <div className="me-5">
                              <p className="mb-0 textGray w600">Experiences</p>
                              <p className="mb-0 textPrime2 w600">
                                {item?.requiredexperience}
                              </p>
                            </div>
                            <div className="me-5">
                              <p className="mb-0 textGray w600">Education</p>
                              <p className="mb-0 textPrime2 w600">
                                {item?.education}
                              </p>
                            </div>
                            <div className="me-5">
                              <p className="mb-0 textGray w600">Location</p>
                              <p className="mb-0 textPrime2 w600">
                                {item?.companycity} , {item?.companystate}
                              </p>
                            </div>
                          </div>
                        </Row>
                        <hr className="opacity50" />
                        <Row>
                          <div className="col-md-6">
                            <p className="mt-4 w600">Skills</p>
                            {skillName?.map((item, key) =>
                              item?.map((item) => (
                                <button
                                  className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2"
                                  key={key}
                                >
                                  {item}
                                </button>
                              ))
                            )}
                          </div>
                          <div className="col-md-6">
                            <p className="mt-4 w600">About Company</p>
                            <p className="font18 textPrime2 w600 mb-0">
                              {item?.companyname}
                              <span className="font14 textLightGray w500">
                                &nbsp; Inforamtion Technology
                              </span>
                            </p>
                            <p className="textLightGray w500">
                              {item?.companysize}
                            </p>
                            <p className="textLightGray mb-1">
                              Location :
                              <span className="w500 textPrime2">
                                {item?.companycity},{item?.companystate}
                              </span>
                            </p>
                          </div>
                        </Row>
                      </div>
                    </div>
                  </Container>
                ))}
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Jsjobdetails;

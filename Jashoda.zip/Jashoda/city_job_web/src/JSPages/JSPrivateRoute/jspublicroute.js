import { Navigate } from "react-router-dom";
import AppStore from "../../redux/store/store";
export { JSPublicRoute };

function JSPublicRoute({ children }) {
  const Token = AppStore.store.getState().token;
  if (Token) {
    return <Navigate to="/j_home" />;
  }

  return children;
}

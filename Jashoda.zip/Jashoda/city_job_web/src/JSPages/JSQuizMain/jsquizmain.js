/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./jsquizmain.css";
import { Container, Row } from "react-bootstrap";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";
import Jsquizresult from "../JSQuizResult/jsquizresult";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";

const Jsquizmain = () => {
  const [quizDetails, setQuizDetails] = useState([]);
  const [clickData, setClickData] = useState("");
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const { id } = useParams();
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();

  useEffect(() => {
    geQuizDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /******************** API CALL START HERE **************************/
  const geQuizDetails = () => {
    const body = {
      isactive: "Y",
      quizid: id,
      pageable: {
        pageno: 0,
        pagesize: 10,
      },
    };
    axiosInstance
      .post(`${Constants.GetQuizDetail}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/j_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setQuizDetails(response.data.data);
        } else {
          swal(`${response.data.message}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/

  /******************** FUNCTION CALL START HERE **************************/
  const nextQuestions = () => {
    if (clickData === quizDetails?.[currentQuestion]?.correctoption) {
      setScore(score + 1);
    }
    if (currentQuestion < quizDetails?.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setClickData("");
    } else {
      setShowResults(true);
    }
    let allRadio = document.querySelectorAll(".optionGroup");
    allRadio.forEach((value) => (value.checked = false));
  };

  const resetData = () => {
    setShowResults(false);
    setCurrentQuestion(0);
    setClickData("");
    setScore(0);
  };
  /******************** FUNCTION CALL END HERE **************************/

  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            {showResults ? (
              <Jsquizresult
                score={score}
                resetData={resetData}
                quizDetails={quizDetails?.length}
                header={quizDetails?.[currentQuestion]?.name}
              />
            ) : (
              <>
                <Container fluid className="mainPagesContainer">
                  <Container>
                    <Row>
                      <div className="col-12">
                        <div className="breadcrubsContainer bgWhite p-3">
                          <nav aria-label="breadcrumb">
                            <ol className="breadcrumb mb-0">
                              <li className="breadcrumb-item">
                                <Link
                                  to="/j_myaccount"
                                  className="linkNone textLightGray w600"
                                >
                                  My Account
                                </Link>
                              </li>
                              <li className="breadcrumb-item">
                                <Link
                                  to="/j_myaccount/j_quizhome"
                                  className="linkNone textLightGray w600"
                                >
                                  My Quiz
                                </Link>
                              </li>
                              <li className="breadcrumb-item">
                                <a href="#" className="linkNone textGray w600">
                                  {quizDetails?.[currentQuestion]?.name}
                                </a>
                              </li>
                            </ol>
                          </nav>
                        </div>
                      </div>
                    </Row>
                    <Row>
                      <div className="col-md-6">
                        <div className="quizQestionContainer w-100 p-3 bgWhite mt-4">
                          <p className="text-end textLightGray w60">
                            {currentQuestion + 1} /{quizDetails?.length}
                          </p>
                          <div>
                            <h4 className="mb-4">
                              {currentQuestion + 1}.
                              {quizDetails?.[currentQuestion]?.questions}
                            </h4>
                            <input
                              type="radio"
                              id="1"
                              name="fav_language"
                              value={quizDetails?.[currentQuestion]?.option1}
                              className="optionGroup"
                              onClick={(e) =>
                                setClickData(
                                  quizDetails?.[currentQuestion]?.option1
                                )
                              }
                            />
                            <label for="1" className="ms-3 w600 textPrime2">
                              {quizDetails?.[currentQuestion]?.option1}
                            </label>
                            <hr className="optionHr" />
                            <input
                              type="radio"
                              id="2"
                              name="fav_language"
                              value={quizDetails?.[currentQuestion]?.option2}
                              className="optionGroup"
                              onClick={() =>
                                setClickData(
                                  quizDetails?.[currentQuestion]?.option2
                                )
                              }
                            />
                            <label for="2" className="ms-3 w600 textPrime2">
                              {quizDetails?.[currentQuestion]?.option2}
                            </label>
                            <hr className="optionHr" />
                            <input
                              type="radio"
                              id="3"
                              name="fav_language"
                              value={quizDetails?.[currentQuestion]?.option3}
                              className="optionGroup"
                              onClick={() =>
                                setClickData(
                                  quizDetails?.[currentQuestion]?.option3
                                )
                              }
                            />
                            <label for="3" className="ms-3 w600 textPrime2">
                              {quizDetails?.[currentQuestion]?.option3}
                            </label>
                            <hr className="optionHr" />
                            <input
                              type="radio"
                              id="4"
                              name="fav_language"
                              value={quizDetails?.[currentQuestion]?.option4}
                              className="optionGroup"
                              onClick={() =>
                                setClickData(
                                  quizDetails?.[currentQuestion]?.option4
                                )
                              }
                            />
                            <label for="4" className="ms-3 w600 textPrime2">
                              {quizDetails?.[currentQuestion]?.option4}
                            </label>
                            <hr className="optionHr" />
                            <div className="text-center">
                              <button
                                className={
                                  !clickData
                                    ? "borderNone textWhite bgLightGray px-3 py-2"
                                    : "borderNone textWhite bgPrime2 px-3 py-2"
                                }
                                disabled={!clickData}
                                onClick={nextQuestions}
                              >
                                Next
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Row>
                  </Container>
                </Container>
              </>
            )}
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Jsquizmain;

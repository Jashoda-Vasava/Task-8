import React, { useState } from "react";
import "../../Common/common.css";
import "./jslogin.css";
import { Container, Row } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { jsLogin, setToken } from "../../redux/action/action";
import swal from "sweetalert";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";

const Jslogin = () => {
  var [mobileno, setMobileNo] = useState("");
  var [emailid, setEmailid] = useState("");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [error, setError] = useState("");

  const handleChangeMobile = (e) => {
    setMobileNo(e.target.value);
  };
  const handleChangeEmailId = (e) => {
    setEmailid(e.target.value);
  };

  /** Validations Functions  **/
  const validate = () => {
    let error = [];
    if (!emailid && !mobileno) {
      error.mobileno = "Email Or Mobile  is required";
    }
    if (!emailid) error.emailid = "";
    if (!mobileno) error.mobileno = "";
    if (emailid.length <= 0 && mobileno.length <= 0) {
      error.mobileno = "Email Or Mobile  is required";
    }
    return setError(error);
  };

  /******************** API CALL START HERE **************************/
  const loginUser = (e) => {
    e.preventDefault();
    validate();
    if (emailid || mobileno) {
      axiosInstance
        .post(
          `${Constants.SaveJobSeekerSignIn}`,
          mobileno === "" ? { emailid: emailid } : { mobileno: mobileno },
          {
            headers: {
              "Content-type": "application/json",
            },
          }
        )
        .then((response) => {
          if (
            response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED
          ) {
            localStorage.clear();
            navigate("/j_login");
          } else if (response.data.status === Constants.CODE_SUCCESS) {
            dispatch(jsLogin(response.data.data));
            dispatch(setToken(response.data.data.accessToken));
            navigate("/js_otp");
          }
        })
        .catch((error) => {
          return swal(`${error.response.data.massage}`, "", "error");
        });
    }
  };
  /******************** API CALL END HERE **************************/
  return (
    <>
      <Container fluid>
        <Row>
          <div className="col-12 ps-5">
            <img
              src="/assets/images/city-job-text-icon.png"
              alt=""
              className="sidebarLogoWithText"
            />
          </div>
          <div className="col-md-6 text-center mt-5">
            <h2 className="w700 mb-5">
              Get <span className="textPrime2">Jobs</span> Instantly !!!
            </h2>
            <img
              src="/assets/images/sidePhoto.png"
              className="img-fluid"
              alt=""
            />
          </div>
          <div className="col-md-6">
            <div className="logiFormContainer">
              <h4 className="w700 text-center pt-5">
                Jobseeker <span className="textPrime2">Login</span>
              </h4>
              <p className="text-center mt-4 w600 textPrime2">
                Continue with mobile number
              </p>
              <input
                type="text"
                placeholder="Enter mobile number"
                className="loginContainerInput"
                onChange={handleChangeMobile}
                name="mobileno"
                value={mobileno}
              />
              <p className="text-center mt-4 w600 textPrime2">
                Or, Continue with Email ID
              </p>
              <input
                type="text"
                placeholder="Enter email id"
                className="loginContainerInput"
                onChange={handleChangeEmailId}
                value={emailid}
                name="emailid"
              />
           {(!emailid && !mobileno) && error.mobileno ? (
                <div className="errorJSLogin text-center">{error.mobileno}</div>
              ) : null}
              <div className="text-center">
                <Link>
                  <button
                    className="bgPrime2 textWhite px-3 py-2 w600 borderNone btnLogin mt-5"
                    onClick={loginUser}
                  >
                    Login
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Jslogin;

/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import { Container, Row } from "react-bootstrap";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import Myaccountheaderjsd from "../../Components/MyAccountHeaderJSD/myaccountheaderjsd";
import JobCardJSD from "../../Components/JobCardJSD/jobcardjsd";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const Jssaved = () => {
  const [jobSeekerData, setJobSeekerData] = useState([]);
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();

  useEffect(() => {
    getJobSeekerData();
  }, []);

  /******************** API CALL START HERE **************************/
  const getJobSeekerData = () => {
    const body = {
      loginuserid: 23041610034887,
      isfavourite: "Y",
    };
    axiosInstance
      .post(`${Constants.GetRecruitmentData}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/j_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setJobSeekerData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="breadcrubsContainer bgWhite p-3">
                      <nav aria-label="breadcrumb">
                        <ol className="breadcrumb mb-0">
                          <li class="breadcrumb-item">
                            <Link
                              to="/j_myaccount"
                              className="linkNone textLightGray w600"
                            >
                              My Account
                            </Link>
                          </li>
                          <li className="breadcrumb-item">
                            <a href="#" className="linkNone textGray w600">
                              Saved Jobs
                            </a>
                          </li>
                        </ol>
                      </nav>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="col-12 mt-4">
                    <Myaccountheaderjsd />
                  </div>
                </Row>
                <Row>
                  {jobSeekerData?.map((item, key) => (
                    <div className="col-md-6 mt-4" key={key}>
                      <JobCardJSD
                        education={item?.education}
                        city={item?.companycity}
                        state={item?.companystate}
                        companyName={item?.companyname}
                        isActive={
                          item?.isfavourite
                            ? "font20 text-danger mx-3"
                            : "font20 textLightGray mx-3"
                        }
                        firstName={item?.firstname}
                        lastName={item?.lastname}
                        experience={item?.requiredexperience}
                      />
                    </div>
                  ))}
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Jssaved;

/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./jshome.css";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import { Container, Pagination, Row } from "react-bootstrap";
import JobCardJSD from "../../Components/JobCardJSD/jobcardjsd";
import Slider from "react-slick";
import { Link, useNavigate } from "react-router-dom";
import swal from "sweetalert";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import { useSelector } from "react-redux";

const JShome = () => {
  const [advertisementData, setadevertisementData] = useState([]);
  const [jobSeekerData, setJobSeekerData] = useState([]);
  const [jobList, setJobList] = useState([]);
  const [page, setPage] = useState(1);
  const [pageCount, setPageCount] = useState(0);
  const login = useSelector((state) => state?.login);
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();

  useEffect(() => {
    getjobSeekerAdvertisement();
    getJobSeekerData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const pagedatacount = Math.ceil(jobSeekerData?.length / 6);
    setPageCount(pagedatacount);
    if (page) {
      const LIMIT = 6;
      const skip = LIMIT * page; // 5 *2 = 10
      const dataskip = jobSeekerData?.slice(
        page === 1 ? 0 : skip - LIMIT,
        skip
      );
      setJobList(dataskip);
    }
  }, [jobSeekerData, page]);

  /******************** API CALL START HERE **************************/
  const getjobSeekerAdvertisement = () => {
    const body = {
      isactive: "Y",
      pageable: {
        pageno: 0,
        pagesize: 10,
      },
    };
    axiosInstance
      .post(`${Constants.GetJobSeekerAdvertisement}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/j_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setadevertisementData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getJobSeekerData = () => {
    const body = {
      userid: login?.userid,
      isfavouritebyrecruiter: "Y",
    };
    axiosInstance
      .post(`${Constants.GetJobSeekerData}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/j_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setJobSeekerData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  /******************** API CALL END HERE **************************/

  /**  ADVERTISEMENT SLIDER **/
  const advertisementSlider = {
    infinite: advertisementData.length >= 3,
    arrows: advertisementData.length >= 3,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 1350,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1080,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  /*** PAGINATION CODE FROM BOOTSTRAP ***/
  // HANDLE NEXT PAGE
  const handleNext = () => {
    if (page === pageCount) return page;
    setPage(page + 1);
  };

  /**  HANDLE PREVIOUS **/
  const handlePrevious = () => {
    if (page === 1) return page;
    setPage(page - 1);
  };

  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div className="fixed">
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-md-12">
                    <Slider {...advertisementSlider} className="slike1">
                      {advertisementData?.map((item, key) => (
                        <video
                          src={item?.videourl}
                          controls
                          loop
                          className="videodata"
                          key={key}
                        />
                      ))}
                    </Slider>
                  </div>
                </Row>
                <Row>
                  <p className="mb-0 w600 textGray font18">Favourite Jobs</p>
                  {jobList?.length > 0 &&
                    jobList?.map((item, key) => (
                      <div className="col-md-6 mt-4" key={key}>
                        <Link to="" className="linkNone">
                          <JobCardJSD
                            education={item?.lastdegree}
                            city={item?.city}
                            state={item?.state}
                            // companyName={recruitmentData?.map(
                            //   (item) => item.companyname
                            // )}
                            Icons={
                              item?.isfavouritebyrecruiter
                                ? "font20 text-danger mx-3"
                                : "font20 textLightGray mx-3"
                            }
                            firstName={item?.firstname}
                            lastName={item?.lastname}
                            experience={item?.totalexperience}
                          />
                        </Link>
                      </div>
                    ))}
                </Row>
                <Row>
                  <div className="mt-4 ms-auto d-flex justify-content-end paginationBox">
                    <Pagination>
                      <Pagination.Prev
                        onClick={handlePrevious}
                        disabled={page === 1}
                      />
                      {Array(pageCount)
                        .fill(null)
                        .map((ele, index) => {
                          return (
                            <>
                              <Pagination.Item
                                active={page === index + 1 ? true : false}
                                onClick={() => setPage(index + 1)}
                              >
                                {index + 1}
                              </Pagination.Item>
                            </>
                          );
                        })}
                      <Pagination.Next
                        onClick={handleNext}
                        disabled={page === pageCount}
                      />
                    </Pagination>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default JShome;

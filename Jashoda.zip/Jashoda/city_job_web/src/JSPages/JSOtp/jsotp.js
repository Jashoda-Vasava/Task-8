import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import { Container, Row } from "react-bootstrap";
import "../JSLogin/jslogin.css";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";
import "./jsotp.css";
import { jsLogin, setToken } from "../../redux/action/action";
import OtpInput from "react-otp-input";
const JsOtp = () => {
  const [otp, setOtp] = useState("");
  const [minutes, setMinutes] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const login = useSelector((state) => state?.login);
  const Token = useSelector((state) => state?.token);

  useEffect(() => {
    const interval = setInterval(() => {
      if (seconds > 0) {
        setSeconds(seconds - 1);
      }
      if (seconds === 0) {
        if (minutes === 0) {
          clearInterval(interval);
        } else {
          setSeconds(59);
          setMinutes(minutes - 1);
        }
      }
    }, 1000);
    return () => {
      clearInterval(interval);
    };
  }, [login, minutes, seconds]);

  const handleChange = (value) => {
    setOtp(value);
  };
  /******************** API CALL START HERE **************************/
  const handleOtpVerify = () => {
    const body = {
      mobileno: login?.mobileno,
      otp: otp,
      userid: login?.userid,
    };
    axiosInstance
      .post(`${Constants.SaveJobSeekerValidotp}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/j_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setOtp(response.data.data?.otp);
          dispatch(setToken(response?.data?.data?.jwttoken));
          setMinutes(1);
          setSeconds(59);
          navigate("/j_home");
          return response.data.data;
        } else {
          swal(`${response.data.massage}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.massage}`, "", "error"));
  };

  const resendOTP = () => {
    if (login?.mobileno) {
      const body = {
        mobileno: login?.mobileno,
      };
      axiosInstance
        .post(`${Constants.SaveJobSeekerSignIn}`, body, {
          headers: {
            "Content-type": "application/json",
            Authorization: `Bearer ${Token}`,
          },
        })
        .then((response) => {
          if (
            response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED
          ) {
            localStorage.clear();
            navigate("/j_login");
          } else if (response.data.status === Constants.CODE_SUCCESS) {
            dispatch(jsLogin(response.data.data));
            dispatch(setToken(response.data.data.jwttoken));
            localStorage.setItem("token", response.data.data?.jwttoken);
          }
        })
        .catch((error) => {
          return swal(`${error.response.data.massage}`, "", "error");
        });
      setMinutes(1);
      setSeconds(59);
    }
    if (login?.emailid) {
      const body = {
        emailid: login?.emailid,
      };
      axiosInstance
        .post(`${Constants.SaveJobSeekerSignIn}`, body, {
          headers: {
            "Content-type": "application/json",
            Authorization: `Bearer ${Token}`,
          },
        })
        .then((response) => {
          if (
            response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED
          ) {
            localStorage.clear();
            navigate("/j_login");
          } else if (response.data.status === Constants.CODE_SUCCESS) {
            dispatch(jsLogin(response.data.data));
            dispatch(setToken(response.data.data.jwttoken));
            localStorage.setItem(
              "token",
              JSON.parse(response.data.data?.jwttoken)
            );
          }
        })
        .catch((error) => {
          return swal(`${error.response.data.massage}`, "", "error");
        });
      setMinutes(1);
      setSeconds(59);
    } else {
    }
  };
  /******************** API CALL END HERE **************************/

  return (
    <>
      <Container fluid>
        <Row>
          <div className="col-12 ps-5">
            <img
              src="/assets/images/city-job-text-icon.png"
              alt=""
              className="sidebarLogoWithText"
            />
          </div>
          <div className="col-md-6 text-center mt-5">
            <h2 className="w700 mb-5">
              Get <span className="textPrime2">Hired</span> Instantly !!!
            </h2>
            <img
              src="/assets/images/sidePhoto.png"
              className="img-fluid"
              alt=""
            />
          </div>
          <div className="col-md-6">
            <div className="logiFormContainer">
              <h4 className="w700 text-center pt-5 textPrime2">
                OTP Verification
              </h4>
              <p className="text-center mt-4 w600 textGray">
                Enter the code we just send on your{" "}
                {login?.mobileno || login?.emailid}
              </p>
              <div className="inputs d-flex flex-row justify-content-center mt-5">
                <OtpInput
                  value={otp}
                  onChange={handleChange}
                  numInputs={4}
                  inputStyle={
                    otp
                      ? "inputStyle bgPrime2 textWhite form-control rounded"
                      : "inputStyle form-control rounded"
                  }
                  renderSeparator={<span> &nbsp; &nbsp;</span>}
                  renderInput={(props) => <input {...props} />}
                ></OtpInput>
              </div>
              <div className="text-center">
                <Link>
                  <button
                    className={
                      otp.length < 4
                        ? "textWhite px-3 py-2 w600 borderNone btnLogin mt-5 bgPrimeLight"
                        : "bgPrime2 textWhite px-3 py-2 w600 borderNone btnLogin mt-5"
                    }
                    onClick={handleOtpVerify}
                    disabled={!otp}
                  >
                    Next
                  </button>
                </Link>
              </div>
              <div className="">
                {seconds > 0 || minutes > 0 ? (
                  <p className="text-center mt-4 w600 textPrime2">
                    Time Remaining: {minutes < 10 ? `0${minutes}` : minutes}:
                    {seconds < 10 ? `0${seconds}` : seconds}
                  </p>
                ) : (
                  <p
                    type="button"
                    disabled={seconds > 0 || minutes > 0}
                    style={{
                      color:
                        seconds > 0 || minutes > 0
                          ? "GrayText"
                          : "text-center mr-5 mt-4 w600 textPrime2",
                    }}
                    className="text-center mt-4 w600 textPrime2"
                    onClick={resendOTP}
                  >
                    Resend OTP ?
                  </p>
                )}
              </div>
            </div>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default JsOtp;

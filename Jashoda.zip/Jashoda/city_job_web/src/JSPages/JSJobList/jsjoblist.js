/* eslint-disable no-sequences */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./jsjoblist.css";
import { Container, Row } from "react-bootstrap";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import JobCardJSD from "../../Components/JobCardJSD/jobcardjsd";
import { FaFilter } from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import swal from "sweetalert";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import Pagination from "react-bootstrap/Pagination";
import { useSelector } from "react-redux";

const Jsjoblist = () => {
  const [recruitmentData, setRecruitmentData] = useState([]);
  const [functionalareaname, setFunctionalAreaName] = useState("");
  const [companycity, setCompanycity] = useState("");
  const [jobtypename, setJobtypename] = useState("");
  const [expactedindustryname, setExpactedIndustryName] = useState("");
  const [requiredexperience, setRequiredexperience] = useState("");
  const [jobList, setJobList] = useState([]);
  const [page, setPage] = useState(1);
  const [pageCount, setPageCount] = useState(0);
  const login = useSelector((state) => state?.login);
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();

  useEffect(() => {
    getRecruitmentData();
    filteredData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    functionalareaname,
    companycity,
    expactedindustryname,
    jobtypename,
    requiredexperience,
  ]);

  useEffect(() => {
    const pagedatacount = Math.ceil(recruitmentData?.length / 6);
    setPageCount(pagedatacount);
    if (page) {
      const LIMIT = 6;
      const skip = LIMIT * page; // 5 *2 = 10
      const dataskip = recruitmentData?.slice(
        page === 1 ? 0 : skip - LIMIT,
        skip
      );
      setJobList(dataskip);
    }
  }, [recruitmentData, page]);

  /******************** API CALL START HERE **************************/

  const getRecruitmentData = () => {
    const body = {
      loginuserid: login?.userid,
      isapply: "Y",
      filtertext: `functionalareaname like '%${functionalareaname}%' OR coursename like '%AWS%' OR upper(jobtypename) in ('PART TIME','FULL TIME') OR companycity like '%${companycity}%' OR expactedindustryname like '%${expactedindustryname}%' OR requiredexperience like '%${requiredexperience}%'`,
    };
    axiosInstance
      .post(`${Constants.GetRecruitmentData}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/j_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setRecruitmentData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const saveJobSeekerFavouritePostJob = async (postjobid, isfavourite) => {
    const body = {
      isfavourite: isfavourite === "Y" ? "N" : "Y",
      jobseekeruserid: login?.userid,
      postjobid: postjobid,
    };
    return axiosInstance
      .post(`${Constants.SaveJobSeekerFavouritePostJob}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/j_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          getRecruitmentData();
          return response.data.data;
        } else {
        }
      });
  };
  /******************** API CALL END HERE **************************/

  /*** PAGINATION CODE FROM BOOTSTRAP ***/
  // HANDLE NEXT PAGE
  const handleNext = () => {
    if (page === pageCount) return page;
    setPage(page + 1);
  };

  /**  HANDLE PREVIOUS **/
  const handlePrevious = () => {
    if (page === 1) return page;
    setPage(page - 1);
  };

  /**  FILTER DATA **/
  const filteredData = () => {
    // Include all elements which includes the search query
    const data = recruitmentData?.filter(
      (filter) =>
        filter?.functionalareaname
          ?.toLowerCase()
          ?.includes(functionalareaname?.toLowerCase()) ||
        filter?.companycity
          ?.toLowerCase()
          ?.includes(companycity?.toLowerCase()) ||
        filter?.jobtypename
          ?.toLowerCase()
          ?.includes(jobtypename?.toLowerCase()) ||
        filter?.expactedindustryname
          ?.toLowerCase()
          ?.includes(expactedindustryname?.toLowerCase()) ||
        filter?.requiredexperience
          ?.toLowerCase()
          ?.includes(requiredexperience?.toLowerCase())
    );
    setRecruitmentData(data);
    return data;
  };

  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="singleFilterItemBox bgWhite ms-3 pb-2">
                    <a className="linkNone w600 textPrime2 font14 py-2">
                      Functional Area
                    </a>
                    <input
                      type="text"
                      name="functionalareaname"
                      placeholder="eg. Java Developer"
                      value={functionalareaname}
                      onChange={(e) => setFunctionalAreaName(e.target.value)}
                      className="filterInput"
                    />
                  </div>
                  <div className="singleFilterItemBox bgWhite ms-3 pb-2">
                    <a className="linkNone w600 textPrime2 font14 py-2">
                      Location
                    </a>
                    <input
                      type="text"
                      name="companycity"
                      value={companycity}
                      onChange={(e) => setCompanycity(e.target.value)}
                      placeholder="eg. Pune"
                      className="filterInput"
                    />
                  </div>
                  <div className="singleFilterItemBox bgWhite ms-3 pb-2">
                    <a className="linkNone w600 textPrime2 font14 py-2">
                      Job Type
                    </a>
                    <select
                      className="w-100 p-2 filterOutline outlineNone"
                      name="jobtypename"
                      onChange={(e) => setJobtypename(e.target.value)}
                      value={jobtypename}
                    >
                      <option selected="true" disabled="disabled" value={""}>
                        Select
                      </option>
                      <option value={"Full Time"}>Full Time</option>
                      <option value={"Part Time"}>Part Time</option>
                      <option value={"Contract"}>Contract</option>
                    </select>
                  </div>
                  <div className="singleFilterItemBox bgWhite ms-3 pb-2">
                    <a className="linkNone w600 textPrime2 font14 py-2">
                      Industry
                    </a>
                    <select
                      className="w-100 p-2 filterOutline outlineNone"
                      name="expactedindustryname"
                      onChange={(e) => setExpactedIndustryName(e.target.value)}
                      value={expactedindustryname}
                    >
                      <option selected="true" disabled="disabled" value={""}>
                        Select
                      </option>
                      <option value="Information Technology">
                        Information Technology
                      </option>
                      <option value="Marketing">Marketing</option>
                      <option value="Finance">Finance</option>
                    </select>
                  </div>
                  <div className="singleFilterItemBox bgWhite ms-3 pb-2">
                    <a className="linkNone w600 textPrime2 font14 mpy2">
                      Required Experience
                    </a>
                    <select
                      className="w-100 p-2 filterOutline outlineNone"
                      name="requiredexperience"
                      onChange={(e) => setRequiredexperience(e.target.value)}
                      value={requiredexperience}
                    >
                      <option selected="true" disabled="disabled" value={""}>
                        Select
                      </option>
                      <option value="1 Year">Less than 1 Year</option>
                      <option value="2 Year">1-3 Year</option>
                      <option value="3 Year">3-5 Year</option>
                      <option value="5 Year">5-10 Year</option>
                      <option value="10 Year">10 Year +</option>
                    </select>
                  </div>
                  <div className="singleFilterItemBox2">
                    <button
                      className="mt-3 borderNone bgPrime2 textWhite p-2 px-3 filterButton"
                      onClick={(e) => filteredData(e)}
                    >
                      <FaFilter />
                    </button>
                  </div>
                </Row>
                <hr className="opacity50" />
                <Row>
                  {jobList?.length > 0 &&
                    jobList?.map((item, key) => (
                      <div className="col-md-6 mt-4" key={key}>
                        <Link
                          to={`/j_joblist/j_jobdetails/${item?.postjobid}`}
                          className="linkNone"
                        >
                          <JobCardJSD
                            key={key}
                            education={item?.education}
                            city={item?.companycity}
                            state={item?.companystate}
                            companyName={item?.companyname}
                            Icons={
                              item?.isfavourite === "Y"
                                ? "font20 text-danger activeLink mx-3"
                                : "font20 textLightGray mx-3"
                            }
                            hendleChangeLike={(e) => {
                              saveJobSeekerFavouritePostJob(
                                item?.postjobid,
                                item?.isfavourite,
                                e.target
                              );
                            }}
                            firstName={item?.firstname}
                            lastName={item?.lastname}
                            experience={item?.requiredexperience}
                          />
                        </Link>
                      </div>
                    ))}
                </Row>
                <Row>
                  <div className="mt-4 ms-auto d-flex justify-content-end paginationBox">
                    <Pagination>
                      <Pagination.Prev
                        onClick={handlePrevious}
                        disabled={page === 1}
                      />
                      {Array(pageCount)
                        .fill(null)
                        .map((ele, index) => {
                          return (
                            <>
                              <Pagination.Item
                                active={page === index + 1 ? true : false}
                                onClick={() => setPage(index + 1)}
                              >
                                {index + 1}
                              </Pagination.Item>
                            </>
                          );
                        })}
                      <Pagination.Next
                        onClick={handleNext}
                        disabled={page === pageCount}
                      />
                    </Pagination>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Jsjoblist;

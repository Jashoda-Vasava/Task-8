/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import "../../Common/common.css";
import "../JSQuizMain/jsquizmain.css";
import { Container, Row } from "react-bootstrap";
import { Link } from "react-router-dom";

const Jsquizresult = ({ score, resetData, quizDetails, header }) => {
  const result = ((score / quizDetails) * 100).toFixed(2);
  localStorage.setItem("score", result);
  
  return (
    <>
      <Container fluid className="mainPagesContainer">
        <Container>
          <Row>
            <div className="col-12">
              <div className="breadcrubsContainer bgWhite p-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item">
                      <Link
                        to="/j_myaccount"
                        className="linkNone textLightGray w600"
                      >
                        My Account
                      </Link>
                    </li>
                    <li class="breadcrumb-item">
                      <Link
                        to="/j_myaccount/j_quizhome"
                        className="linkNone textLightGray w600"
                      >
                        My Quiz
                      </Link>
                    </li>
                    <li class="breadcrumb-item">
                      <a href="#" className="linkNone textGray w600">
                        {header}
                      </a>
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
          </Row>
          <Row className="text-center pt-5">
            <p className="mt-5 font24 w700 textGray">
              Congratulations !!! you have scored
            </p>
            <h1 className="fontXL textPrime2 mb-0">
              {score} / {quizDetails} correct - ({result} %)
            </h1>
            <p className="font20 w700 textGray">
              & You have earned
              <span className="textPrime2">&nbsp;{result} % Reward Points</span>
            </p>
            <div className="text-center">
              <button
                className="borderNone bgPrime2 textWhite px-3 py-2 r20"
                onClick={resetData}
              >
                Try Again
              </button>
            </div>
          </Row>
        </Container>
      </Container>
    </>
  );
};
export default Jsquizresult;

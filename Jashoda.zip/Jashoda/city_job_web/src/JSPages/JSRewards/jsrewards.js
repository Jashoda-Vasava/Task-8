/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./jsrewards.css";
import { Container, Row } from "react-bootstrap";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import Myaccountheaderjsd from "../../Components/MyAccountHeaderJSD/myaccountheaderjsd";
import { FaLessThan } from "react-icons/fa";
import { IoMdInformationCircle } from "react-icons/io";
import { Link, useNavigate } from "react-router-dom";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";
import CopyToClipboard from "react-copy-to-clipboard";
import { useSelector } from "react-redux";

const Jsrewards = () => {
  const [rewardData, setRewardData] = useState([]);
  const [text, setText] = useState("bit.ly.366swds/refrsfrind/cfke/c.com");
  const [isCopied, setIsCopied] = useState(false);
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();

  useEffect(() => {
    getRewardPointMaster();
  }, []);

  /******************** API CALL START HERE **************************/
  const getRewardPointMaster = () => {
    const body = {
      isactive: "Y",
      pageable: {
        pageno: 0,
        pagesize: 10,
      },
    };
    axiosInstance
      .post(`${Constants.GetRewardPointMaster}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/j_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setRewardData(response.data.data);
        } else {
          swal(`${response.data.message}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/

  /** COPYLINK FUNCTION **/
  const onCopyText = () => {
    setIsCopied(true);
    setTimeout(() => {
      setIsCopied(false);
    }, 1000);
  };
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="breadcrubsContainer bgWhite p-3">
                      <nav aria-label="breadcrumb">
                        <ol className="breadcrumb mb-0">
                          <li className="breadcrumb-item">
                            <Link
                              to="/j_myaccount"
                              className="linkNone textLightGray w600"
                            >
                              My Account
                            </Link>
                          </li>
                          <li className="breadcrumb-item">
                            <a href="#" className="linkNone textGray w600">
                              Rewards
                            </a>
                          </li>
                        </ol>
                      </nav>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="col-12 mt-4">
                    <Myaccountheaderjsd />
                  </div>
                </Row>
                <Row>
                  <div className="col-md-6">
                    <div className="col-12">
                      <div className="currentPointContainer mt-4 w-100 bgWhite p-3">
                        <p className="textLightGray mb-0 font18">
                          You have total
                          <span className="textPrime2 w600">
                            {" "}
                            {localStorage.getItem("score")
                              ? localStorage.getItem("score")
                              : 0}{" "}
                            {/* % */}
                          </span>{" "}
                          points
                        </p>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="referFriendContainer mt-4 w-100 bgWhite p-3">
                        <p className="w600 text-dark mb-1">Refer a friend</p>
                        <p className="textLightGray">
                          By referring City-job to your friends you will get
                          bonus points if they install using your link .
                        </p>
                        <div className="d-flex inputContainer">
                          <input
                            type="text"
                            value={text}
                            onChange={(event) => setText(event.target.value)}
                            className="borderNone"
                          />
                          <CopyToClipboard text={text} onCopy={onCopyText}>
                            <button className="borderNone bgWhite textPrime2 w600">
                              Copy
                            </button>
                          </CopyToClipboard>
                          <span
                            className={`copy-feedback ${
                              isCopied ? "active" : ""
                            }`}
                          >
                            Copied!
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="playQuizBox w-100 bgWhite mt-4 p-3">
                        <p className="mb-0 textGray w600 font18">
                          Play quiz to earn more points
                        </p>
                        <Link to="/j_myaccount/j_quizhome">
                          <button className="borderNone textWhite bgPrime2 px-3 py-2">
                            Start
                          </button>
                        </Link>
                      </div>
                    </div>
                    <div className="col-12 p-3">
                      <p className="textLightGray w500 mt-2">
                        <IoMdInformationCircle className="textPrime2 mt-0" />{" "}
                        You can post one additional job preference once reach
                        1000 points
                      </p>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="row">
                      {rewardData?.map((item, key) => (
                        <div className="col-6 mt-4" key={key}>
                          <div className="singleSocialBox w-100 bgWhite p-3">
                            <div className="text-center socialIcon">
                              <img
                                src={item?.imageicon}
                                alt=""
                                className="mt-2 imgIcon"
                              />
                              <p className="mt-3 w600 textGray font18">
                                {item?.name}
                              </p>
                            </div>
                            <div className="d-flex justify-content-between mt-3">
                              <p className="textPrime2 w600 mb-0">
                                {item?.point} Points
                              </p>
                              <button className="borderNone bgPrime2 fullRadious textWhite">
                                <Link to={item?.urlopen}>
                                  <FaLessThan className="inIcon" />
                                </Link>
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Jsrewards;

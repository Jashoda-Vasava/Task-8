/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable react-hooks/exhaustive-deps */

import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./jsquizhome.css";
import { Container, Row } from "react-bootstrap";
import Sidebarjs from "../../Components/SideBarJSD/sidebarjsd";
import Myaccountheaderjsd from "../../Components/MyAccountHeaderJSD/myaccountheaderjsd";
import { IoMdInformationCircle } from "react-icons/io";
import { Link, useNavigate } from "react-router-dom";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";
import { useSelector } from "react-redux";

const Jsquizhome = () => {
  const [quizHeader, setQuizHeader] = useState([]);
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();

  useEffect(() => {
    getQuizHeader();
  }, []);

  /******************** API CALL START HERE **************************/
  const getQuizHeader = () => {
    const body = {
      isactive: "Y",
      pageable: {
        pageno: 0,
        pagesize: 10,
      },
    };
    axiosInstance
      .post(`${Constants.GetQuizHeader}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/j_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setQuizHeader(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/

  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div>
              <Sidebarjs />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="breadcrubsContainer bgWhite p-3">
                      <nav aria-label="breadcrumb">
                        <ol className="breadcrumb mb-0">
                          <li className="breadcrumb-item">
                            <Link
                              to="/j_myaccount"
                              className="linkNone textLightGray w600"
                            >
                              My Account
                            </Link>
                          </li>
                          <li className="breadcrumb-item">
                            <a href="#" className="linkNone textGray w600">
                              My Quiz
                            </a>
                          </li>
                        </ol>
                      </nav>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="col-12 mt-4">
                    <Myaccountheaderjsd />
                  </div>
                </Row>
                <Row>
                  <div className="col-md-6">
                    <div className="col-12">
                      <div className="currentPointContainer mt-4 w-100 bgWhite p-3">
                        <p className="textLightGray mb-0 font18">
                          You have total
                          <span className="textPrime2 w600">
                            {" "}
                            {localStorage.getItem("score")
                              ? localStorage.getItem("score")
                              : 0}{" "}
                            {/* % */}
                          </span>
                          points
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-12">
                    <Row>
                      {quizHeader?.map((item, key) => (
                        <div className="col-md-6" key={key}>
                          <div className="singleQuizContainer w-100 p-3 bgWhite mt-4">
                            <div>
                              <p className="mb-0 font14 textLightGray w600">
                                10 Question
                              </p>
                              <h4>{item?.name}</h4>
                            </div>
                            <Link to={`/j_myaccount/j_quiz/${item?.quizid}`}>
                              <button className="px-3 py-2 bgPrime2 textWhite borderNone">
                                Play
                              </button>
                            </Link>
                          </div>
                        </div>
                      ))}
                    </Row>
                  </div>
                  <p className="textLightGray w500 mt-2">
                    <IoMdInformationCircle className="textPrime2" /> Play quiz
                    and score at least 60% to earn rewards
                  </p>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Jsquizhome;

/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { Button, Container, Row } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import "../../Common/common.css";
import JobAndCity from "../../Components/JobAndCity/jobAndCity";
import SearchBar from "../../Components/SearchBar/searchBar";
import axiosInstance from "../../Api/commonUrl";
import swal from "sweetalert";
import * as Constants from "../../Common/Global/constants";
import { useSelector } from "react-redux";

const AllJobsCity = () => {
  const [cityData, setCityData] = useState([]);
  const [geteducationData, setEducationData] = useState([]);
  const Token = useSelector((state) => state?.token);
  const [education, setEducation] = useState(false);
  const [city, setCity] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    getEducation();
    getCityMaster();
  }, []);

  /******************** API CALL START HERE **************************/
  const getEducation = () => {
    const body = {
      isactive: "Y",
      pageable: {
        pageno: 0,
        pagesize: 20,
      },
    };
    axiosInstance
      .post(`${Constants.GetEducation}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setEducationData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getCityMaster = () => {
    const body = {
      isactive: "Y",
      pageable: {
        pageno: 0,
        pagesize: 20,
      },
    };
    axiosInstance
      .post(`${Constants.GetCityMaster}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setCityData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  /******************** API CALL END HERE **************************/
  return (
    <Container>
      <div className="d-flex justify-content-center mt50">
        <SearchBar />
      </div>
      <Row>
        <h1 className="text-center textGray w700 mb50">
          Job <span className="textPrime">Categories</span>
        </h1>
        {education === false
          ? geteducationData?.slice(0, 11).map((item, key) => (
              <div className="col-md-3 col-lg-3" key={key}>
                <Link className="linkNone" to="/categorydetails">
                  <JobAndCity name={item?.name} candidate={item?.data_count} />
                </Link>
              </div>
            ))
          : null}
        {education === false ? (
          <div className="col-md-3">
            <div className="bgOffWhite text-center jobAndCityBoxContainer">
              <Link
                className="textGray font18 w700 linkNone"
                onClick={() => setEducation(true)}
              >
                View All
              </Link>
            </div>
          </div>
        ) : null}
        {education === true
          ? geteducationData?.map((item, key) => (
              <div className="col-md-3 col-lg-3" key={key}>
                <Link className="linkNone" to="/categorydetails">
                  <JobAndCity name={item?.name} candidate={item?.data_count} />
                </Link>
              </div>
            ))
          : null}
        {education === true ? (
          <div className="col-md-3">
            <div className="bgOffWhite text-center jobAndCityBoxContainer">
              <Button
                className="textGray font18 w700 linkNone"
                onClick={() => setEducation(false)}
              >
                View All
              </Button>
            </div>
          </div>
        ) : null}
      </Row>
      <Row>
        <h1 className="text-center textGray w700 my50">
          All <span className="textPrime">Cities</span>
        </h1>

        {city === false
          ? cityData?.slice(0, 11).map((item, key) => (
              <div className="col-md-4 col-lg-3" key={key}>
                <JobAndCity name={item.city} candidate={item?.data_count} />
              </div>
            ))
          : null}
        {city === false ? (
          <div className="col-md-3">
            <div className="bgOffWhite text-center jobAndCityBoxContainer">
              <Link
                className="textGray font18 w700 linkNone"
                onClick={() => setCity(true)}
              >
                View All
              </Link>
            </div>
          </div>
        ) : null}
        {city === true
          ? cityData?.map((item, key) => (
              <div className="col-md-4 col-lg-3" key={key}>
                <JobAndCity name={item.city} candidate={item?.data_count} />
              </div>
            ))
          : null}
        {city === true ? (
          <div className="col-md-3">
            <div className="bgOffWhite text-center jobAndCityBoxContainer">
              <Link
                className="textGray font18 w700 linkNone"
                onClick={() => setCity(false)}
              >
                View All
              </Link>
            </div>
          </div>
        ) : null}
      </Row>
    </Container>
  );
};
export default AllJobsCity;

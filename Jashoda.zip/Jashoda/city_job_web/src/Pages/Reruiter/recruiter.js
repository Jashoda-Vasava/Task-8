/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import "./recruiter.css";
import "../../Common/common.css";
import { Container, Row } from "react-bootstrap";
import Accordion from "react-bootstrap/Accordion";
import Buttons from "../../Components/Buttons/buttons";
import Download from "../../Components/Download/download";
import KeyFeture from "../../Components/KeyFeture/keyFeture";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";
import Slider from "react-slick";
import VideoText from "../../Components/VideoText/videoText";
import DownloadModal from "../../Components/DownloadModal/downloadModal";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import Pricing from "../Pricing/pricing";
import { rtloginUser } from "../../redux/action/action";

const Recruiter = () => {
  const [show, setShow] = useState(false);
  const [faqData, setFaqData] = useState([]);
  const [videodetailData, setVideodetailData] = useState([]);
  let [firstname, setFirstName] = useState("");
  let [mobileno, setMobileNo] = useState("");
  let [emailid, setEmailid] = useState("");
  let [companyname, setCompanyname] = useState("");
  let [myposition, setMyposition] = useState("");
  const Token = useSelector((state) => state?.token);
  const dispatch = useDispatch();
  let [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    getFaqDetails();
    getVideoDetail();
  }, []);

  /******************** API CALL START HERE **************************/
  const recruiterRegister = () => {
    validate();
    const body = {
      emailid: emailid,
      mobileno: mobileno,
    };
    if (emailid && mobileno && firstname && myposition && companyname) {
      axiosInstance
        .post(`${Constants.SaveRecruitmentSignIn}`, body, {
          headers: {
            "Content-type": "application/json",
            Authorization: `Bearer ${Token}`,
          },
        })
        .then((response) => {
          if (
            response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED
          ) {
            localStorage.clear();
            navigate("/");
          } else if (response.data.status === Constants.CODE_SUCCESS) {
            dispatch(rtloginUser(response.data.data));
            recruiterPersonalInfo(response.data.data);
            recruiterCompanyInfo(response.data.data?.userid);
            swal(`${response.data.massage}`, "", "success");
          } else {
            swal(`${response.data.massage}`, "", "error");
          }
          setMobileNo("");
          setEmailid("");
          setCompanyname("");
          setFirstName("");
          setMyposition("");
        })
        .catch((error) => swal(`${error.response.data.massage}`, "", "error"));
    }
  };

  const recruiterPersonalInfo = (data) => {
    const body = {
      userid: data?.userid,
      firstname: firstname,
      myposition: myposition,
      emailid: data?.emailid,
      mobileno: data?.mobileno,
    };
    axiosInstance
      .post(`${Constants.SaveRecruitmentPersonalInfo}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          return response.data.data;
        } else {
          swal(`${response.data.massage}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.massage}`, "", "error"));
  };

  const recruiterCompanyInfo = (userid) => {
    const body = {
      userid: userid,
      name: companyname,
    };
    axiosInstance
      .post(`${Constants.SaveRecruitmentCompanyInfo}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          return response.data.data;
        } else {
          swal(`${response.data.massage}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.massage}`, "", "error"));
  };
  const getVideoDetail = () => {
    const body = {
      pagecode: "RECRUITER",
      isactive: "Y",
      pageable: {
        pageno: 0,
        pagesize: 10,
      },
    };
    axiosInstance
      .post(`${Constants.GetVideoDetail}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setVideodetailData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getFaqDetails = () => {
    const body = {
      applicableto: "Recruiter",
    };
    axiosInstance
      .post(`${Constants.GetFAQ}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setFaqData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/

  /** Validation Function */
  const validate = () => {
    let errors = [];
    if (!firstname) {
      errors.firstname = "Name is required";
    }
    if (!mobileno) {
      errors.mobileno = "Mobileno is required";
    }
    if (!emailid) {
      errors.emailid = "Email id is required";
    }
    if (!companyname) {
      errors.companyname = "Company name is required";
    }
    if (!myposition) {
      errors.myposition = "Designation is required";
    }
    if (!firstname) firstname = "";
    if (!mobileno) mobileno = "";
    if (!emailid) emailid = "";
    if (!companyname) emailid = "";
    if (!myposition) myposition = "";
    return setError(errors);
  };

  /** VIDEOS SLIDER **/
  const videoSlider = {
    rows: 1,
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 2,
    autoplay: true,
    autoplaySpeed: 2500,
    arrows: true,
    responsive: [
      {
        breakpoint: 1350,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1080,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
    <Container fluid>
      <Container className="py100">
        <Row>
          <div className="col-md-6">
            <h2 className="w700 textGray mb-5">
              Hire <span className="textPrime">Talent</span> Instantly !!!
            </h2>
            <img
              src="/assets/images/sidePhoto.png"
              className="w-100"
              alt=""
            ></img>
          </div>
          <div className="col-md-6 text-centers ps-0 ps-md-5">
            <div className="formContainer text-center bgWhite">
              <h2 className="w700 textGray mb-5 text-start">
                Fill the <span className="textPrime">From</span> Below
              </h2>
              <input
                placeHolder="Your Name"
                className="offInput bgOffWhite borderNone outlineNone ps-3"
                name="firstname"
                value={firstname}
                onChange={(e) => setFirstName(e.target.value)}
              />
              {!firstname && error.firstname ? (
                <p className="errContact text-start">{error.firstname}</p>
              ) : null}
              <input
                placeHolder="Email"
                className="offInput bgOffWhite borderNone outlineNone ps-3"
                name="emailid"
                value={emailid}
                onChange={(e) => setEmailid(e.target.value)}
              />
              {!emailid && error.emailid ? (
                <p className="errContact text-start">{error.emailid}</p>
              ) : null}
              <input
                placeHolder="Mobile No."
                className="offInput bgOffWhite borderNone outlineNone ps-3"
                name="mobileno"
                value={mobileno}
                onChange={(e) => setMobileNo(e.target.value)}
              />
              {!mobileno && error.mobileno ? (
                <p className="errContact text-start">{error.mobileno}</p>
              ) : null}
              <input
                placeHolder="Company's Name"
                className="offInput bgOffWhite borderNone outlineNone ps-3"
                name="companyname"
                value={companyname}
                onChange={(e) => setCompanyname(e.target.value)}
              />
              {!companyname && error.companyname ? (
                <p className="errContact text-start">{error.companyname}</p>
              ) : null}
              <input
                placeHolder="Your Designation"
                className="offInput bgOffWhite borderNone outlineNone ps-3"
                name="myposition"
                value={myposition}
                onChange={(e) => setMyposition(e.target.value)}
              />
              {!myposition && error.myposition ? (
                <p className="errContact text-start">{error.myposition}</p>
              ) : null}
              <div class=" justify-content-center rowButton">
                <Buttons
                  bgColor="Prime"
                  textColor="White"
                  content="Submit"
                  hover="greenHover"
                  onClick={recruiterRegister}
                />
                <span className="w700 text-center inputOr w-50">OR</span>
                <Link to="/rt_login">
                  <Buttons
                    bgColor="Prime"
                    textColor="White"
                    content="Login"
                    hover="greenHover"
                  />
                </Link>
              </div>
            </div>
          </div>
        </Row>
      </Container>
      <div className="bgOffWhite py100 text-center">
        <h1 className="w700 textGray">
          Hire <span className="textPrime"> Talented </span>Employees
        </h1>
        <div className="hireImageContainer mt50 mb-3">
          <div className="oneStep">
            <img src="/assets/images/seeker1.png" alt="" />
            <p className="w500 textGray mt-2">#1 Build Your Profile</p>
          </div>
          <div className="oneStep">
            <img src="/assets/images/comp2.png" alt="" />
            <p className="w500 textGray mt-2">#2 Post a Job</p>
          </div>
          <div className="oneStep">
            <img src="/assets/images/seeker3.png" alt="" />
            <p className="w500 textGray mt-2">#3 Hire a Perfect Employee</p>
          </div>
        </div>
        <Buttons
          bgColor="Prime"
          textColor="White"
          content="Start Hiring"
          hover="greenHover"
          onClick={() => {
            setShow(true);
          }}
        />
        <DownloadModal show={show} setShow={setShow} />
      </div>
      <Container className="my100">
        <Slider {...videoSlider}>
          {videodetailData?.map((item, key) => (
            <VideoText
              key={key}
              video={item?.videourl}
              Heading={item?.header}
              Content={item?.description}
            />
          ))}
        </Slider>
      </Container>
      <Container>
        <div className="py50 text-center">
          <h1 className="w700 textGray mb-5">
            Our Key <span className="textPrime">Features</span>
          </h1>
          <Row>
            <div className="col-md-3 d-flex justify-content-center">
              <KeyFeture
                content="Direct Communication with Job Seekers"
                path="chat.png"
              />
            </div>
            <div className="col-md-3 d-flex justify-content-center">
              <KeyFeture content="Data Security" path="secure.png" />
            </div>
            <div className="col-md-3 d-flex justify-content-center">
              <KeyFeture content="Conduct Video Interviews" path="vcall.png" />
            </div>
            <div className="col-md-3 d-flex justify-content-center">
              <KeyFeture content="100% Data Security" path="secure2.png" />
            </div>
          </Row>
        </div>
      </Container>
      <Container>
        <div>
          <Pricing />
        </div>
      </Container>
      <Container fluid className="py50">
        <h1 className="w700 textPrime text-center">
          FAQ<span className="textGray">s</span>
        </h1>
        {faqData?.map((item, key) => (
          <div className="faq_accordian" key={key}>
            <Accordion>
              <Accordion.Item eventKey="0">
                <Accordion.Header>{item?.question}</Accordion.Header>
                <Accordion.Body>
                  <p className="mb-0 textJustify">{item?.answer}</p>
                </Accordion.Body>
              </Accordion.Item>
              <hr className="mx-3" />
            </Accordion>
          </div>
        ))}
      </Container>
      <Download />
    </Container>
  );
  //
};
export default Recruiter;

/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { Container, Row } from "react-bootstrap";
import "../../Common/common.css";
import Buttons from "../../Components/Buttons/buttons";
import Download from "../../Components/Download/download";
import KeyFeture from "../../Components/KeyFeture/keyFeture";
import "./jobSeeker.css";
import Accordion from "react-bootstrap/Accordion";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";
import Slider from "react-slick";
import VideoText from "../../Components/VideoText/videoText";
import DownloadModal from "../../Components/DownloadModal/downloadModal";
import { useSelector } from "react-redux";
import JobSeekerPlans from "../Pricing/jobSeekerPlans";
import { useNavigate } from "react-router-dom";

const JobSeeker = () => {
  const [show, setShow] = useState(false);
  const [faqData, setFaqData] = useState([]);
  const [videodetailData, setVideodetailData] = useState([]);
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();

  useEffect(() => {
    getVideoDetail();
    getFaqDetails();
  }, []);

  /******************** API CALL START HERE **************************/
  const getVideoDetail = () => {
    const body = {
      pagecode: "JOBSEEKER_PAGE",
      isactive: "Y",
      pageable: {
        pageno: 0,
        pagesize: 10,
      },
    };
    axiosInstance
      .post(`${Constants.GetVideoDetail}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setVideodetailData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      });
    // .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getFaqDetails = () => {
    const body = {
      applicableto: "Job Seeker",
    };
    axiosInstance
      .post(`${Constants.GetFAQ}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setFaqData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/

  //VIDEOS SLIDER
  const videoSlider = {
    rows: 1,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 2,
    autoplay: true,
    autoplaySpeed: 2500,
    arrows: true,
  };

  return (
    <Container fluid>
      <Download />
      <Container className="my100">
        <Slider {...videoSlider}>
          {videodetailData?.map((item, key) => (
            <VideoText
              key={key}
              video={item?.videourl}
              Heading={item?.header}
              Content={item?.description}
            />
          ))}
        </Slider>
      </Container>
      <div className="bgOffWhite py100 text-center">
        <h1 className="w700 textGray">
          How To Get Your <span className="textPrime">Dream</span>Job
        </h1>
        <div className="seekerImageContainer mt50 mb-3">
          <div className="oneStep">
            <img src="/assets/images/seeker1.png" alt="" />
            <p className="w500 textGray mt-2">#1 Build Your Profile</p>
          </div>
          <div className="oneStep">
            <img src="/assets/images/seeker2.png" alt="" />
            <p className="w500 textGray mt-2">#2 Apply for jobs</p>
          </div>
          <div className="oneStep">
            <img src="/assets/images/seeker3.png" alt="" />
            <p className="w500 textGray mt-2">#3 Get Your Dream Job</p>
          </div>
        </div>
        <Buttons
          bgColor="Prime"
          textColor="White"
          content="Get Hired"
          hover="greenHover"
          onClick={() => {
            setShow(true);
          }}
        />
        <DownloadModal show={show} setShow={setShow} />
      </div>
      <Container className="my100">
        <Slider {...videoSlider}>
          {videodetailData?.map((item, key) => (
            <VideoText
              key={key}
              video={item?.videourl}
              Heading={item?.header}
              Content={item?.description}
            />
          ))}
        </Slider>
      </Container>
      <Container>
        <div className="py100 text-center">
          <h1 className="w700 textGray mb-5">
            Our Key <span className="textPrime">Features</span>
          </h1>
          <Row>
            <div className="col-md-4 d-flex justify-content-center">
              <KeyFeture
                content="Direct Communication with Recruiters"
                path="chat.png"
              />
            </div>
            <div className="col-md-4 d-flex justify-content-center">
              <KeyFeture
                content="AI Powered Job Recommendations"
                path="ai.png"
              />
            </div>
            <div className="col-md-4 d-flex justify-content-center">
              <KeyFeture
                content="Built In Video Call Function"
                path="vcall.png"
              />
            </div>
          </Row>
        </div>
      </Container>
      <Container>
        <div>
          <JobSeekerPlans />
        </div>
      </Container>
      <Container fluid>
        <h1 className="w700 textPrime text-center">
          FAQ<span className="textGray">s</span>
        </h1>
        {faqData?.map((item, key) => (
          <div className="faq_accordian" key={key}>
            <Accordion defaultActiveKey="0">
              <Accordion.Item>
                <Accordion.Header>{item?.question}</Accordion.Header>
                <Accordion.Body>
                  <p className="mb-0 textJustify">{item?.answer}</p>
                </Accordion.Body>
              </Accordion.Item>
              <hr className="mx-3" />
            </Accordion>
          </div>
        ))}
      </Container>
    </Container>
  );
};
export default JobSeeker;

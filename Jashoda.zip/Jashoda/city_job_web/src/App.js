import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Landingpage from "./Pages/Landingpage/landingpage";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import JobSeeker from "./Pages/JobSeeker/jobSeeker";
import { Routes, Route } from "react-router-dom";
import Homepage from "./Pages/Homepage/homepage";
import Recruiter from "./Pages/Reruiter/recruiter";
import AllJobsCity from "./Pages/AllJobsCity/allJobsCity";
import CategoryDetails from "./Pages/CategoryDetails/categoryDetails";
import Legal from "./Pages/Legal/legal";
import TermsAndContion from "./Pages/Legal/termsAndContion";
import Contact from "./Pages/Contact/contact";
import CandidateInfo from "./Pages/CandidateInfo/candidateInfo";
import About from "./Pages/About/about";
import Listing from "./Pages/Listing/listing";
import Slider from "./Pages/Slider/slider";
import Pricing from "./Pages/Pricing/pricing";
import PrivacyPolicy from "./Pages/Legal/privacyPolicy";
import RefundPolicy from "./Pages/Legal/refundPolicy";
//jobseeker dashboard
import Jshome from "./JSPages/JSHome/jshome";
import Jsjobdetails from "./JSPages/JSJobDetails/jsjobdetails";
import Jslogin from "./JSPages/JSLogin/jslogin";
import Jsmyaccount from "./JSPages/JSMyAccount/jsmyaccount";
import Jsjoblist from "./JSPages/JSJobList/jsjoblist";
import Jsgreetings from "./JSPages/JSGreetings/jsgreetings";
import Jscontact from "./JSPages/JSContact/jscontact";
import Jsjobpreferences from "./JSPages/JSJobPreferences/jsjobpreferences";
import Jssaved from "./JSPages/JSSaved/jssaved";
import Jssearch from "./JSPages/JSSearch/jssearch";
import Jsshare from "./JSPages/JSShare/jsshare";
import Jsrewards from "./JSPages/JSRewards/jsrewards";
import Jsquizhome from "./JSPages/JSQuizHome/jsquizhome";
import Jsmypayment from "./JSPages/JSMyPayment/jsmypayment";
import Jsquizmain from "./JSPages/JSQuizMain/jsquizmain";
import Jsquizresult from "./JSPages/JSQuizResult/jsquizresult";
// Recruiter Dashboard
import Rthome from "./RTPages/RTHome/rthome";
import Rtcandidatelist from "./RTPages/RTCandidateList/rtcandidatelist";
import Rtjobinfo from "./RTPages/RTJobInfo/rtjobinfo";
import Rtcandidatedetails from "./RTPages/RTCandidateDetails/rtcandidatedetails";
import Rtmyaccount from "./RTPages/RTMyAccount/rtmyaccount";
import Rtmanagejobs from "./RTPages/RTManageJobs/rtmanagejobs";
import Rtsavedjobs from "./RTPages/RTSavedCandidates/rtsavedcandidates";
import Rtshare from "./RTPages/RTShare/rtshare";
import Rtsearch from "./RTPages/RTSearch/rtseach";
import Rtgreetings from "./RTPages/RTGreetings/rtgreetings";
import Rtcontact from "./RTPages/RTContact/rtcontact";
import Rtmypayment from "./RTPages/RTMypayment/rtmypayment";
import Rtlogin from "./RTPages/RTLogin/rtlogin";
import RtAllJobs from "./RTPages/RTAllJobs/rtalljobs";
import RtOtp from "./RTPages/RTOtp/rtotp";
import JsOtp from "./JSPages/JSOtp/jsotp";
import RTPrivateRoute from "./RTPages/RTPrivateRoute/rtprivateroute";
import JSPrivateRoute from "./JSPages/JSPrivateRoute/jsprivateroute";
import { JSPublicRoute } from "./JSPages/JSPrivateRoute/jspublicroute";

const App = () => {
  return (
    <>
      <Routes>
        {/* Web Dashbord */}
        <Route exact path="/" element={<Homepage />}>
          <Route exact path="" element={<Landingpage />} />
          <Route exact path="jobseeker" element={<JobSeeker />} />
          <Route exact path="recruiter" element={<Recruiter />} />
          <Route exact path="alljobs" element={<AllJobsCity />} />
          <Route exact path="categorydetails" element={<CategoryDetails />} />
          <Route exact path="legal" element={<Legal />} />
          <Route exact path="terms" element={<TermsAndContion />} />
          <Route exact path="privacy" element={<PrivacyPolicy />} />
          <Route exact path="refund" element={<RefundPolicy />} />
          <Route exact path="contact" element={<Contact />} />
          <Route exact path="info" element={<CandidateInfo />} />
          <Route exact path="about" element={<About />} />
          <Route exact path="listing" element={<Listing />} />
          <Route exact path="pricing" element={<Pricing />} />
          <Route exact path="slider" element={<Slider />} />
        </Route>

        {/* Job Seeker Dashboard */}
        <Route
          exact
          path="/j_home"
          element={
            <JSPrivateRoute>
              <Jshome />
            </JSPrivateRoute>
          }
        />
        <Route exact path="/j_login" element={<Jslogin />} />
        <Route
          exact
          path="/js_otp"
          element={
            <JSPublicRoute>
              <JsOtp />
            </JSPublicRoute>
          }
        />
        <Route
          exact
          path="/j_share"
          element={
            <JSPrivateRoute>
              <Jsshare />
            </JSPrivateRoute>
          }
        />
        {/* jobList */}

        <Route
          exact
          path="/j_joblist"
          element={
            <JSPrivateRoute>
              <Jsjoblist />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_joblist/j_jobdetails/:id"
          element={
            <JSPrivateRoute>
              <Jsjobdetails />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_joblist/j_search"
          element={
            <JSPrivateRoute>
              <Jssearch />
            </JSPrivateRoute>
          }
        />
        {/* {My Account} */}
        <Route
          exact
          path="/j_myaccount"
          element={
            <JSPrivateRoute>
              <Jsmyaccount />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_myaccount/j_greetings"
          element={
            <JSPrivateRoute>
              <Jsgreetings />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_myaccount/j_contact"
          element={
            <JSPrivateRoute>
              <Jscontact />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_myaccount/j_jobpreference"
          element={
            <JSPrivateRoute>
              <Jsjobpreferences />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_myaccount/j_saved"
          element={
            <JSPrivateRoute>
              <Jssaved />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_myaccount/j_rewards"
          element={
            <JSPrivateRoute>
              <Jsrewards />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_myaccount/j_quizhome"
          element={
            <JSPrivateRoute>
              <Jsquizhome />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_myaccount/j_mypayment"
          element={
            <JSPrivateRoute>
              <Jsmypayment />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_myaccount/j_quiz/:id"
          element={
            <JSPrivateRoute>
              <Jsquizmain />
            </JSPrivateRoute>
          }
        />
        <Route
          exact
          path="/j_myaccount/j_quizresult"
          element={
            <JSPrivateRoute>
              <Jsquizresult />
            </JSPrivateRoute>
          }
        />

        {/* Recruiter Dashboard */}
        <Route exact path="/rt_login" element={<Rtlogin />} />
        <Route exact path="/rt_otp" element={<RtOtp />} />
        <Route
          exact
          path="/rt_share"
          element={
            <RTPrivateRoute>
              <Rtshare />
            </RTPrivateRoute>
          }
        />
        {/* Home */}
        <Route
          exact
          path="/rt_home"
          element={
            <RTPrivateRoute>
              <Rthome />
            </RTPrivateRoute>
          }
        />
        <Route
          exact
          path="/rt_home/rt_jobinfo/:id"
          element={
            <RTPrivateRoute>
              <Rtjobinfo />
            </RTPrivateRoute>
          }
        />
        {/* All Job */}
        <Route
          exact
          path="/rt_alljobs"
          element={
            <RTPrivateRoute>
              <RtAllJobs />
            </RTPrivateRoute>
          }
        />
        <Route
          exact
          path="/rt_alljobs/rt_candidatelist/:id"
          element={
            <RTPrivateRoute>
              <Rtcandidatelist />
            </RTPrivateRoute>
          }
        />
        <Route
          exact
          path="/rt_alljobs/rt_candidatelist/rt_candidatedetails/:id"
          element={
            <RTPrivateRoute>
              <Rtcandidatedetails />
            </RTPrivateRoute>
          }
        />
        <Route
          exact
          path="/rt_alljobs/rt_search"
          element={
            <RTPrivateRoute>
              <Rtsearch />
            </RTPrivateRoute>
          }
        />
        {/* My Account */}
        <Route
          exact
          path="/rt_myaccount"
          element={
            <RTPrivateRoute>
              <Rtmyaccount />
            </RTPrivateRoute>
          }
        />
        <Route
          exact
          path="/rt_myaccount/rt_managejobs"
          element={
            <RTPrivateRoute>
              <Rtmanagejobs />
            </RTPrivateRoute>
          }
        />
        <Route
          exact
          path="/rt_myaccount/rt_savedcandidates"
          element={
            <RTPrivateRoute>
              <Rtsavedjobs />
            </RTPrivateRoute>
          }
        />
        <Route
          exact
          path="/rt_myaccount/rt_greetings"
          element={
            <RTPrivateRoute>
              <Rtgreetings />
            </RTPrivateRoute>
          }
        />
        <Route
          exact
          path="/rt_myaccount/rt_contact"
          element={
            <RTPrivateRoute>
              <Rtcontact />
            </RTPrivateRoute>
          }
        />
        <Route
          exact
          path="/rt_myaccount/rt_mypayment"
          element={
            <RTPrivateRoute>
              <Rtmypayment />
            </RTPrivateRoute>
          }
        />
      </Routes>
    </>
  );
};

export default App;

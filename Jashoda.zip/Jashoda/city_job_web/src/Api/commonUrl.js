import axios from "axios";
import * as Constants from "../Common/Global/url";

export default axios.create({
  baseURL: Constants.BASE_URL_API,
});

import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./myaccountheaderrt.css";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import swal from "sweetalert";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const MyaccountheaderRt = () => {
  const [personalInfoData,setPersonalInfoData]=useState([]);
  const [companyInfoData,setCompanyInfoData]=useState([]);
  const user = useSelector((state) => state.user);
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();

  useEffect(() => {
    getRecruitmentPersonalInfo();
    getRecruitmentCompanyInfo()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /******************** API CALL START HERE **************************/
  const getRecruitmentPersonalInfo = () => {
    const body = {
      userid: user?.userid,
      isapply: "Y",
    };
    axiosInstance
      .post(`${Constants.GetRecruitmentPersonalInfo}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/rt_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setPersonalInfoData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getRecruitmentCompanyInfo = () => {
    const body = {
      userid: user?.userid,
      isapply: "Y",
    };
    axiosInstance
      .post(`${Constants.GetRecruitmentCompanyInfo}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/rt_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setCompanyInfoData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  /******************** API CALL END HERE **************************/
  return (
    <>
      {personalInfoData?.map((item, key) => (
        <div className="myAccountHeaderMainContainer bg-white px-4" key={key}>
          <div className="d-flex">
            <img
              src={
                item?.profileimage
                  ? item?.profileimage
                  : "/assets/images/defaultUser.png"
              }
              className="accountHeaderImage rounded-circle"
              alt=""
            />
            <div className="ms-3">
              <h3 className="mb-0 w600 textPrime2">
                {item?.firstname} {item?.lastname}
              </h3>
              {companyInfoData?.map((item, key) => (
                <p className="textLightGray w500" key={key}>
                  {item?.name}
                </p>
              ))}
            </div>
          </div>
          <Link to="/rt_myaccount/rt_mypayment">
            <p className="textUnderline textPrime2 w600">My Plan</p>
          </Link>
        </div>
      ))}
    </>
  );
};

export default MyaccountheaderRt;

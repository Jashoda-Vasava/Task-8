import React from "react";
import "../../Common/common.css";
import "./jobpreferencecardjsd.css";

const Jobpreferencecardjsd = (props) => {
  return (
    <>
      <div className="singlePreferenceBox w-100 bgWhite p-3">
        <p className="textPrime2 w600 mb-0">
          {props?.name}
          <span className="ms-3 textLightGray">Rs {props?.salary}</span>
        </p>
        <p className="textLightGray w600">{props?.technology}</p>
        <p className="textLightGray w600">
          {props?.city}
          {props?.state}
        </p>
      </div>
    </>
  );
};

export default Jobpreferencecardjsd;

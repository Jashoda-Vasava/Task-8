import React from "react";

const Filterrt = () => {
  return (
    <>
      <p className="w600 textPrime2 font14 mb-2">Functional Area</p>
      <input
        type="text"
        placeholder="eg. Java Developer"
        className="filterInput"
      />
      <p className="mt-4 w600 textPrime2 font14 mb-2">Job Type</p>
      <select className="w-100 p-2 filterOutline outlineNone">
        <option value="">Full-Time</option>
        <option value="">Part-Time</option>
        <option value="">Contract</option>
      </select>
      <p className="mt-4 w600 textPrime2 font14 mb-2">Required Education</p>
      <select className="w-100 p-2 filterOutline outlineNone">
        <option value="">10th Pass</option>
        <option value="">Diploma</option>
        <option value="">Graduate</option>
      </select>
      <p className="mt-4 w600 textPrime2 font14 mb-2">Industry</p>
      <select className="w-100 p-2 filterOutline outlineNone">
        <option value="">Information Technology</option>
        <option value="">Marketing</option>
        <option value="">Finance</option>
      </select>
      <p className="mt-4 w600 textPrime2 font14 mb-2">Required Experience</p>
      <select className="w-100 p-2 filterOutline outlineNone">
        <option value="">Less than 1 Year</option>
        <option value="">1-3 Year</option>
        <option value="">3-5 Year</option>
        <option value="">5-10 Year</option>
        <option value="">10 Year +</option>
      </select>
      <p className="mt-4 w600 textPrime2 font14 mb-2">Location</p>
      <input
        type="text"
        placeholder="eg. Java Developer"
        className="filterInput"
      />
      <button className="w-100 mt-4 py-2 bgPrime2 textWhite borderNone">
        Apply Filter
      </button>
    </>
  );
};
export default Filterrt;

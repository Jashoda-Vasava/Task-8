import { React } from "react";
import Modal from "react-bootstrap/Modal";
import Buttons from "../Buttons/buttons";
import { IoLogoGooglePlaystore } from "react-icons/io5";
import { SiAppstore } from "react-icons/si";
import { ImCross } from "react-icons/im";
import "./downloadModal.css";
import "../../Common/common.css";

const DownloadModal = ({ show, setShow }) => {
  return (
    <>
      <Modal centered show={show} onHide={setShow}>
        <Modal.Body className="text-center py50">
          <button
            onClick={() => {
              setShow(false);
            }}
            className="modalCloseButton bgNone borderNone outlineNone textGray"
          >
            <ImCross />
          </button>
          <br />
          <h4 className="w700 textGray">
            <span className="textPrime">Download</span> Now !
          </h4>
          <img src="/assets/images/qr.png" height="200px" alt="" />
          <input
            type="text"
            className="borderNone outlineNone modalInput my-4"
            placeholder="Enter mobile no."
          />
          <br />
          <Buttons
            bgColor="Prime"
            textColor="White"
            content="Send me the link"
            hover=" "
            className="mb50 "
          />
          <div className="d-flex justify-content-center mt-4">
            <SiAppstore className="font30 me-2 textGray" />
            <IoLogoGooglePlaystore className="ms-2 font30 textGray" />
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default DownloadModal;

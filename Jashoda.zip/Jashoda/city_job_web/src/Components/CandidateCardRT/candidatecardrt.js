import React from "react";
import "./candidatecardrt.css";
import { AiTwotoneHeart } from "react-icons/ai";
import { TbCertificate } from "react-icons/tb";

const Candidatecardrt = (props) => {
  return (
    <>
      <div className="candidateCardInfo w-100 bgWhite p-3">
        <div className="d-flex align-item-center justify-content-between">
          <div className="d-flex">
            <img
              src={props?.profileimage}
              className="userImage rounded-circle"
              alt=""
            />
            <div className="ms-3">
              <p className="mb-0 font18 w600 textGray mt-2">{props?.firstname} {props?.lastname}</p>
              <p className="mb-0 font14 w500 text-secondary">
              {props?.company}  {props?.experience}
              </p>
            </div>
          </div>
          <div className="d-flex mt-3">
            <h3 className="font20 textPrime2 w600">Rs {props?.salary}</h3>
            <AiTwotoneHeart className={props?.Icons} onClick={props?.hendleChangeLike}/>
          </div>
        </div>
        <div className="workExp d-flex mt-4 ms-2">
          <TbCertificate className="mt-3 font22 text-secondary" />
          <div className="ms-3">
            <p className="mb-0 font18 w600 textGray">
              {props?.education} 
            </p>
            <p className="mb-0 font14 w500 text-secondary">
              {props?.educationYear}
            </p>
          </div>
        </div>
        <p className="mt-4 w600 text-secondary w-100 text-truncate">
         {props?.description}
        </p>
      </div>
    </>
  )
}

export default Candidatecardrt


import React, { useState } from "react";
import "../../Common/common.css";
import "./sidebarjsd.css";
import { NavLink, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { logout } from "../../redux/action/action";

const Sidebarjsd = () => {
  const [collapsSidebar, setCollaps] = useState(true);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  //TOGGLE BUTTON OPEN AND CLOSE
  const handleCollaps = () => {
    if (collapsSidebar === true) {
      setCollaps(false);
    } else {
      setCollaps(true);
    }
  };

  const logOut = () => {
    dispatch(logout());
    localStorage.clear();
    navigate("/");
  };

  //SIDEBAR MENU ITEMS OBJECT
  const menuItem = [
    {
      path: "/j_home",
      name: "Home",
      icon: <img src="/assets/images/home-icon.svg" alt="" />,
    },
    {
      path: "/j_joblist",
      name: "Job",
      icon: <img src="/assets/images/job-icon.svg" alt="" />,
    },
    {
      path: "/j_myaccount",
      name: "My Account",
      icon: <img src="/assets/images/account-icon.svg" alt="" />,
    },
    {
      path: "/j_share",
      name: "Share",
      icon: <img src="/assets/images/share-icon.svg" alt="" />,
    },
    {
      path: "/",
      name: "Logout",
      icon: <img src="/assets/images/logout-icon.svg" alt="" />,
      onClick: logOut,
    },
  ];

  return (
    <>
      <div className="sideBarMainCotainer">
        <div
          className="sideBarContent"
          style={{ width: collapsSidebar === true ? "250px" : "58px" }}
        >
          <img
            src="/assets/images/city-job-text-icon.png"
            className="sidebarLogoWithText mb-4"
            alt=""
          />
          <br />
          {menuItem?.map((item, index) => (
            <div className="cursorPointer d-flex">
              <NavLink
                to={item.path}
                key={index}
                className="link"
                activeclassName="active"
                onClick={item.onClick}
              >
                <div className="link-icon">{item.icon}</div>
                <div
                  style={{ display: collapsSidebar ? "block" : "none" }}
                  className="linkNone textGray ms-4 font18 w600 link-text cursorPointer"
                >
                  {item.name}
                </div>
              </NavLink>
            </div>
          ))}
        </div>
        <button
          className="collapsButton borderNone bgWhite textPrime2"
          onClick={handleCollaps}
        >
          &#x2630;
        </button>
      </div>
    </>
  );
};

export default Sidebarjsd;

import { React, useState } from "react";
import "./sidebarrt.css";
import "../../Common/common.css";
import { NavLink, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { logout } from "../../redux/action/action";
// import AppStore from "../../redux/store/store"

const Sidebarrt = () => {
  const [collapsSidebar, setCollaps] = useState(true);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  //TOGGLE BUTTON OPEN AND CLOSE
  const handleCollaps = () => {
    if (collapsSidebar === true) {
      setCollaps(false);
    } else {
      setCollaps(true);
    }
  };

  const logOut = () => {
    dispatch(logout());
    localStorage.clear();
    navigate("/");
  };

  //SIDEBAR MENU ITEMS OBJECT
  const menuItem = [
    {
      path: "/rt_home",
      name: "Home",
      icon: <img src="/assets/images/home-icon.svg" alt="" />,
    },
    {
      path: "/rt_alljobs",
      name: "Hire",
      icon: <img src="/assets/images/hire-icon.svg" alt="" />,
    },
    {
      path: "/rt_myaccount",
      name: " My Account",
      icon: <img src="/assets/images/account-icon.svg" alt="" />,
      submenu: [
        {
          path: "/rt_contact",
          name: " My Account",
          icon: <img src="/assets/images/account-icon.svg" alt="" />,
        },
      ],
    },
    {
      path: "/rt_share",
      name: "Share",
      icon: <img src="/assets/images/share-icon.svg" alt="" />,
    },
    {
      path: "/",
      name: "Logout",
      icon: <img src="/assets/images/logout-icon.svg" alt="" />,
      onClick: logOut,
    },
  ];
  return (
    <>
      <div className="sideBarMainCotainer">
        <div
          className="sideBarContent"
          style={{ width: collapsSidebar === true ? "250px" : "58px" }}
        >
          <img
            src="/assets/images/city-job-text-icon.png"
            className="sidebarLogoWithText mb-4"
            alt=""
          />
          <br />
          {menuItem.map((item, key) => (
            <div className="cursorPointer d-flex">
              <NavLink
                to={item.path}
                key={key}
                className="link"
                activeclassName="activeLink"
                onClick={item.onClick}
              >
                <div className="link-icon">{item.icon}</div>
                <div
                  style={{ display: collapsSidebar ? "block" : "none" }}
                  className="linkNone textGray ms-4 font18 w600 link-text cursorPointer"
                >
                  {item.name}
                </div>
              </NavLink>
              <div> </div>
            </div>
          ))}
        </div>
        <button
          className="collapsButton borderNone bgWhite textPrime2"
          onClick={handleCollaps}
        >
          &#x2630;
        </button>
      </div>
    </>
  );
};

export default Sidebarrt;

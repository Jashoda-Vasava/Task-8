/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from "react";
import "./navigationBar.css";
import "../../Common/common.css";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import { Link, NavLink } from "react-router-dom";
import DownloadModal from "../DownloadModal/downloadModal";

const NavigationBar = () => {
  const [show, setShow] = useState(false);
  const [expanded, setExpanded] = useState(false);

    const navToggle = () => {
        setExpanded(expanded ? false : true);
    };

    const closeNav = () => {
        setExpanded(false);
    };
  return (
    <>
      <Navbar className="jobNavbar bgWhite" expand="lg" expanded={expanded}>
        <Container fluid>
          <Navbar.Brand href="#home" onClick={closeNav}>
            <Link className="linkNone" to="">
              <img
                src="/assets/images/Logo.png"
                height="35px"
                className="mx-3"
                alt=""
              />
              <a className="font18 textGray linkNone w700">City Job</a>
            </Link>
          </Navbar.Brand>
          <Navbar.Toggle
           onClick={navToggle} 
            aria-controls="basic-navbar-nav"
            className="shadow-none"
          />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto"></Nav>
            <Nav className="ms-auto">
              <Nav.Link onClick={closeNav}>
                <NavLink
                activeClassName="active"
                  className="ms-3 w500 textGray textPrimeHover linkNone basic-navbar-nav"
                  to=""
                >
                  Home
                </NavLink>
              </Nav.Link>
              <Nav.Link onClick={closeNav}>
                <NavLink
                 activeClassName="active"
                  className="ms-3 w500 textGray textPrimeHover linkNone"
                  to="recruiter"
                >
                  Recruiters
                </NavLink>
              </Nav.Link>
              <Nav.Link onClick={closeNav}>
                <NavLink
                 activeClassName="active"
                  className="ms-3 w500 textGray textPrimeHover linkNone"
                  to="jobseeker"
                >
                  Job Seekers
                </NavLink>
              </Nav.Link>
              <Nav.Link
                onClick={() => {
                  setShow(true);
                  closeNav()
                }}
                className="ms-3 w500 textGray textPrimeHover"
                activeClassName="active"
              >
                Download App
              </Nav.Link>
              <Nav.Link className="ms-3 d-block d-lg-none w500 textGray textPrimeHover" onClick={closeNav}>
                <NavLink className="linkNone textGray" to="about"  activeClassName="active">
                  About us
                </NavLink>
              </Nav.Link>
              <Nav.Link className="ms-3 d-block d-lg-none w500 textGray textPrimeHover" onClick={closeNav}>
                Blog
              </Nav.Link>
            </Nav>
            <NavDropdown
            onClick={closeNav}
              className="ms-3 d-none d-lg-block"
              title={
                <>
                  <button className="font26 borderNone bgNone mx-3 textGray textPrimeHover">
                    &#9776;
                  </button>
                </>
              }
              id="basic-nav-dropdown"
            >
              <NavDropdown.Item
                href="#action/3.1"
                className="bgWhite w500 textGray"
              >
                <NavLink to="about" className="linkNone textGray"  activeClassName="active" onClick={closeNav}>
                  About us
                </NavLink>
              </NavDropdown.Item>
              <NavDropdown.Item
              onClick={closeNav}
                href="#action/3.1"
                className="bgWhite w500 textGray"
              >
                <NavLink to="" className="linkNone textGray"  activeClassName="active" onClick={closeNav}>
                Blog
                </NavLink>
              </NavDropdown.Item>
            </NavDropdown>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <DownloadModal show={show} setShow={setShow} />
    </>
  );
};

export default NavigationBar;

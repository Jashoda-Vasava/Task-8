import React from "react";
import "./pricingPlanCard.css";

const PricingPlanCard = (props) => {
  
  return (
    <div className="planContainer">
      <div className="planName text-start bgPrime">
        <p className="mb-0 w700 ms-4 textGray">{props.planname}</p>
        <h2 className="mb-0 w700 ms-4 textWhite">
          ${props.price} <span className="font16">{props.day} days</span>
        </h2>
      </div>
      <div className="featuresContainer text-start mb-3">
        <p className="ms-4 textGray w600">&#11201; {props?.feature1}</p>
      </div>
    </div>
  );
};

export default PricingPlanCard;

import React from "react";
import "../../Common/common.css";
import "./postedjobsrt.css";

export default function Postedjobsrt(props) {
  return (
    <>
      <div className="jobcardMainContainer w-100 bgWhite p-3">
        <div className="d-flex justify-content-between mt-2">
          <div>
            <b className="font18 textGray">{props.name} </b>
            <p className="text-secondary w500">{props.companyName} </p>
          </div>
          <div className="text-end">
            <h3 className="font20 textPrime2 w600 pb-2">{props.salary}</h3>
            <span
              style={{ display: props.noOfApplication }}
              className="textWhite ms-2 bgPrime w600 applicantNumber"
            >
              {props.applicantsNumber}
            </span>
          </div>
        </div>
        <div className="row" style={{ display: props.metadata }}>
          <div className="col-sm-6">
            <p className="text12 textPrime2 w600 mb-0">Education</p>
            <p className="w600 textLightGray">{props.education}</p>
          </div>
          <div className="col-sm-6">
            <p className="text12 textPrime2 w600 mb-0">Location</p>
            <p className="w600 textLightGray">
              <span className="font14">{props.location}</span>
            </p>
          </div>
          <div className="col-sm-6">
            <p className="text12 textPrime2 w600 mb-0">Experience</p>
            <p className="w600 textLightGray">{props.experience}</p>
          </div>
        </div>
      </div>
    </>
  );
}

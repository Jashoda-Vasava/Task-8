import React from "react";
import "../../Common/common.css";
import "./jobcardjsd.css";
import { AiTwotoneHeart } from "react-icons/ai";

const JobCardJSD = (props) => {
  return (
    <>
      <div className="jobcardMainContainer w-100 bgWhite p-3">
        <div className="d-flex justify-content-between">
          <div>
            <b className="font18 textGray">Opration Executive</b>
            <p className="text-secondary w500">{props?.companyName}</p>
          </div>
          <div >
            <AiTwotoneHeart className={props?.Icons} onClick={props.hendleChangeLike}  />
          </div>
        </div>
        <div className="row">
          <div className="col-sm-6">
            <p className="text12 textPrime2 w600 mb-0">Education</p>
            <p className="w600 textLightGray">{props.education}</p>
          </div>
          <div className="col-sm-6">
            <p className="text12 textPrime2 w600 mb-0">Location</p>
            <p className="w600 textLightGray">
              {props.city}<span className="font14"> , {props.state}</span>
            </p>
          </div>
          <div className="col-sm-6">
            <p className="text12 textPrime2 w600 mb-0">Posted by</p>
            <p className="w600 textLightGray">
           {props.firstName} <span className="font14">{props.lastName}</span>
            </p>
          </div>
          <div className="col-sm-6">
            <p className="text12 textPrime2 w600 mb-0">Experience</p>
            <p className="w600 textLightGray">{props?.experience}</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default JobCardJSD;

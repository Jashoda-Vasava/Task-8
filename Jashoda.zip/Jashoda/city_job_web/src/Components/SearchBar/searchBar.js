import { React, useState } from "react";
import "./searchBar.css";
import { FaSearch } from "react-icons/fa";
import Input from "../Input/input";
import DownloadModal from "../DownloadModal/downloadModal";

const SearchBar = () => {
  const [show, setShow] = useState(false);
  return (
    <div>
      <div className="inputWrap2">
        <input
          type="text"
          placeholder="Enter Skills"
          className="borderNone outlineNone"
        />
        <input
          type="text"
          placeholder="Hiring Location"
          className="borderNone outlineNone"
        />
        <button
          onClick={() => {
            setShow(true);
          }}
          className="heroscetionSearchBtn fullRadious borderNone bgPrime textWhite"
        >
          <FaSearch />
        </button>
      </div>
      <div className="inputWrap3 bgWhite">
        <Input placeHolder="Skills"></Input>
        <Input placeHolder="Location"></Input>
        <button
          onClick={() => {
            setShow(true);
          }}
          className="w-100 bgPrime textWhite borderNone outlineNone py-2 mobileSearchBtn"
        >
          Search
        </button>
      </div>
      <DownloadModal show={show} setShow={setShow} />
    </div>
  );
};

export default SearchBar;

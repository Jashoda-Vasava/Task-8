/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable array-callback-return */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import { Container, Pagination, Row } from "react-bootstrap";
import Sidebarrt from "../../Components/SidebarRT/sidebarrt";
import Postedjobsrt from "../../Components/PostedJobsRT/postedjobsrt";
import { Link, useNavigate } from "react-router-dom";
import "./rtalljobs.css";
import { GoSearch } from "react-icons/go";
import swal from "sweetalert";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import { useSelector } from "react-redux";

export default function RtAllJobs() {
  const [recruitmentData, setRecruitmentData] = useState([]);
  const [searchField, setSearchField] = useState("");
  const [status, setStatus] = useState([]);
  const [allJobData, setAllJobData] = useState([]);
  const [page, setPage] = useState(1);
  const [pageCount, setPageCount] = useState(0);
  const user = useSelector((state) => state?.user);
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();
  useEffect(() => {
    getRecruitmentStatus();
  }, []);

  useEffect(() => {
    const pagedatacount = Math.ceil(status?.length / 6);
    setPageCount(pagedatacount);
    if (page) {
      const LIMIT = 6;
      const skip = LIMIT * page; // 5 *2 = 10
      const dataskip = status?.slice(page === 1 ? 0 : skip - LIMIT, skip);
      setAllJobData(dataskip);
    }
  }, [status, page]);

  /******************** API CALL START HERE **************************/
  const getRecruitmentStatus = () => {
    const body = {
      userid: user?.userid,
    };
    axiosInstance
      .post(`${Constants.GetRecruitmentStatus}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/rt_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setStatus(response.data.data);
          setRecruitmentData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/

  /**  HANDLE CHANGE FUNCTION  CALL **/
  const handalechange = (e) => {
    const value = e.target.value;
    setStatus(value);
    if (value === "ALL") {
      const allData = recruitmentData?.filter((item) => item);
      return setStatus(allData);
    } else if (value === "OPENING") {
      const allData = recruitmentData?.filter(
        (item) => item?.status === "OPENING"
      );
      return setStatus(allData);
    } else if (value === "CLOSED") {
      const allData = recruitmentData?.filter(
        (item) => item?.status === "CLOSED"
      );
      return setStatus(allData);
    } else if (value === "PENDING") {
      const allData = recruitmentData?.filter(
        (item) => item?.status === "PENDING"
      );
      return setStatus(allData);
    } else if (value === "REJETED") {
      const allData = recruitmentData?.filter(
        (item) => item?.status === "REJETED"
      );
      return setStatus(allData);
    }
  };

  /*** PAGINATION CODE FROM BOOTSTRAP ***/
  // HANDLE NEXT PAGE
  const handleNext = () => {
    if (page === pageCount) return page;
    setPage(page + 1);
  };

  /**  HANDLE PREVIOUS **/
  const handlePrevious = () => {
    if (page === 1) return page;
    setPage(page - 1);
  };
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div className="fixed">
              <Sidebarrt />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <h4 className="my-3 w700 textGray">Posted Jobs</h4>
                  <div className="d-flex justify-content-betweem">
                    <select
                      className="dropdownBorder w-auto px-2 py-2 borderNone mb-3"
                      onChange={handalechange}
                    >
                      <option value={"ALL"} selected>
                        All
                      </option>
                      <option value={"OPENING"}>Opening</option>
                      <option value={"CLOSED"}>Closed</option>
                      <option value={"PENDING"}>Panding</option>
                      <option value={"REJETED"}>Rejected</option>
                    </select>

                    <div className="searchContainer">
                      <input
                        type="text"
                        onChange={(e) => setSearchField(e.target.value)}
                        className="borderNone outlineNone bgWhite ps-2"
                        placeholder="Search..."
                      />
                      <GoSearch className="searchIcon" />
                    </div>
                  </div>
                  {allJobData?.length > 0 &&
                    allJobData
                      ?.filter((post) => {
                        if (searchField === "") {
                          return post;
                        } else if (
                          post?.functionalareaname
                            .toLowerCase()
                            .includes(searchField.toLowerCase()) ||
                          post?.location
                            .toLowerCase()
                            .includes(searchField.toLowerCase()) ||
                          post?.salary
                            .toLowerCase()
                            .includes(searchField.toLowerCase()) ||
                          post?.jobtypename
                            .toLowerCase()
                            .includes(searchField.toLowerCase()) ||
                          post?.education
                            .toLowerCase()
                            .includes(searchField.toLowerCase()) ||
                          post?.description
                            .toLowerCase()
                            .includes(searchField.toLowerCase()) ||
                          post?.requiredexperience
                            .toLowerCase()
                            .includes(searchField.toLowerCase())
                        ) {
                          return post;
                        }
                      })
                      ?.map((item, key) => (
                        <div className="col-md-6 mb-4" key={key}>
                          <Link
                            to={`/rt_alljobs/rt_candidatelist/${item?.postjobid}`}
                            className="linkNone"
                          >
                            <Postedjobsrt
                              companyName={item?.companyname}
                              applicantsNumber={item?.applaycount}
                              metadata="none"
                              noOfApplication=""
                              name={item?.functionalareaname}
                              salary={item?.salary}
                              education={item?.education}
                              location={item?.location}
                              experience={item?.requiredexperience}
                            />
                          </Link>
                        </div>
                      ))}
                </Row>
                <Row>
                  <div className="mt-4 ms-auto d-flex justify-content-end paginationBox">
                    <Pagination>
                      <Pagination.Prev
                        onClick={handlePrevious}
                        disabled={page === 1}
                      />
                      {Array(pageCount)
                        .fill(null)
                        .map((ele, index) => {
                          return (
                            <>
                              <Pagination.Item
                                active={page === index + 1 ? true : false}
                                onClick={() => setPage(index + 1)}
                              >
                                {index + 1}
                              </Pagination.Item>
                            </>
                          );
                        })}
                      <Pagination.Next
                        onClick={handleNext}
                        disabled={page === pageCount}
                      />
                    </Pagination>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
}

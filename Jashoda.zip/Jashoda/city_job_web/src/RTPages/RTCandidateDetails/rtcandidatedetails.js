/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-array-constructor */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./rtcandidatedetails.css";
import { Container, Row } from "react-bootstrap";
import Sidebarrt from "../../Components/SidebarRT/sidebarrt";
import { AiTwotoneHeart } from "react-icons/ai";
import swal from "sweetalert";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const Rtcandidatedetails = () => {
  const [jobWorkExperience, setJobWorkExperience] = useState([]);
  const [jobSeekerData, setJobSeekerData] = useState([]);
  var skillname = new Array();
  skillname = jobSeekerData?.map((item) => {
    return item.skillname?.split(",");
  });
  const { id } = useParams();
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();

  useEffect(() => {
    getJobSeekerWorkExperience();
    getJobSeekerData();
  }, []);

  /******************** API CALL START HERE **************************/
  const getJobSeekerWorkExperience = () => {
    const body = {
      userid: id,
      isactive: "Y",
    };
    axiosInstance
      .post(`${Constants.GetJobSeekerWorkExperience}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_SUCCESS) {
          setJobWorkExperience(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getJobSeekerData = () => {
    const body = {
      userid: id,
      postjobid: localStorage.getItem("postjobid"),
      isapply: "Y",
    };
    axiosInstance
      .post(`${Constants.GetJobSeekerData}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/rt_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setJobSeekerData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div className="fixed">
              <Sidebarrt />
            </div>
            {jobSeekerData?.map((item, key) => (
              <Container fluid className="mainPagesContainer" key={key}>
                <Container>
                  <Row>
                    <div className="col-12">
                      <div className="jobDetailsHeaderContainer bgWhite p-4 d-flex justify-content-between w-100">
                        <div className="d-flex">
                          <img
                            src={
                              item?.profileimage
                                ? item?.profileimage
                                : "/assets/images/defaultUser.png"
                            }
                            className="userImage rounded-circle"
                            alt=""
                          />
                          <div className="ms-4">
                            <h4 className="mb-0 w600 textPrime2">
                              {item?.firstname} {item?.lastname}
                            </h4>
                            <p className="mb-0 w500 text-secondary">
                              {item?.functionalareaname} |{" "}
                              {item?.totalexperience} |{item?.lastdegree}
                            </p>
                          </div>
                        </div>
                        <div>
                          <AiTwotoneHeart
                            className={
                              item.isfavouritebyrecruiter === "Y"
                                ? "font20 text-danger activeLink mx-3"
                                : "font20 textLightGray mx-3"
                            }
                          />
                        </div>
                      </div>
                    </div>
                  </Row>
                  <Row>
                    <p className="mt-4 mb-0 w600">About Me</p>
                    <p className="mt-1 text-secondary textJustify">
                      {item?.bio}
                    </p>
                  </Row>
                  <hr className="opacity50" />
                  <Row>
                    <div className="col-12">
                      <div className="d-flex mt-4">
                        <div className="me-5">
                          <p className="mb-0 textGray w600">Experiences</p>
                          <p className="mb-0 textPrime2 w600">
                            {item?.totalexperience}
                          </p>
                        </div>
                        <div className="me-5">
                          <p className="mb-0 textGray w600">Education</p>
                          <p className="mb-0 textPrime2 w600">
                            {item?.lastdegree}
                          </p>
                        </div>
                        <div className="me-5">
                          <p className="mb-0 textGray w600">Location</p>
                          <p className="mb-0 textPrime2 w600">
                            {item?.city} , {item?.state}
                          </p>
                        </div>
                      </div>
                    </div>
                  </Row>
                  <hr className="mt-4 opacity50" />
                  <Row>
                    <div className="col-md-6">
                      <p className="mt-4 w600">Job Preferences</p>
                      <p className="mt-4 w600 font18 textPrime2 mb-0">
                        {item?.functionalareaname}
                        <span className="w600 font14 textLightGray">
                          &nbsp; Information Technology
                        </span>
                      </p>
                      <p className="w600 font14 textLightGray">
                        In {item?.location}
                      </p>
                      <p className="w600 textLightGray">
                        {item?.jobtypename}
                        <span className="mt-4 w600 ms-2 textPrime2 mb-0">
                          Rs. {item?.expactedsalaryname}
                        </span>
                      </p>
                    </div>
                    <div className="col-md-6">
                      <p className="mt-4 w600">Skills</p>
                      {skillname?.map((item, key) =>
                        item.map((item) => (
                          <button
                            className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2"
                            key={key}
                          >
                            {item}
                          </button>
                        ))
                      )}
                    </div>
                  </Row>
                  <hr className="opacity50" />
                  <Row>
                    <div className="col-md-6">
                      <p className="mt-4 w600">Work Experiences</p>
                      {jobWorkExperience?.map((item, key) => (
                        <div key={key}>
                          <p className="mt-4 w600 font18 textPrime2 mb-0">
                            {item?.companyname}
                          </p>
                          <p className="w600 font14 textLightGray">
                            {item?.roleandresponsibilities}
                          </p>
                          <p className="w600 textLightGray">
                            {item?.designation}
                          </p>
                        </div>
                      ))}
                    </div>

                    <div className="col-md-6">
                      <p className="mt-4 w600">Education</p>
                      <div>
                        <p className="mt-4 w600 font18 textPrime2 mb-0">
                          {item?.lastdegree}
                        </p>
                        <p className="w600 font14 textLightGray">
                          Bachelor’s Degree
                        </p>
                      </div>
                    </div>
                  </Row>
                </Container>
              </Container>
            ))}
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Rtcandidatedetails;

/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import "./rtjobinfo.css";
import { Container, Row } from "react-bootstrap";
import Sidebarrt from "../../Components/SidebarRT/sidebarrt";
import swal from "sweetalert";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import { useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";

const Rtjobinfo = () => {
  const [postJobData, setPostJobData] = useState([]);
  const { id } = useParams();
  const Token = useSelector((state) => state?.token);
  const user = useSelector((state) => state?.user);
  const navigate = useNavigate();

  useEffect(() => {
    GetRecruitmentPostJob();
  }, []);

  /******************** API CALL START HERE **************************/
  const GetRecruitmentPostJob = () => {
    const body = {
      userid: user?.userid,
      postjobid: id,
      isactive: "Y",
    };
    axiosInstance
      .post(`${Constants.GetRecruitmentData}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/rt_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setPostJobData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div className="fixed">
              <Sidebarrt />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="jobDetailsHeaderContainer bgWhite p-4 d-flex justify-content-between w-100">
                      {postJobData?.map((item, key) => (
                        <div key={key}>
                          <h4 className="mb-0 w600">Operation Executive</h4>
                          <p className="mb-0 w500 text-secondary">
                            {item?.companyname}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </Row>
                {postJobData?.map((item, key) => (
                  <div key={key}>
                    <Row>
                      <p className="mt-4 mb-0 w600">Description</p>
                      <p className="mt-1 text-secondary textJustify">
                        {item?.description}
                      </p>
                    </Row>
                    <Row>
                      <div className="col-md-6">
                        <div className="d-flex mt-4">
                          <div className="me-5">
                            <p className="mb-0 textGray w600">Experiences</p>
                            <p className="mb-0 textPrime2 w600">
                              {item?.requiredexperience}
                            </p>
                          </div>
                          <div className="me-5">
                            <p className="mb-0 textGray w600">Education</p>
                            <p className="mb-0 textPrime2 w600">
                              {item?.education}
                            </p>
                          </div>
                          <div className="me-5">
                            <p className="mb-0 textGray w600">Location</p>
                            <p className="mb-0 textPrime2 w600">
                              {item?.location}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="col-md-6" key={key}>
                        <p className="mt-4 w600">Skills</p>
                        {item?.skillList?.map((item, key) => (
                          <button
                            className="jobdetails_skillBTN px-3 py-1 bgWhite me-2 mt-2"
                            key={key}
                          >
                            {item?.skillname}
                          </button>
                        ))}
                      </div>
                    </Row>
                  </div>
                ))}
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Rtjobinfo;

/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import "../../Common/common.css";
import { Container, Row } from "react-bootstrap";
import Sidebarrt from "../../Components/SidebarRT/sidebarrt";
import { BiCopy } from "react-icons/bi";
import CopyToClipboard from "react-copy-to-clipboard";
import swal from "sweetalert";
import "../../JSPages/JSShare/jsshare.css"
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const Rtshare = () => {
  const [text, setText] = useState("bit.ly.366swds/refrsfrind/cfke/c.com");
  const [isCopied, setIsCopied] = useState(false);
  const [socialIconData, setSocialIconData] = useState([]);
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();

  useEffect(() => {
    getJobSeekerSocialIcon();
  }, []);

  /******************** API CALL START HERE **************************/
  function getJobSeekerSocialIcon() {
    const body = {
      isactive: "Y",
      pageable: {
        pageno: 0,
        pagesize: 10,
      },
    };
    axiosInstance
      .post(`${Constants.GetRecruitmentSocialIcon}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/rt_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setSocialIconData(response.data.data);
        } else {
          swal(`${response.data.message}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response}`, "", "error"));
  }
  /******************** API CALL END HERE **************************/

  /** COPY LINK FUNCTION CALL **/
  const onCopyText = () => {
    setIsCopied(true);
    setTimeout(() => {
      setIsCopied(false);
    }, 1000);
  };

  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div className="fixed">
              <Sidebarrt />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-xl-8 col-md-12 mt-4">
                    <div className="shareMainBox w100 bgWhite p-3">
                      <div className="qrbox p-3">
                        <p className="text-center textGray w600">
                          Scan & Share
                        </p>
                        <img
                          src="/assets/images/qr.png"
                          className="qrImage"
                          alt=""
                        />
                      </div>
                      <div className="mx-auto p-3 text-center">
                        <p className="text-center textGray w600">
                          Share via app
                        </p>
                        <div className="d-flex socialIconBox">
                          {socialIconData?.map((item, key) => (
                            <Link to={item?.linkurl} key={key}>
                              <img
                                src={item?.imageurl}
                                alt=""
                                className="mx-2 imgIcon"
                              />
                            </Link>
                          ))}
                        </div>
                        <p className="text-center textGray w600 mt-4">
                          Or copy link below
                        </p>
                        <div className="d-flex linkShareBox text-center">
                          <input
                            type="text"
                            value={text}
                            onChange={(e) => setText(e.target.value)}
                            className="ms-3"
                          />
                          <CopyToClipboard text={text} onCopy={onCopyText}>
                            <button className="bgNone textPrime2 w600">
                              Copy <BiCopy />
                            </button>
                          </CopyToClipboard>
                          <span
                            className={`copy-feedback ${
                              isCopied ? "active" : ""
                            }`}
                          >
                            Copied!
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Rtshare;

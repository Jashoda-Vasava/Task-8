import { Navigate } from "react-router-dom";
import AppStore from "../../redux/store/store";
export { RTPublicRoute };

function RTPublicRoute({ children }) {
  const Token = AppStore.store.getState().token;
  if (Token) {
    return <Navigate to="/rt_login" />;
  }
  return children;
}

import React from "react";
import { Navigate } from "react-router-dom";
import AppStore from "../../redux/store/store";

const RTPrivateRoute = ({ children }) => {
  const Token = AppStore.store.getState().user;
  return Token ? children : <Navigate to="/rt_login" />;
};
export default RTPrivateRoute;

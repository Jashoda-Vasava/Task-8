/* eslint-disable react-hooks/exhaustive-deps */
import { React, useEffect, useState } from "react";
import "../../Common/common.css";
import { Link, useNavigate } from "react-router-dom";
import "./rthome.css";
import { Container, Pagination, Row } from "react-bootstrap";
import Sidebarrt from "../../Components/SidebarRT/sidebarrt";
import Slider from "react-slick";
import Postedjobsrt from "../../Components/PostedJobsRT/postedjobsrt";
import swal from "sweetalert";
import axiosInstance from "../../Api/commonUrl";
import * as Constants from "../../Common/Global/constants";
import { useSelector } from "react-redux";

const Rthome = () => {
  const [advertisementData, setadevertisementData] = useState([]);
  const [postJobData, setPostJobData] = useState([]);
  const [jobData, setJobData] = useState([]);
  const [page, setPage] = useState(1);
  const [pageCount, setPageCount] = useState(0);
  const user = useSelector((state) => state?.user);
  const Token = useSelector((state) => state?.token);
  const navigate = useNavigate();
  useEffect(() => {
    getRecruitmentAdvertisement();
    getRecruitmentPostJob();
  }, []);

  useEffect(() => {
    const pagedatacount = Math.ceil(postJobData?.length / 6);
    setPageCount(pagedatacount);
    if (page) {
      const LIMIT = 6;
      const skip = LIMIT * page; // 5 *2 = 10
      const dataskip = postJobData?.slice(page === 1 ? 0 : skip - LIMIT, skip);
      setJobData(dataskip);
    }
  }, [page, postJobData]);

  /******************** API CALL START HERE **************************/
  const getRecruitmentAdvertisement = () => {
    const body = {
      isactive: "Y",
      pageable: {
        pageno: 0,
        pagesize: 10,
      },
    };
    axiosInstance
      .post(`${Constants.GetRecruitmentAdvertisement}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/rt_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setadevertisementData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const getRecruitmentPostJob = () => {
    const body = {
      userid: user?.userid,
      isactive: "Y",
    };
    axiosInstance
      .post(`${Constants.GetRecruitmentData}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/rt_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setPostJobData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };
  /******************** API CALL END HERE **************************/

  /**  VIDIOS SLIDER **/
  const advertisementSlider = {
    infinite: advertisementData.length >= 3,
    arrows: advertisementData.length >= 3,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 1350,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1080,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  /*** PAGINATION CODE FROM BOOTSTRAP ***/
  // HANDLE NEXT PAGE
  const handleNext = () => {
    if (page === pageCount) return page;
    setPage(page + 1);
  };

  /**  HANDLE PREVIOUS **/
  const handlePrevious = () => {
    if (page === 1) return page;
    setPage(page - 1);
  };
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div className="fixed">
              <Sidebarrt />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-md-12">
                    <Slider
                      {...advertisementSlider}
                      className="imgTextComponenetSlider"
                    >
                      {advertisementData?.map((item, key) => (
                        <div className="col-md-4" key={key}>
                          <video
                            src={item?.videourl}
                            controls
                            loop
                            className="videodata"
                          ></video>
                        </div>
                      ))}
                    </Slider>
                  </div>
                </Row>
                <Row>
                  <p className="mt-4 mb-0 w600 textGray font18">
                    Job Posted By You
                  </p>
                  {jobData?.length > 0 &&
                    jobData?.map((item, key) => (
                      <div className="col-md-6 mt-4" key={key}>
                        <Link
                          to={`/rt_home/rt_jobinfo/${item?.postjobid}`}
                          className="linkNone"
                        >
                          <Postedjobsrt
                            key={key}
                            companyName={item?.companyname}
                            metadata=""
                            noOfApplication="none"
                            name={item?.functionalareaname}
                            salary={item?.salary}
                            education={item?.education}
                            location={item?.location}
                            experience={item?.requiredexperience}
                          />
                        </Link>
                      </div>
                    ))}
                </Row>
                <Row>
                  <div className="mt-4 ms-auto d-flex justify-content-end paginationBox">
                    <Pagination>
                      <Pagination.Prev
                        onClick={handlePrevious}
                        disabled={page === 1}
                      />
                      {Array(pageCount)
                        .fill(null)
                        .map((ele, index) => {
                          return (
                            <>
                              <Pagination.Item
                                active={page === index + 1 ? true : false}
                                onClick={() => setPage(index + 1)}
                              >
                                {index + 1}
                              </Pagination.Item>
                            </>
                          );
                        })}
                      <Pagination.Next
                        onClick={handleNext}
                        disabled={page === pageCount}
                      />
                    </Pagination>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Rthome;

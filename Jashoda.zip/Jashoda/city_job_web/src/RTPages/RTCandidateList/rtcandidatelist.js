/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable jsx-a11y/anchor-is-valid */
import { React, useEffect, useState } from "react";
import "../../Common/common.css";
import { Link, useNavigate, useParams } from "react-router-dom";
import "./rtcandidatelist.css";
import { Container, Row } from "react-bootstrap";
import Sidebarrt from "../../Components/SidebarRT/sidebarrt";
import Candidatecardrt from "../../Components/CandidateCardRT/candidatecardrt";
import swal from "sweetalert";
import * as Constants from "../../Common/Global/constants";
import axiosInstance from "../../Api/commonUrl";
import Pagination from "react-bootstrap/Pagination";
import { FaFilter } from "react-icons/fa";
import { useSelector } from "react-redux";

const Rtcandidatelist = (props) => {
  const [jobSeekerData, setJobSeekerData] = useState([]);
  const [functionalareaname, setFunctionalAreaName] = useState("");
  const [location, setLocation] = useState("");
  const [jobtypename, setJobtypename] = useState("");
  const [expactedindustryname, setExpactedIndustryName] = useState("");
  const [requiredexperience, setRequiredExperience] = useState("");
  const [jobSeekerList, setJobSeekerList] = useState([]);
  const [page, setPage] = useState(1);
  const [pageCount, setPageCount] = useState(0);
  const { id } = useParams();
  const Token = useSelector((state) => state?.token);
  localStorage.setItem("postjobid", id);
  const navigate = useNavigate();

  useEffect(() => {
    filteredData();
    getJobSeekerData();
  }, [
    functionalareaname,
    location,
    jobtypename,
    expactedindustryname,
    requiredexperience,
  ]);

  useEffect(() => {
    const pagedatacount = Math.ceil(jobSeekerData?.length / 6);
    setPageCount(pagedatacount);
    if (page) {
      const LIMIT = 6;
      const skip = LIMIT * page; // 5 *2 = 10
      const dataskip = jobSeekerData?.slice(
        page === 1 ? 0 : skip - LIMIT,
        skip
      );
      setJobSeekerList(dataskip);
    }
  }, [jobSeekerData, page]);

  /******************** API CALL START HERE **************************/
  const getJobSeekerData = () => {
    const body = {
      postjobid: id,
      isapply: "Y",
      filtertext: `functionalareaname like '%${functionalareaname}%' OR coursename like '%AWS%' OR upper(jobtypename) in ('PART TIME','FULL TIME') OR location like '%${location}%' OR expactedindustryname like '%${expactedindustryname}%' OR totalexperience like '%${requiredexperience}%'`,
    };
    axiosInstance
      .post(`${Constants.GetJobSeekerData}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/rt_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          setJobSeekerData(response.data.data);
        } else {
          swal(`${response.data.error}`, "", "error");
        }
      })
      .catch((error) => swal(`${error.response.data.error}`, "", "error"));
  };

  const saveJobSeekerFavouritePostJob = async (
    userid,
    isfavouritebyrecruiter
  ) => {
    const body = {
      isfavourite: isfavouritebyrecruiter === "N" ? "Y" : "N",
      jobseekeruserid: userid,
      postjobid: id,
    };
    return axiosInstance
      .post(`${Constants.SaveJobSeekerFavouritePostJob}`, body, {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${Token}`,
        },
      })
      .then((response) => {
        if (response.data.status === Constants.CODE_ACCESS_TOKEN_UNAUTHORIZED) {
          localStorage.clear();
          navigate("/rt_login");
        } else if (response.data.status === Constants.CODE_SUCCESS) {
          getJobSeekerData();
          return response.data.data;
        } else {
        }
      })
      .catch((error) => swal(`${error.response.data.massage}`, "", "error"));
  };

  /******************** API CALL END HERE **************************/

  /*** PAGINATION CODE FROM BOOTSTRAP ***/
  // HANDLE NEXT PAGE
  const handleNext = () => {
    if (page === pageCount) return page;
    setPage(page + 1);
  };

  // HANDLE PREVIOUS PAGE
  const handlePrevious = () => {
    if (page === 1) return page;
    setPage(page - 1);
  };

  //Filter Data
  const filteredData = () => {
    // Include all elements which includes the search query
    const data = jobSeekerData?.filter(
      (filter) =>
        filter?.functionalareaname
          ?.toLowerCase()
          ?.includes(functionalareaname?.toLowerCase()) ||
        filter?.location?.toLowerCase()?.includes(location?.toLowerCase()) ||
        filter?.jobtypename
          ?.toLowerCase()
          ?.includes(jobtypename?.toLowerCase()) ||
        filter?.expactedindustryname
          ?.toLowerCase()
          ?.includes(expactedindustryname?.toLowerCase()) ||
        filter?.requiredexperience
          ?.toLowerCase()
          ?.includes(requiredexperience?.toLowerCase())
    );
    setJobSeekerData(data);
    return data;
  };
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div className="fixed">
              <Sidebarrt />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="singleFilterItemBox bgWhite ms-3 pb-2">
                    <a className="linkNone w600 textPrime2 font14 py-2">
                      Functional Area
                    </a>
                    <input
                      type="text"
                      name="functionalareaname"
                      placeholder="eg. Java Developer"
                      value={functionalareaname}
                      onChange={(e) => setFunctionalAreaName(e.target.value)}
                      className="filterInput"
                    />
                  </div>
                  <div className="singleFilterItemBox bgWhite ms-3 pb-2">
                    <a className="linkNone w600 textPrime2 font14 py-2">
                      Location
                    </a>
                    <input
                      type="text"
                      placeholder="eg. Pune"
                      name="location"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="filterInput"
                    />
                  </div>
                  <div className="singleFilterItemBox bgWhite ms-3 pb-2">
                    <a className="linkNone w600 textPrime2 font14 py-2">
                      Job Type
                    </a>
                    <select
                      className="w-100 p-2 filterOutline outlineNone"
                      name="jobtypename"
                      onChange={(e) => setJobtypename(e.target.value)}
                      value={jobtypename}
                    >
                      <option selected={true} disabled="disabled" value={""}>
                        Select
                      </option>
                      <option value={"Full Time"}>Full Time</option>
                      <option value={"Part Time"}>Part Time</option>
                      <option value={"Contract"}>Contract</option>
                    </select>
                  </div>
                  <div className="singleFilterItemBox bgWhite ms-3 pb-2">
                    <a className="linkNone w600 textPrime2 font14 py-2">
                      Industry
                    </a>
                    <select
                      className="w-100 p-2 filterOutline outlineNone"
                      name="expactedindustryname"
                      onChange={(e) => setExpactedIndustryName(e.target.value)}
                      value={expactedindustryname}
                    >
                      <option selected="true" disabled="disabled" value={""}>
                        Select
                      </option>
                      <option value="Information Technology">
                        Information Technology
                      </option>
                      <option value="Marketing">Marketing</option>
                      <option value="Finance">Finance</option>
                    </select>
                  </div>
                  <div className="singleFilterItemBox bgWhite ms-3 pb-2">
                    <a className="linkNone w600 textPrime2 font14 mpy2">
                      Required Experience
                    </a>
                    <select
                      className="w-100 p-2 filterOutline outlineNone"
                      name="requiredexperience"
                      onChange={(e) => setRequiredExperience(e.target.value)}
                      value={requiredexperience}
                    >
                      <option selected="true" disabled="disabled" value={""}>
                        Select
                      </option>
                      <option value="1+ Year">Less than 1 Year</option>
                      <option value="2+ Year">1-3 Year</option>
                      <option value="3+ Year">3-5 Year</option>
                      <option value="5+ Year">5-10 Year</option>
                      <option value="10+ Year">10 Year +</option>
                    </select>
                  </div>
                  <div className="singleFilterItemBox2">
                    <button
                      className="mt-3 borderNone bgPrime2 textWhite p-2 px-3 filterButton"
                      onClick={(e) => filteredData(e)}
                    >
                      <FaFilter />
                    </button>
                  </div>
                </Row>
                <hr className="opacity50" />
                <Row>
                  {jobSeekerList?.length > 0 &&
                    jobSeekerList?.map((item, key) => (
                      <div className="col-md-6 mt-4" key={key}>
                        <Link
                          to={`/rt_alljobs/rt_candidatelist/rt_candidatedetails/${item?.userid}`}
                          className="linkNone"
                        >
                          <Candidatecardrt
                            key={item.userid}
                            profileimage={
                              item?.profileimage
                                ? item?.profileimage
                                : "/assets/images/defaultUser.png"
                            }
                            firstname={item?.firstname}
                            lastname={item?.lastname}
                            experience={item?.totalexperience}
                            salary={item?.expactedsalaryname}
                            education={item?.lastdegree}
                            educationYear={item?.lastdegreeyear}
                            Icons={
                              item.isfavouritebyrecruiter === "Y"
                                ? "font20 text-danger activeLink mx-3"
                                : "font20 textLightGray mx-3"
                            }
                            hendleChangeLike={(e) => {
                              saveJobSeekerFavouritePostJob(
                                item?.userid,
                                item.isfavouritebyrecruiter,
                                e.target
                              );
                            }}
                          />
                        </Link>
                      </div>
                    ))}
                </Row>
                <Row>
                  <div className="mt-4 ms-auto d-flex justify-content-end paginationBox">
                    <Pagination>
                      <Pagination.Prev
                        onClick={handlePrevious}
                        disabled={page === 1}
                      />
                      {Array(pageCount)
                        .fill(null)
                        .map((ele, index) => {
                          return (
                            <>
                              <Pagination.Item
                                active={page === index + 1 ? true : false}
                                onClick={() => setPage(index + 1)}
                              >
                                {index + 1}
                              </Pagination.Item>
                            </>
                          );
                        })}
                      <Pagination.Next
                        onClick={handleNext}
                        disabled={page === pageCount}
                      />
                    </Pagination>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Rtcandidatelist;

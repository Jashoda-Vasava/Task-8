import React from "react";
import "../../Common/common.css";
import "./rtmyaccount.css";
import { Container, Row } from "react-bootstrap";
import Sidebarrt from "../../Components/SidebarRT/sidebarrt";
import { Link } from "react-router-dom";
import MyaccountheaderRt from "../../Components/MyAccountHeaderRT/myaccountheaderrt";

const Rtmyaccount = () => {
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div className="fixed">
              <Sidebarrt />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <MyaccountheaderRt />
                  </div>
                  <div className="col-md-6 mt-4">
                    <div className="myAccountMenuSectionMain bgWhite p-1">
                      <div className="singleMenuItemBox px-4 py-3">
                        <img
                          src="/assets/images/greetings.png"
                          className="me-4"
                          alt=""
                        />
                        <Link
                          to="/rt_myaccount/rt_greetings"
                          className="mb-0 textLightGray w600 linkNone"
                        >
                          Greetings
                        </Link>
                      </div>
                      <div className="singleMenuItemBox px-4 py-3">
                        <img
                          src="/assets/images/contact.png"
                          className="me-4"
                          alt=""
                        />
                        <Link
                          to="/rt_myaccount/rt_contact"
                          className="mb-0 textLightGray w600 linkNone"
                        >
                          <p className="mb-0 textLightGray w600">Contact Us</p>
                        </Link>
                      </div>
                      <div className="singleMenuItemBox px-4 py-3">
                        <img
                          src="/assets/images/payment.png"
                          className="me-4"
                          alt=""
                        />
                        <Link
                          to="/rt_myaccount/rt_mypayment"
                          className="mb-0 textLightGray w600 linkNone"
                        >
                          <p className="mb-0 textLightGray w600">My Payments</p>
                        </Link>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6 mt-4">
                    <div className="myAccountMenuSectionMain bgWhite p-1">
                      <div className="singleMenuItemBox2 px-4 py-3">
                        <Link
                          to=" "
                          className="mb-0 textLightGray w600 linkNone"
                        >
                          My Chats
                        </Link>
                        <p className="mb-0 w600">4</p>
                      </div>
                      <div className="singleMenuItemBox2 px-4 py-3">
                        <Link
                          to=" "
                          className="mb-0 textLightGray w600 linkNone"
                        >
                          Interviews
                        </Link>
                        <p className="mb-0 w600">4</p>
                      </div>
                    </div>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Rtmyaccount;

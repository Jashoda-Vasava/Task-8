/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import "../../Common/common.css";
import { Container, Row } from "react-bootstrap";
import Sidebarrt from "../../Components/SidebarRT/sidebarrt";
import { Link } from "react-router-dom";
import MyaccountheaderRt from "../../Components/MyAccountHeaderRT/myaccountheaderrt";

const Rtgreetings = () => {
  return (
    <>
      <Container fluid>
        <Row>
          <div className="d-flex">
            <div className="fixed">
              <Sidebarrt />
            </div>
            <Container fluid className="mainPagesContainer">
              <Container>
                <Row>
                  <div className="col-12">
                    <div className="breadcrubsContainer bgWhite p-3">
                      <nav aria-label="breadcrumb">
                        <ol className="breadcrumb mb-0">
                          <li className="breadcrumb-item ">
                            <Link to="/rt_myaccount" className="linkNone textLightGray w600">
                              My Account
                            </Link>
                          </li>
                          <li className="breadcrumb-item">
                            <a href="#" className="linkNone textGray w600">
                              Greenings
                            </a>
                          </li>
                        </ol>
                      </nav>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="col-12 mt-4">
                    <MyaccountheaderRt />
                  </div>
                </Row>
                <Row>
                  <div className="col-12 mt-4">
                    <div className="greetingOptionContainer w-100 bgWhite p-4">
                      <div className="signleGreetingOptionbox py-3">
                        <input type="radio" id="1" name="Greetings" value=" " />
                        <label for="1" className="ms-3 w500 textLightGray">
                          Lorem Ipsum is simply dummy text of the printing and
                          typesetting industry. Lorem Ipsum has been the
                          industry"s
                        </label>
                        <br />
                      </div>
                      <div className="signleGreetingOptionbox py-3">
                        <input type="radio" id="1" name="Greetings" value=" " />
                        <label for="1" className="ms-3 w500 textLightGray">
                          Lorem Ipsum is simply dummy text of the printing and
                          typesetting industry. Lorem Ipsum has been the
                          industry's
                        </label>
                        <br />
                      </div>
                      <div className="signleGreetingOptionbox py-3">
                        <input type="radio" id="1" name="Greetings" value=" " />
                        <label for="1" className="ms-3 w500 textLightGray">
                          Lorem Ipsum is simply dummy text of the printing and
                          typesetting industry. Lorem Ipsum has been the
                          industry's
                        </label>
                        <br />
                      </div>
                      <div className="signleGreetingOptionbox py-3">
                        <input type="radio" id="1" name="Greetings" value=" " />
                        <label for="1" className="ms-3 w500 textLightGray">
                          Lorem Ipsum is simply dummy text of the printing and
                          typesetting industry. Lorem Ipsum has been the
                          industry's
                        </label>
                        <br />
                      </div>
                      <div className="signleGreetingOptionbox py-3">
                        <input type="radio" id="1" name="Greetings" value=" " />
                        <label for="1" className="ms-3 w500 textLightGray">
                          Lorem Ipsum is simply dummy text of the printing and
                          typesetting industry. Lorem Ipsum has been the
                          industry's
                        </label>
                        <br />
                      </div>
                      <div className="signleGreetingOptionbox py-3">
                        <input type="radio" id="1" name="Greetings" value=" " />
                        <label for="1" className="ms-3 w500 textLightGray">
                          Lorem Ipsum is simply dummy text of the printing and
                          typesetting industry. Lorem Ipsum has been the
                          industry's
                        </label>
                        <br />
                      </div>
                      <div className="signleGreetingOptionbox py-3">
                        <input type="radio" id="1" name="Greetings" value=" " />
                        <label for="1" className="ms-3 w500 textLightGray">
                          Lorem Ipsum is simply dummy text of the printing and
                          typesetting industry. Lorem Ipsum has been the
                          industry's
                        </label>
                        <br />
                      </div>
                    </div>
                  </div>
                </Row>
              </Container>
            </Container>
          </div>
        </Row>
      </Container>
    </>
  );
};
export default Rtgreetings;

import { Add } from "@mui/icons-material";
import RemoveIcon from "@mui/icons-material/Remove";
import { Button, ButtonGroup, Stack } from "@mui/material";
import React, { useReducer } from "react";
import reducer from "../../Api/context.js/reducer/reducer";

const initialValue=0;
const UseReducer = () => {
    const [count, dispatch] = useReducer(reducer, initialValue)
  return (
    <div>
      <Stack direction="row" justifyContent="center" alignItems="center">
        <ButtonGroup
          variant="contained"
          size="small"
          aria-label="outlined primary button group flex-end"
        >
          <Button variant="contained" size="small" sx={{ mx: "auto" }} onClick={() => dispatch({type:"INC"})}>
            <Add />
          </Button>
          <Button variant="text" size="small">
            {count}
          </Button>
          <Button variant="contained" size="small" onClick={() => dispatch({type:"DEC"})}>
            <RemoveIcon />
          </Button>
        </ButtonGroup>
      </Stack>
    </div>
  );
};

export default UseReducer;

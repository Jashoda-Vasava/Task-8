/* eslint-disable jsx-a11y/alt-text */
import React, { useEffect } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Button, ButtonGroup, Stack, Typography } from "@mui/material";
import { Add } from "@material-ui/icons";
import RemoveIcon from "@mui/icons-material/Remove";
import "./style.css";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import KeyboardBackspaceIcon from "@mui/icons-material/KeyboardBackspace";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import {
  addToCart,
  decreaseCart,
  getTotals,
  removeFromCart,
} from "../../Redux/cartSlice";

const Carts = () => {
  const cart = useSelector((state) => state?.cart);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getTotals());
  }, [cart, dispatch]);

  const handleAddToCart = (product) => {
    dispatch(addToCart(product));
  };
  const handleDecreaseCart = (product) => {
    dispatch(decreaseCart(product));
  };
  const handleRemoveFromCart = (product) => {
    dispatch(removeFromCart(product));
  };

  console.log(cart, "cart");

  function ccyFormat(num) {
    return `${num.toFixed(2)}`;
  }

  return (
    <>
      <Stack
        direction="column"
        justifyContent="center"
        alignItems="center"
        spacing={1}
      >
        <Typography variant="h4" component="h4">
          Shopping Cart{" "}
        </Typography>
        {cart?.cartItem.length === 0 ? (
          <>
            <Typography variant="h5" component="h5">
              Your cart is currently empty{" "}
            </Typography>
            <Link to="/product">
              <Stack
                direction="row"
                justifyContent="center"
                alignItems="center"
                spacing={1}
              >
                <KeyboardBackspaceIcon />
                <Typography>Start Shopping</Typography>
              </Stack>
            </Link>
          </>
        ) : (
          <TableContainer component={Paper} sx={{ overflow: "auto" }}>
            <Table
              sx={{ minWidth: 500, display: "table", tableLayout: "fixed" }}
              aria-label="spanning table"
            >
              <TableHead>
                <TableRow>
                  <TableCell align="center" colSpan={3}>
                    Details
                  </TableCell>
                  <TableCell align="right">Price</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell align="center">Images</TableCell>
                  <TableCell align="center">Desc</TableCell>
                  <TableCell align="center">Qty.</TableCell>
                  {/* <TableCell align="center">Action</TableCell> */}
                  <TableCell align="right">Total</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {cart?.cartItem &&
                  cart?.cartItem?.map((row) => (
                    <>
                      <TableRow key={row.desc}>
                        <TableCell align="center">
                          <img src={row.img} alt width="100" />
                        </TableCell>
                        <TableCell align="center">
                          <Typography>
                          {row.title}
                          </Typography>
                        <Button
                            variant="contained"
                            size="small"
                            onClick={() => handleRemoveFromCart(row)}
                          >
                            <DeleteOutlineIcon /> Remove
                          </Button>
                        </TableCell>
                        <TableCell align="center">
                 
                          <ButtonGroup
                            variant="contained"
                            size="small"
                            aria-label="outlined primary button group flex-end"
                          >
                            <Button
                              variant="contained"
                              size="small"
                              onClick={() => handleAddToCart(row)}
                            >
                              <Add />
                            </Button>
                            <Button variant="text" size="small">
                              {row.cartQuantity}
                            </Button>
                            <Button
                              variant="contained"
                              size="small"
                              onClick={() => handleDecreaseCart(row)}
                            >
                              <RemoveIcon />
                            </Button>
                          </ButtonGroup>
                        </TableCell>
                        {/* <TableCell align="center">
                          <Button
                            variant="contained"
                            size="small"
                            onClick={() => handleRemoveFromCart(row)}
                          >
                            <DeleteOutlineIcon /> Remove
                          </Button>
                        </TableCell> */}
                        <TableCell align="right">
                          ₹ {ccyFormat(row.price)}
                        </TableCell>
                      </TableRow>
                    </>
                  ))}

                <TableRow>
                  <TableCell rowSpan={0} />
                  <TableCell rowSpan={0} />
                  
                  <TableCell align="center" sx={{ fontSize: "25px" }}>
                    Subtotal
                  </TableCell>
                  <TableCell align="right" sx={{ fontSize: "25px" }}>
                    ₹ {cart?.cartAmount}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Stack>
    </>
  );
};

export default Carts;

import React from "react";
import Cards from "../../Components/Cards/Cards";
import { Grid } from "@mui/material";
import { product } from "../../Api/fackeApi";
import AddIcon from "@mui/icons-material/Add";
import Viewmodel from "./viewmodel";
import { useDispatch } from "react-redux";
import { addToCart } from "../../Redux/cartSlice";
const Product = () => {
  const dispatch=useDispatch();
  const handleAddToCart=(item)=>{
    dispatch(addToCart(item))
  }
  return (
    <div>
      <Grid container spacing={2}>
        {product?.map((item, key) => (
          <Grid item xs={12} md={6} lg={3} key={key}>
            <Cards
              title={item?.title}
              img={item?.img}
              description={item?.text}
              price={item?.price}
              rate={item?.rating?.rate}
              button
              icon={<AddIcon  />}
              onClick={()=>handleAddToCart(item)}
              view={<Viewmodel item={item} />}
              name="Add to Cart"
              number="1"
            />
          
          </Grid>
        ))}
      </Grid>
  
    </div>
  );
};

export default Product;

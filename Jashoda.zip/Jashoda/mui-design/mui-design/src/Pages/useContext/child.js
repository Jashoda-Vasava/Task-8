import { Card, Stack, Typography } from "@mui/material";
import React, { useContext } from "react";
import { AppContext } from "../../Api/context.js/useContext";

const Child = () => {
  const userData = useContext(AppContext);
  return (
    <div>
      <Stack direction="row" justifyContent="center" alignItems="center">
        <Card
          variant="none"
          sx={{
            maxWidth: 300,
            mx: "auto",
            fontSize: 300,
            p: 1,
            fontWeight: 500,
          }}
        >
          <Typography level="h1" sx={{ fontWeight: 500 }}>
            Name: {userData?.name}
          </Typography>
          <Typography
            level="h2"
            fontSize="xl"
            sx={{ mb: 0.5, fontWeight: 500 }}
          >
            Age:{userData?.age}
          </Typography>
        </Card>
      </Stack>
    </div>
  );
};

export default Child;

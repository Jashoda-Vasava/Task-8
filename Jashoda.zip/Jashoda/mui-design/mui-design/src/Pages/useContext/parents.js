import React from 'react'
import Child from './child'

const Parents = () => {
  return (
    <div>
        <Child/>
    </div>
  )
}

export default Parents
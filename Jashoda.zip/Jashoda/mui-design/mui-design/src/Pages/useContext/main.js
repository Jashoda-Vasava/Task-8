import React from "react";
import Parents from "./parents";
import UseReducer from "../useReducer/useReducer";
import UseRef from "../useRef/useRef";
import { Stack } from "@mui/material";

const Main = () => {
  return (
    <div>
      <Stack
        direction="column"
        justifyContent="center"
        alignItems="center"
        spacing={1}
      >
        <Parents />
        <UseReducer />
        <UseRef />
      </Stack>
    </div>
  );
};

export default Main;

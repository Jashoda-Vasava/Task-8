import { Grid } from "@mui/material";
import React from "react";
import Cards from "../../Components/Cards/Cards";
import CardImage from "../../Components/Cards/CardImage";

const About = () => {
  const cardData=[
    {
    title: "jasu",
    description: "haegjhfodjcvhvj",
    img:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbHUGyuJi8G--iVE8kwdiROukV1rPIZqq7QrktWLqtjQ&s"

  },
  {
    title: "jashoda",
    description: "haegjhfodjcvhvj",
    img:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbHUGyuJi8G--iVE8kwdiROukV1rPIZqq7QrktWLqtjQ&s"

  },
  {
    title: "Vasava",
    description: "haegjhfodjcvhvj",
    img:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbHUGyuJi8G--iVE8kwdiROukV1rPIZqq7QrktWLqtjQ&s"

  }
]
  return (
    <div>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <CardImage/>
        </Grid>
      {cardData?.map(item=>(
      <Grid  item xs={4}>
        <Cards title={item.title} description={item.description} img={item.img}/>
      </Grid>
      ))}
      </Grid>
    </div>
  );
};

export default About;

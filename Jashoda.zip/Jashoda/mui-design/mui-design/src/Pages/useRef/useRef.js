import { Button, Stack, Typography } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import Input from '@mui/base/Input';

const UseRef = () => {
  const [inputdata, setInputData] = useState("");
  const count = useRef(0);
  const inputRef = useRef()
  
  useEffect(() => {
    count.current = count.current + 1;
  });
  const changeBorder=()=>{
    inputRef.current.focus();
    inputRef.current.style.backgroundColor ="aquamarine"
  };

  return (
    <div>
      <Stack
        direction="column"
        justifyContent="center"
        alignItems="center"
        spacing={1}
      >
        <Input
          disabled={false}
          placeholder=""
          name="inputData"
          value={inputdata}
          onChange={(e) => setInputData(e.target.value)}
        />
        <Typography>
          The number of items component renderr:{count.current}
        </Typography>
        <Input disabled={false} placeholder="" ref={inputRef} />
        <Button onClick={changeBorder}>Submit</Button>
      </Stack>
    </div>
  );
};

export default UseRef;

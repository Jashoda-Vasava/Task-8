import React from "react";
import Sidebar from "./SideBar";

export const userpages = [
  {
    name: "113 Posts",
  },
  {
    name: "141 Followers / 110 Following",
  },
  {
    path: "",
    name: "History",
  },
  {
    path: "/userbadge",
    name: "Badge",
  },
  {
    path: "",
    name: "Resume",
  },
  {
    path: "/userbio",
    name: "Bio",
  },
];
const AllPages = () => {
  return (
    <div>
      <Sidebar Search pages={userpages} />
    </div>
  );
};

export default AllPages;

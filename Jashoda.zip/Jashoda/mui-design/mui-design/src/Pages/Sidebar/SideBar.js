// import React from "react";
// import PropTypes from "prop-types";
// import Drawer from "@material-ui/core/Drawer";
// import Hidden from "@material-ui/core/Hidden";
// import IconButton from "@material-ui/core/IconButton";
// import List from "@material-ui/core/List";

// import MenuIcon from "@material-ui/icons/Menu";
// import CloseIcon from "@material-ui/icons/Close";

// import Typography from "@material-ui/core/Typography";
// import { makeStyles, useTheme } from "@material-ui/core/styles";
// import { useState } from "react";
// import DrawerHeader from "@mui/material/Drawer";
// import { FaRegUserCircle } from "react-icons/fa";
// import { BsBagX } from "react-icons/bs";
// import { NavLink } from "react-router-dom";
// import ListItemIcon from "@material-ui/core/ListItem";
// import { Grid, Box } from "@mui/material";
// import {
//   RiUserSearchLine,
//   RiHome5Line,
//   RiHashtag,
//   RiSettings3Line,
//   RiLogoutCircleRLine,
// } from "react-icons/ri";
// export const homepages = [
//   {
//     name: "All",
//   },
//   {
//     path: "/homedetection",
//     name: "Detection",
//   },
//   {
//     path: "/homerecheck",
//     name: "Rechecking",
//   },
//   {
//     name: "Report",
//   },
// ];

// export const settingpages = [
//   {
//     name: "Information",
//   },
//   {
//     path: "/settingaction",
//     name: "Action History",
//   },
//   {
//     path: "/settingbookmark",
//     name: "Bookmark",
//   },
//   {
//     name: "My Report",
//   },
// ];
// export const userpages = [
//   {
//     name: "113 Posts",
//   },
//   {
//     name: "141 Followers / 110 Following",
//   },
//   {
//     path: "",
//     name: "History",
//   },
//   {
//     path: "/userbadge",
//     name: "Badge",
//   },
//   {
//     path: "",
//     name: "Resume",
//   },
//   {
//     path: "/userbio",
//     name: "Bio",
//   },
// ];

// const drawerWidth = 120;
// const useStyles = makeStyles((theme) => ({
//   root: {
//     display: "flex",
//   },
//   drawer: {
//     [theme.breakpoints.up("sm")]: {
//       width: drawerWidth,
//       flexShrink: 0,
//     },
//   },
//   appBar: {
//     zIndex: theme.zIndex.drawer + 1,
//   },
//   menuButton: {
//     marginRight: theme.spacing(2),
//     [theme.breakpoints.up("sm")]: {
//       display: "none",
//     },
//   },
//   toolbar: theme.mixins.toolbar,
//   drawerPaper: {
//     width: drawerWidth,
//     boxShadow: "inset -2px -2px 19px rgba(0, 0, 0, 0.18)",
//     height: "85%",
//     borderRadius: "18px",
//     marginTop: "90px",
//     marginLeft: "30px",
//   },
//   content: {
//     flexGrow: 1,
//     padding: theme.spacing(3),
//   },
//   closeMenuButton: {
//     marginRight: "auto",
//     marginLeft: 0,
//   },
// }));

// const Sidebar = (props) => {
//   const [selected, setSelected] = useState(false);
//   const handleClick = (id) => {
//     setSelected(id !== selected ? id : "");
//   };
//   const classes = useStyles();
//   const theme = useTheme();

//   const menuItem = [
//     {
//       path: "/",
//       name: "Home",
//       navicon: <RiHome5Line />,
//     },
//     {
//       path: "/user",
//       name: "User",
//       navicon: <RiUserSearchLine />,
//     },
//     {
//       path: "/hashtag",
//       name: "Hashtag",
//       navicon: <RiHashtag />,
//     },
//     {
//       path: "/objection",
//       name: "Objection",
//       navicon: <BsBagX />,
//     },
//     {
//       path: "/setting",
//       name: "Settings",
//       navicon: <RiSettings3Line />,
//     },
//     {
//       path: "/admin",
//       name: "Admin",
//       navicon: <FaRegUserCircle />,
//     },
//     {},
//     {},
//     {},
//     {
//       path: "/logout",
//       name: "Log Out",
//       navicon: <RiLogoutCircleRLine />,
//     },
//   ];
//   const drawer = (
//     <div>
//       <List>
//         {menuItem?.map((item, index) => (
//           <NavLink
//             onClick={() => {
//               handleClick(index);
//             }}
//             className={`${
//               selected === index ? "sidebarmenuactive" : "sidebarmenu"
//             } `}
//             to={item?.path}
//           >
//             <List
//               style={{
//                 marginBottom: "8px",
//                 marginRight: "20px",
//                 marginLeft: "30px",
//               }}
//             >
//               <Grid container direction="column">
//                 <Grid>
//                   <ListItemIcon
//                     style={{
//                       justifyContent: "center",
//                       fontSize: "25px",
//                       color: selected === index ? "#0db3a5" : "black",
//                     }}
//                   >
//                     {item?.navicon}
//                   </ListItemIcon>
//                 </Grid>
//                 <Grid>
//                   <Typography
//                     variant="subtitle2"
//                     style={{
//                       textAlign: "center",
//                       fontWeight: "bold",
//                     }}
//                   >
//                     {item?.name}
//                   </Typography>
//                 </Grid>
//               </Grid>
//             </List>
//           </NavLink>
//         ))}
//       </List>
//     </div>
//   );
//   return (
//     <div>

//       <div className={classes.root}>
//         {/* <AppBar position="fixed" className={classes.appBar}> */}
//         <nav className={classes.drawer}>
//           {/* {The implementation can be swapped with js to avoid SEO duplication of links. /} */}
//           {/* <Hidden smUp implementation="css"> */}
//             <Drawer
//               variant="temporary"
//               anchor={theme.direction === "rtl" ? "right" : "left"}
//               open={props.mobileOpen}
//               onClose={props.handleDrawerToggle}
//               classes={{
//                 paper: classes.drawerPaper,
//               }}
//               ModalProps={{
//                 keepMounted: true, // Better open performance on mobile.
//               }}
//             >
//               <IconButton
//                 onClick={props.handleDrawerToggle}
//                 className={classes.closeMenuButton}
//               >
//                 <CloseIcon />
//               </IconButton>
//               {drawer}
//             </Drawer>
//           {/* </Hidden> */}
//           {/* <Hidden xsDown implementation="css"> */}
//             <Drawer
//               className={classes.drawer}
//               variant="permanent"
//               classes={{
//                 paper: classes.drawerPaper,
//               }}
//             >
//               <div className={classes.toolbar} />
//               {drawer}
//             </Drawer>
//           {/* </Hidden> */}
//         </nav>
//         <div className={classes.content}>
//           <div className={classes.toolbar} />
//           <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
//             <DrawerHeader />
//             {props?.children}
//           </Box>
//         </div>
//       </div>
//     </div>
//   );
// };
// Sidebar.propTypes = {
//   // Injected by the documentation to work in an iframe.
//   // You won't need it on your project.
//   container: PropTypes.object,
// };
// export default Sidebar;

import React, { useState } from "react";
import Box from "@mui/material/Box";

import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import CssBaseline from "@mui/material/CssBaseline";
import Typography from "@mui/material/Typography";

import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";

import ListItemIcon from "@mui/material/ListItemIcon";
import Badge from "@mui/material/Badge";

import { NavLink, useNavigate } from "react-router-dom";
import DrawerHeader from "@mui/material/Drawer";

import { IoIosNotificationsOutline } from "react-icons/io";
import AccountCircleOutlinedIcon from "@mui/icons-material/AccountCircleOutlined";
// import './style.css'
import {
  Button,
  Container,
  Drawer,
  Grid,
  Hidden,
  InputBase,
  Menu,
} from "@mui/material";
import { FaRegUserCircle } from "react-icons/fa";
import { BsBagX } from "react-icons/bs";
import {
  RiUserSearchLine,
  RiHome5Line,
  RiHashtag,
  RiSettings3Line,
  RiLogoutCircleRLine,
} from "react-icons/ri";
import { makeStyles } from "@material-ui/core/styles";
import { styled, useTheme } from "@mui/material/styles";
import CloseIcon from "@material-ui/icons/Close";
import SearchIcon from "@mui/icons-material/Search";

const drawerWidth = 120;

const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: "10px",
  border: "1px solid gray",
  marginRight: theme.spacing(3),
  marginLeft: 0,
  marginTop: "8px",
  height: "35px",
  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(6),
    width: "38%",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  position: "absolute",
  display: "flex",
  alignItems: "center",
}));
const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("md")]: {
      width: "20ch",
    },
  },
}));

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
  },
  drawer: {
    [theme.breakpoints.up("sm")]: {
      width: drawerWidth,
      flexShrink: 0,
    },
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
  },
  menuButton: {
    marginRight: theme.spacing(2),
    [theme.breakpoints.up("sm")]: {
      display: "none",
    },
  },
  toolbar: theme.mixins.toolbar,
  drawerPaper: {
    width: drawerWidth,
    boxShadow: "inset -2px -2px 19px rgba(0, 0, 0, 0.18)",
    height: "85%",
    borderRadius: "18px",
    marginTop: "90px",
    marginLeft: "30px",
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
  closeMenuButton: {
    marginRight: "auto",
    marginLeft: 0,
  },
}));

// const DrawerHeader = styled("div")(({ theme }) => ({
//   display: "flex",
//   alignItems: "center",
//   justifyContent: "flex-end",
//   padding: theme.spacing(0, 1),
//   // necessary for content to be below app bar
//   ...theme.mixins.toolbar,
// }));

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(["width", "margin"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const Sidebar = (props) => {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const navigate = useNavigate();
  const [selected, setSelected] = useState(false);
  const handleClick = (id) => {
    setSelected(id !== selected ? id : "");
  };
  const classes = useStyles();
  const [anchorElNav, setAnchorElNav] = React.useState(null);

  // const handleOpenNavMenu = (event) => {
  //   setAnchorElNav(event.currentTarget);
  // };
  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  const menuItem = [
    {
      path: "/",
      name: "Home",
      navicon: <RiHome5Line />,
    },
    {
      path: "/user",
      name: "User",
      navicon: <RiUserSearchLine />,
    },
    {
      path: "/hashtag",
      name: "Hashtag",
      navicon: <RiHashtag />,
    },
    {
      path: "/objection",
      name: "Objection",
      navicon: <BsBagX />,
    },
    {
      path: "/setting",
      name: "Settings",
      navicon: <RiSettings3Line />,
    },
    {
      path: "/admin",
      name: "Admin",
      navicon: <FaRegUserCircle />,
    },
    {},
    {},
    {},
    {
      path: "/logout",
      name: "Log Out",
      navicon: <RiLogoutCircleRLine />,
    },
  ];
  const drawer = (
    <div>
      <List>
        {menuItem?.map((item, index) => (
          <NavLink
            onClick={() => {
              handleClick(index);
            }}
            className={`${
              selected === index ? "sidebarmenuactive" : "sidebarmenu"
            } `}
            to={item?.path}
          >
            <List
              style={{
                marginBottom: "8px",
                marginRight: "20px",
                marginLeft: "30px",
              }}
            >
              <Grid container direction="column">
                <Grid>
                  <ListItemIcon
                    style={{
                      justifyContent: "center",
                      fontSize: "25px",
                      color: selected === index ? "#0db3a5" : "black",
                    }}
                  >
                    {item?.navicon}
                  </ListItemIcon>
                </Grid>
                <Grid>
                  <Typography
                    variant="subtitle2"
                    style={{
                      textAlign: "center",
                      fontWeight: "bold",
                    }}
                  >
                    {item?.name}
                  </Typography>
                </Grid>
              </Grid>
            </List>
          </NavLink>
        ))}
      </List>
    </div>
  );

  return (
    <div>
      <Box sx={{ display: "flex" }}>
        <CssBaseline />
        <AppBar position="static" open={open}>
          <Container maxWidth="xl">
            <Toolbar disableGutters>
              <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
                <IconButton
                  color="inherit"
                  aria-label="open drawer"
                  onClick={handleDrawerOpen}
                  edge="start"
                  sx={{
                    marginRight: 5,
                    ...(open && { display: "none" }),
                  }}
                >
                  <MenuIcon />
                </IconButton>
                <Menu
                  id="menu-appbar"
                  anchorEl={anchorElNav}
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "left",
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "left",
                  }}
                  open={Boolean(anchorElNav)}
                  onClose={handleCloseNavMenu}
                  sx={{
                    display: { xs: "block", md: "none" },
                  }}
                >
                  {props?.pages?.map((page, index) => (
                    <Button
                      buttonVariant="outlined"
                      key={index}
                      className={`${selected === index ? "buttonActive" : ""}`}
                      sx={{
                        px: 3,
                        boxShadow: "inset -9px -7px 19px rgba(0, 0, 0, 0.18)",
                        borderRadius: "10px",
                        color: "black",
                        marginLeft: "30px",
                        textTransform: "capitalize",
                        marginTop: "5px",
                        fontWeight: "bold",
                      }}
                      onClick={(e) => {
                        e.preventDefault();
                        handleClick(index);
                        navigate(page?.path);
                      }}
                    >
                      {page?.name}
                    </Button>
                  ))}
                </Menu>
              </Box>
              {/* <IconButton
            color="inherit"
            aria-label="Open drawer"
            aria-controls="menu-appbar"
            aria-haspopup="true"
            edge="start"
            onClick={handleDrawerOpen}
            className={classes.menuButton}
          >
            <MenuIcon />
          </IconButton> */}
              {props?.pages?.map((page, index) => (
                <Grid xs={2} sm={4} md={4} key={index}>
                  <Button
                    buttonVariant="outlined"
                    key={index}
                    className={`${selected === index ? "buttonActive" : ""}`}
                    sx={{
                      display: { xs: "none", md: "-ms-grid" },
                      px: 3,
                      boxShadow: "inset -9px -7px 19px rgba(0, 0, 0, 0.18)",
                      borderRadius: "10px",
                      color: "black",
                      marginLeft: "30px",
                      textTransform: "capitalize",
                      marginTop: "5px",
                      fontWeight: "bold",
                    }}
                    onClick={(e) => {
                      e.preventDefault();
                      handleClick(index);
                      navigate(page?.path);
                    }}
                  >
                    {page?.name}
                  </Button>
                </Grid>
              ))}

              {props.Search && (
                <Search>
                  <SearchIconWrapper>
                    <SearchIcon />
                  </SearchIconWrapper>
                  <StyledInputBase
                    placeholder="Search…"
                    inputProps={{ "aria-label": "search" }}
                  />
                </Search>
              )}
              <Box sx={{ display: { xs: "none", md: "flex" } }}>
                <Badge
                  badgeContent={1}
                  sx={{
                    "& .MuiBadge-badge": {
                      backgroundColor: "#44C6BA",
                      fontSize: 9,
                      height: 15,
                      minWidth: 5,
                      mt: 2,
                      mr: 1,
                    },
                  }}
                >
                  <IoIosNotificationsOutline
                    style={{ color: "black", fontSize: "40px", marginTop: 7 }}
                  />
                </Badge>
                <IconButton>
                  <Badge
                    variant="dot"
                    sx={{
                      "& .MuiBadge-badge": {
                        right: 12,
                        top: 22,
                        background: "#00D100",
                      },
                    }}
                  >
                    <AccountCircleOutlinedIcon
                      style={{
                        color: "black",
                        height: "35px",
                        width: "50px",
                      }}
                    />
                  </Badge>
                </IconButton>
              </Box>
            </Toolbar>
          </Container>
        </AppBar>
      </Box>
      <div className={classes.root}>
        <nav className={classes.drawer}>
          {/* {The implementation can be swapped with js to avoid SEO duplication of links. /} */}
          <Hidden smUp implementation="css">
            <Drawer
              variant="temporary"
              anchor={theme.direction === "rtl" ? "right" : "left"}
              open={open}
              onClose={handleDrawerClose}
              classes={{
                paper: classes.drawerPaper,
              }}
              ModalProps={{
                keepMounted: true, // Better open performance on mobile.
              }}
            >
              <IconButton
                onClick={handleDrawerClose}
                className={classes.closeMenuButton}
              >
                <CloseIcon />
              </IconButton>
              {drawer}
            </Drawer>
          </Hidden>
          <Hidden xsDown implementation="css">
            <Drawer
              className={classes.drawer}
              variant="permanent"
              classes={{
                paper: classes.drawerPaper,
              }}
            >
              <div className={classes.toolbar} />
              {drawer}
            </Drawer>
          </Hidden>
        </nav>
        <div className={classes.content}>
          <div className={classes.toolbar} />
          <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
            <DrawerHeader />
            {props?.children}
          </Box>
        </div>
      </div>

      <div className={classes.content}>
        <div className={classes.toolbar} />
        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
          {props.children}
        </Box>
      </div>
    </div>
  );
};
export default Sidebar;

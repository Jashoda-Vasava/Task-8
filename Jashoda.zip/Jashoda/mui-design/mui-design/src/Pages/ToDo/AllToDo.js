import React from 'react'
import AddTodo from './addToDo'
import ListTodo from './toDo'
import './style.css'

const AllToDo = () => {
  return (
    <div>
    <AddTodo />
    <ListTodo />
  </div>
  )
}
export default AllToDo
import React from "react";
import Carousel from "react-material-ui-carousel";
import bg1 from "../../Components/Images/img1.png";
import bg2 from "../../Components/Images/img2.png";
import bg3 from "../../Components/Images/img3.png";
import bg4 from "../../Components/Images/img4.png";
import bg5 from "../../Components/Images/img5.png";
import { Container } from "@mui/material";
const bgImages = [bg1, bg2, bg3, bg4, bg5];
const Carousels = () => {
  return (
    <Container maxWidth="lg">
      <Carousel
        autoPlay={false}
        indicators={false}
        className="home__carousel"
        navButtonsAlwaysVisible={true}
        navButtonsAlwaysInvisible={false}
      >
        {bgImages.map((item, i) => (
          <img
            key={i}
            src={item}
            alt={`Amazon Background ${i}`}
            className="home__image"
          />
        ))}
      </Carousel>
    </Container>
  );
};

export default Carousels;

import { Button } from "@mui/material";
import React from "react";

const Buttons = () => {
  return (
    <div style={{ marginTop:5 }}>
      <Button variant="text">Text</Button>&nbsp;&nbsp;
      <Button variant="contained">Contained</Button>&nbsp;&nbsp;
      <Button variant="outlined">Outlined</Button>
    </div>
  );
};

export default Buttons;

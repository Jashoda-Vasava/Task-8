import * as React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import {
  Button,
  ButtonGroup,
  CardActionArea,
  CardActions,
  Rating,
  Stack,
} from "@mui/material";
import Title from "../Title/title";
import { Add } from "@material-ui/icons";
import RemoveIcon from "@mui/icons-material/Remove";

const Cards = (props) => {
  return (
    <Card sx={{ maxWidth: 345 }}>
      <CardActionArea>
        <CardMedia
          component="img"
          height="140"
          image={props.img}
          alt="green iguana"
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            <Title>{props.title} </Title>
            <Typography gutterBottom variant="h5" component="div">
              ₹ {props.price}
            </Typography>
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {props.description}
          </Typography>
          <Rating
            name="read-only"
            value={props.rate}
            precision={0.5}
            readOnly
          />
        </CardContent>
      </CardActionArea>
      <CardActions>
        {props.button && (
          <Stack
            direction={{ xs: "column", sm: "row" }}
            spacing={{ xs: 6, sm: 24, md: 16 }}
          >
            <Button variant="contained" size="small" startIcon={props.icon} onClick={props.onClick}>
              {props.name}
            </Button>
            <Button variant="contained" size="small">
              {props.view}
            </Button>
          </Stack>
        )}
        {props.group && (
          <ButtonGroup
            variant="contained"
            size="small"
            aria-label="outlined primary button group flex-end"
          >
            <Button variant="contained" size="small">
              <Add />
            </Button>
            <Button variant="text" size="small">
              {props.number}
            </Button>
            <Button variant="contained" size="small">
              <RemoveIcon />
            </Button>
          </ButtonGroup>
        )}
      </CardActions>
    </Card>
  );
};
export default Cards;

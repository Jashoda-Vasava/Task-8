import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter as Router } from "react-router-dom";
import store from './Redux/store';
import { Provider } from 'react-redux';
import { AuthProvider } from './Redux/redux';
import { AppProvider } from './Api/context.js/useContext';
import { getTotals } from './Redux/cartSlice';
// import { AuthProvider } from './Redux/redux';
// export const AuthContext = React.createContext()
store.dispatch(getTotals());
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
<AppProvider>
    <Provider store={store}>
    	<AuthProvider>
    <Router>
    <App />
    </Router>
    </AuthProvider>
    </Provider>
    </AppProvider>
 
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

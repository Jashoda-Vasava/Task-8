import "./App.css";
import 'react-toastify/dist/ReactToastify.css';
import Sidebar from "./Components/SideBar/sidebar";
import { Routes, Route, Outlet } from "react-router-dom";
import Home from "./Pages/Home/home";
import About from "./Pages/About/about";
import Product from "./Pages/Product/product";
import Login from "./Pages/Login/login";
import AllToDo from "./Pages/ToDo/AllToDo";
import Carts from "./Pages/Product/carts";
import Main from "./Pages/useContext/main";
import {ToastContainer} from "react-toastify"


const AppOutLet = () => {
  return (
    <Sidebar>
      <Outlet></Outlet>
    </Sidebar>
  );
};
function App() {
  return (
    <div>
      {/* <Sidebar/> */}
      <ToastContainer/>
      <Routes>
      <Route path="/login" element={<Login />} />
        <Route path="/" element={<AppOutLet />}>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/product" element={<Product />} />
          <Route path="/allTodo" element={<AllToDo />} />
          <Route path="/cart"  element={<Carts />} />
          <Route path="/main"  element={<Main />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;

export const socialicons = [
  { text: "Twitter", icon: "fab fa-twitter", link: "" },
  {
    text: "Facebook",
    icon: "fab fa-facebook",
    link: "https://www.facebook.com/joshua13j/",
  },
  {
    text: "Instagram",
    icon: "fab fa-instagram",
    link: "https://www.instagram.com/joshua_bitton13/",
  },
  { text: "Pinterest", icon: "fab fa-pinterest" },
  { text: "YouTube", icon: "fab fa-youtube" },
];

export const profile = [
  {
    title: "Profile",
    img: "https://i.imgur.com/EMcyIBn.png",
    text: "Extremely motivated to constantly develop my skills and grow professionally. I am confident in my ability to come up with new ideas and enhance  my UI and UX skills.",
    icon: "paint-brush",
  },
  {
    title: "Quotes",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed convallis ante nec imperdiet venenatis. Aenean sed consectetur enim. Donec pretium erat ut varius varius.",
    icon: "quote-left",
    img: "https://i.imgur.com/PldPiNS.png",
  },
  {
    title: "Inspiration",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed convallis ante nec imperdiet venenatis. Aenean sed consectetur enim. Donec pretium erat ut varius varius.",
    img: "https://i.imgur.com/ih8gwVB.png",
    icon: "lightbulb",
  },
];

export const style = {
  NotificationItem: {
    DefaultStyle: {
      backgroundColor: "#fff",
      borderRadius: "10px",
      border: "solid 1px rgb(0, 0,0,0)",
      boxShadow: "var(--light-shadow)",
      height: "45px",
      display: "flex",
      alignItems: "center",
    },
    warning: {},
  },
};

export const contactinputs = [
  {
    text: "Full Name",
    value: "name",
    name: "from_name",
  },
  {
    text: "Email",
    value: "email",
    name: "from_email",
  },
  {
    text: "Message",
    value: "msg",
    textarea: true,
    name: "message",
  },
];

export const product = [
  {
    id:1,
    title: "hdhdkfdf",
    img: "http://surl.li/hcadw",
    price:1000,
    rating:{rate:5,count:120},
    text: "Extremely motivated to constantly develop my skills and grow professionally. I am confident in my ability to come up with new ideas and enhance  my UI and UX skills.",
    icon: "paint-brush",
  },
  {
    id:2,
    title: "dfdhjjdfk",
    img: "http://surl.li/hcagp",
    price:1200,
    rating:{rate:4.5,count:120},
    text: "Extremely motivated to constantly develop my skills and grow professionally. I am confident in my ability to come up with new ideas and enhance  my UI and UX skills.",
    icon: "paint-brush",
  },
  {
    id:3,
    title: "fdfkdjffkdf",
    img: "http://surl.li/hcadw",
    price:900,
    rating:{rate:4,count:120},
    text: "Extremely motivated to constantly develop my skills and grow professionally. I am confident in my ability to come up with new ideas and enhance  my UI and UX skills.",
    icon: "paint-brush",
  },
  {
    id:4,
    title: "shdjhfj",
    img:"http://surl.li/hcagp",
    price:700,
    rating:{rate:3,count:120},
    text: "Extremely motivated to constantly develop my skills and grow professionally. I am confident in my ability to come up with new ideas and enhance  my UI and UX skills.",
    icon: "paint-brush",
  },
  {
    id:5,
    title: "fsgd",
    img: "http://surl.li/hcadw",
    price:600,
    rating:{rate:3,count:120},
    text: "Extremely motivated to constantly develop my skills and grow professionally. I am confident in my ability to come up with new ideas and enhance  my UI and UX skills.",
    icon: "paint-brush",
  },
  {
    id:6,
    title: "dfhdddf",
    img:"http://surl.li/hcagp",
    price:800,
    rating:{rate:4,count:120},
    text: "Extremely motivated to constantly develop my skills and grow professionally. I am confident in my ability to come up with new ideas and enhance  my UI and UX skills.",
    icon: "paint-brush",
  },
  {
    id:7,
    title: "fgdffg",
    img: "http://surl.li/hcadw",
    price:700,
    rating:{rate:3.9,count:120},
    text: "Extremely motivated to constantly develop my skills and grow professionally. I am confident in my ability to come up with new ideas and enhance  my UI and UX skills.",
    icon: "paint-brush",
  },
  {
    id:8,
    title: "gfghghg",
    img:"http://surl.li/hcagp",
    price:300,
    rating:{rate:2,count:120},
    text: "Extremely motivated to constantly develop my skills and grow professionally. I am confident in my ability to come up with new ideas and enhance  my UI and UX skills.",
    icon: "paint-brush",
  },
  {
    id:9,
    title: "jfhfj",
    img: "http://surl.li/hcadw",
    price:500,
    rating:{rate:3.5,count:120},
    text: "Extremely motivated to constantly develop my skills and grow professionally. I am confident in my ability to come up with new ideas and enhance  my UI and UX skills.",
    icon: "paint-brush",
  },
];

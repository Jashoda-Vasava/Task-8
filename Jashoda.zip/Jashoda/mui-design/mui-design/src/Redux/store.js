import { configureStore } from '@reduxjs/toolkit';
import toDoReducer from './reduxSlice';
import cartReducer from "./cartSlice"

export default configureStore({
    reducer: {toDo: toDoReducer,cart:cartReducer}
  })
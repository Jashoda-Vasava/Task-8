import axios from "axios";

const ROOT_URL = 'http://localhost:3004/login';
export async function loginUser(dispatch, loginPayload) {
	try {
		dispatch({ type: 'REQUEST_LOGIN' });
		let response = await axios.post(`${ROOT_URL}`,loginPayload,{ headers: { 'Content-Type': 'application/json' ,dataType: 'json'}})
		   
		if (response) {
			dispatch({ type: 'LOGIN_SUCCESS', payload: response?.data });
			localStorage.setItem('currentUser', JSON.stringify(response?.data));
			return response;
		}
		dispatch({ type: 'LOGIN_ERROR', error: response?.message });
		return;
	} catch (error) {
		dispatch({ type: 'LOGIN_ERROR', error: error?.message });
		console.log(error);
	}
}

export async function logout(dispatch) {
	dispatch({ type: 'LOGOUT' });
	localStorage.removeItem('currentUser');
	localStorage.removeItem('token');
}
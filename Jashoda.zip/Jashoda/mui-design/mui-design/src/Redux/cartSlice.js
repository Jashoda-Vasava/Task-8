import { createSlice } from "@reduxjs/toolkit";
import {toast} from "react-toastify"

export const CartSlice = createSlice({
  name: "toDo",
  initialState: {
    cartItem: localStorage.getItem("cartItem")? JSON.parse(localStorage.getItem("cartItem")):[],
    cartQty: 0,
    cartAmount: 0,
  },
  reducers: {
    addToCart: (state, action) => {
      const itemIndex = state.cartItem.findIndex(
        (item) => item.id === action.payload.id
      );
      if(itemIndex>=0){
        state.cartItem[itemIndex].cartQuantity +=1
        toast.info(`increased ${state.cartItem[itemIndex].title} cart quantity`,{
            position:"top-right"
        })
      }else{
        const carts = { ...action.payload, cartQuantity: 1 };
        state.cartItem.push(carts);
        toast.success(`${action.payload.title} added to cart `,{
            position:"top-right"
        })
      }
      localStorage.setItem("cartItem",JSON.stringify(state.cartItem));
    },
    decreaseCart(state, action) {
        const itemIndex = state.cartItem.findIndex(
          (item) => item.id === action.payload.id
        );
  
        if (state.cartItem[itemIndex].cartQuantity > 1) {
          state.cartItem[itemIndex].cartQuantity -= 1;
  
          toast.info(`Decreased  product quantity`, {
            position: "top-right",
          });
        } else if (state.cartItem[itemIndex].cartQuantity === 1) {
          const nextCartItems = state.cartItem.filter(
            (item) => item.id !== action.payload.id
          );
  
          state.cartItem = nextCartItems;
  
          toast.error("Product removed from cart", {
            position: "top-right",
          });
        }
  
        localStorage.setItem("cartItem", JSON.stringify(state.cartItem));
      },
      removeFromCart(state, action) {
        state.cartItem.map((cartItem) => {
          if (cartItem.id === action.payload.id) {
            const nextCartItems = state.cartItem.filter(
              (item) => item.id !== cartItem.id
            );
  
            state.cartItem = nextCartItems;
  
            toast.error("Product removed from cart", {
              position: "top-right",
            });
          }
          localStorage.setItem("cartItem", JSON.stringify(state.cartItem));
          return state;
        });
      },
      getTotals(state, action) {
        let { total, quantity } = state.cartItem.reduce(
          (cartTotal, cartItem) => {
            const { price, cartQuantity } = cartItem;
            const itemTotal = price * cartQuantity;
            cartTotal.total += itemTotal;
            cartTotal.quantity += cartQuantity;
            return cartTotal;
          },
          {
            total: 0,
            quantity: 0,
          }
        );
        state.cartQty=quantity
        state.cartAmount = total;
      },
  },
});
// Action creators are generated for each case reducer function
export const { addToCart, decreaseCart, removeFromCart, getTotals } = CartSlice.actions;
export default CartSlice.reducer;

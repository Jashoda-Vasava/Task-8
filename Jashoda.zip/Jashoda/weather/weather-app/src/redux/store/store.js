import { configureStore } from "@reduxjs/toolkit";
import weatherReducer from "../weatherSlice/weatherSlice";
import cityReducer from "../weatherSlice/citySlice";

export const store = configureStore({
  reducer: {
    weather: weatherReducer,
    city:cityReducer
  },
})
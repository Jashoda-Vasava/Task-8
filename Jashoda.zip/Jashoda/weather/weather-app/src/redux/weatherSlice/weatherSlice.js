import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
const initialState = {
  data: [],
  futureData: [],
  loading: false,
  hasError: false,
};

export const getDataAsync = (cityName) => async (dispatch) => {
  dispatch(getData());
  try {
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=f7e26c9b5f707d4e3025c5a884f8139b`
    );
    dispatch(getDataSuccess(response.data));
    toast.success("Data shows sucessfully",response.data.cod, {
      position: "top-right",
      autoClose: 500,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
      });
  } catch (error) {
    dispatch(getDataFailure(error));
    toast.error("Please enter city name",error.response.data.message, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
      });
  }
};
export const getFutureDataAsync = (cityName) => async (dispatch) => {
  dispatch(getData());
  try {
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=f7e26c9b5f707d4e3025c5a884f8139b`
    );
    dispatch(getDataSuccess(response.data));
  } catch (error) {
    dispatch(getDataFailure(error));
  }
};


export const weatherSlice=createSlice({
    name: "weather",
    initialState,
    reducers: {
      getData: (state) => {
        state.loading = true;
      },
      getDataSuccess: (state, action) => {
        console.log(action.payload);
        state.data = action.payload;
        state.loading = false;
        state.hasError = false;
      },
      getDataFailure: (state) => {
        state.loading = false;
        state.hasError = true;
      },
    },
  })
export const { getData, getDataSuccess, getDataFailure } = weatherSlice.actions;
export const selectData = (state) => state.weather;

export default weatherSlice.reducer;
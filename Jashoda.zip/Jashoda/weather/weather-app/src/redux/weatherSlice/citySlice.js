import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const initialState = {
  name: "",
  listCity: [],
};

export const getAutoComplName = (data) => async (dispatch) => {
  try {
    const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${data}&appid=f7e26c9b5f707d4e3025c5a884f8139b`       
    );
    dispatch(getAutoName(response.data));
    console.log(response.data);
  } catch (error) {
    console.log(error);
  }
};

export const citySlice = createSlice({
  name: "city",
  initialState,

  reducers: {
    getCityName: (state, action) => {
      state.name = action.payload;
    },

    getAutoName: (state, action) => {
      state.listCity = action.payload;
    },
  },
});

export const { getCityName, getAutoName } = citySlice.actions;
export const selectCount = (state) => state.city.value;

export default citySlice.reducer;

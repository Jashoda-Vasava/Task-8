import React, { useEffect } from 'react'
import './Weather.css'
import {useDispatch, useSelector} from 'react-redux'
import { getDataAsync } from '../../redux/weatherSlice/weatherSlice';


import moment from "moment";


const Weather = () => {
  
const dispatch =useDispatch();
    const cityName=useSelector((state)=>state.city.listCity.name)
    const data = useSelector((state) => state.city.listCity);
    const spinner = useSelector((state) => state.weather.loading);
    // const [showSugg, setShowSugg] = useState(false);
    console.log(data,"weather");
    console.log(spinner,"spinner");
    console.log(cityName,"cityNameWeather");
    // const data = weather && weather.map((users)=>console.log(users))
    // console.log(data,"data");
    useEffect(() => {
      dispatch(getDataAsync(cityName));
    }, [cityName, dispatch]);
  

      
  return (
    <>
          <div className="helper-text">Type City Name and Hit Enter</div>
          <div className="info">
            <div className="sub-heading">
              Weather Forecast <div>on</div>
            </div>
            <small className="date">
            {data? moment().format("MMM DD YYYY") : null}
         
            </small>
            <div className="location">
            
       {data.name}     
       <small>
        ( {data.sys.country})
                </small>
            </div>
            <div className="forecast-info">
              <div className="forecast-icon">
                  <img
                    src={`https://openweathermap.org/img/wn/${data.weather[0].icon}.png`}
                    alt=""
                  />
              </div>
              <div className="forecast-value">
                <div className="degrees">
                  <span className="">
                 {data.main.temp}  &deg;
                  </span>
                  C
                </div>
                <span className="weather-condition">
                {data.weather[0].description}
                </span>
              </div>
            </div>
            <div className="additional-info">
              <ul className="list">
                <li>
                  <b>Feels Like:</b>
                 {data.main.feels_like } 
                </li>
                <li>
                  <b>Min Temp:</b>
                  {data.main.temp_min}
                </li>
                <li>
                  <b>Max Temp:</b>
                  {data.main.temp_max}
                </li>
                <li>
                  <b>Pressure:</b>
                  {data.main.pressure}
                </li>
                <li>
                  <b>Humidity:</b>
                  {data.main.humidity}
                </li>
              </ul>
            </div>
          </div>
       
        {/* <ToastContainer /> */}
    </>
  )
}

export default Weather
import React, { useState } from 'react'
import { getAutoComplName, getCityName } from '../../redux/weatherSlice/citySlice';
import { useDispatch, useSelector } from 'react-redux';
import './Weather.css'
import { getDataAsync } from '../../redux/weatherSlice/weatherSlice';

const City = () => {
    const [user ,setUser]=useState("");
    const dispatch =useDispatch();
    const city=useSelector((state)=>state.city.listCity)
    const [showSugg, setShowSugg] = useState(false);
    console.log(city,"city");
    const handleSearch =(e)=>{
        e.preventDefault()
        dispatch(getCityName(user))
     }

  return (
    <div>
          <div className="heading">Weather Finder</div>
          <form className="search-form"
      
           >
            <input
              type="text"
              name='user'
              placeholder="Search Weather by City"
              value={user}
              onChange={(e) => {
                setShowSugg(true);
                setUser(e.target.value);
                dispatch(getAutoComplName(e.target.value));
              }}
            />
            <button  onClick={handleSearch}>Find</button>
            {/* {city && showSugg && (
       <ul className="suggestions"> 
        { city?.map((item) => ( 
        <li
              className="sugg-item" 
        key={item.id}
              onClick={(e) => { 
          handleSearch(e);
      setShowSugg(false);
             }}
            > 
              {item.name}
            </li>
           ))}
         </ul> 
      )} */}
          </form>
          </div>
  )
}

export default City
import { useSelector } from "react-redux";
import "./App.css";
import Weather from "./components/weather/Weather";
import City from "./components/weather/city";
import "../src/components/weather/Weather.css";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";
function App() {
  const cityName = useSelector((state) => state.city.listCity.name);
  return (
    <div className="container">
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
      <City />
      {cityName && <Weather />}
    </div>
  );
}

export default App;

import {  getAllServices,  getHomepageInfoServices, getRecruitmentpartnersServices, getSocialiconServices, getVideodetailServices, getmediaCoverageServices } from "../../servicesAll/servicesAll";
import { GET_HOMEPAGE_INFO, GET_MEDIACOVERAGE, GET_RECRUITMENTPARTNERS, GET_SOCIALICON, GET_VIDEODETAIL, SAVE_HOMEPAGE_HEADER } from "./actionType";

//Home Page Action 
export const getUserAll = () => async (dispatch) => {
  const props = {
    isactive: "Y",
    pageable: {
      pageno: 0,
      pagesize: 10,
    },
  };
  try {
    const res = await getAllServices(props);
    dispatch({
      type: SAVE_HOMEPAGE_HEADER,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};


export const getHomePageInfo = () => async (dispatch) => {
  const props = {
    isactive: "Y",
    pageable: {
      pageno: 0,
      pagesize: 10,
    },
  };
  try {
    const res = await getHomepageInfoServices(props);
    dispatch({
      type: GET_HOMEPAGE_INFO,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const getMediacoverage = () => async (dispatch) => {
  const props = {
    isactive: "Y",
    pageable: {
      pageno: 0,
      pagesize: 10,
    },
  };
  try {
    const res = await getmediaCoverageServices(props);
    dispatch({
      type: GET_MEDIACOVERAGE,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const getRecruitmentpartners = () => async (dispatch) => {
  const props = {
    isactive: "Y",
    pageable: {
      pageno: 0,
      pagesize: 10,
    },
  };
  try {
    const res = await getRecruitmentpartnersServices(props);
    dispatch({
      type: GET_RECRUITMENTPARTNERS,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const getSocialicon = () => async (dispatch) => {
  const props = {
    isactive: "Y",
    pageable: {
      pageno: 0,
      pagesize: 10,
    },
  };
  try {
    const res = await getSocialiconServices(props);
    dispatch({
      type: GET_SOCIALICON,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const getVideodetail = () => async (dispatch) => {
  const props = {
    isactive: "Y",
    pageable: {
      pageno: 0,
      pagesize: 10,
    },
  };
  try {
    const res = await getVideodetailServices(props);
    dispatch({
      type: GET_VIDEODETAIL,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};



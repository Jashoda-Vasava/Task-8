import {
  GET_HOMEPAGE_INFO,
  GET_MEDIACOVERAGE,
  GET_RECRUITMENTPARTNERS,
  GET_SOCIALICON,
  GET_VIDEODETAIL,
  SAVE_HOMEPAGE_HEADER,
} from "../action/actionType";

const initialState = [];

const homePageReducer = (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case SAVE_HOMEPAGE_HEADER:
      return { ...state, header: payload };
    case GET_HOMEPAGE_INFO:
      return { ...state, info: payload };
    case GET_MEDIACOVERAGE:
      return { ...state, mediacoverage: payload };
    case GET_RECRUITMENTPARTNERS:
      return { ...state, recruitmentpartners: payload };
    case GET_SOCIALICON:
      return { ...state, socialicon: payload };
    case GET_VIDEODETAIL:
      return { ...state, videodetail: payload };
    default:
      return state;
  }
};

export default homePageReducer;

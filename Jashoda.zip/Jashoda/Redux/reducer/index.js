import { combineReducers } from "redux";

import homePageReducer from "./homePageReducer"; 

export default combineReducers({
user:homePageReducer,
});
